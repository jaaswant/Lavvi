import { useState, useEffect, useCallback, useMemo } from 'react';
import { BUILTIN_TOPICS, loadLesson, isAiAvailable } from './lib/lessons';
import { IDEAS } from './data/ideas';
import { useProgress, useTheme, dayKey } from './lib/progress';
import { stopSpeaking } from './lib/speech';
import Header from './components/Header';
import Home from './components/Home';
import TeachingBoard from './components/TeachingBoard';
import DoubtPanel from './components/DoubtPanel';
import Teacher from './components/Teacher';
import Challenge from './components/Challenge';
import Subjects from './components/Subjects';
import Compare from './components/Compare';
import NotesScanner from './components/NotesScanner';
import Toasts from './components/Toasts';
import './App.css';

export default function App() {
  const [view, setView] = useState('home'); // home | lesson | challenge | subjects | compare | scan
  const [lesson, setLesson] = useState(null);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [subjectId, setSubjectId] = useState(null);
  const [startSignal, setStartSignal] = useState(0);
  const [aiOn, setAiOn] = useState(false);
  const [theme, toggleTheme] = useTheme();
  const progress = useProgress();
  const { data, award } = progress;

  useEffect(() => {
    isAiAvailable().then(setAiOn);
  }, []);

  // "/" jumps to the search box from anywhere
  useEffect(() => {
    const onKey = (e) => {
      if (e.key !== '/' || e.target.closest?.('input, textarea, select') || e.metaKey || e.ctrlKey) return;
      const input = document.querySelector('[data-search-input]');
      if (input) {
        e.preventDefault();
        input.focus();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const search = useCallback(
    async (q, depth = 'standard') => {
      setLoading(true);
      setError('');
      setQuery(q);
      try {
        const result = await loadLesson(q, depth);
        // first time this lesson shows up in the history: small reward
        if (!data.history.some((h) => h.id === result.id)) award(5, 'New lesson');
        progress.pushHistory(result);
        setLesson(result);
        setView('lesson');
        window.scrollTo({ top: 0 });
        setStartSignal((n) => n + 1); // the search click lets the teacher start talking
      } catch (e) {
        setError(e.message || 'Something went wrong. Please try again.');
      } finally {
        setLoading(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [data.history, award]
  );

  const goHome = () => {
    stopSpeaking();
    setView('home');
    setError('');
  };

  const openSubjects = (id = null) => {
    stopSpeaking();
    setSubjectId(id);
    setView('subjects');
    setError('');
    window.scrollTo({ top: 0 });
  };

  const openChallenge = () => {
    stopSpeaking();
    setView('challenge');
    window.scrollTo({ top: 0 });
  };

  const openTool = (name) => {
    stopSpeaking();
    setView(name);
    setError('');
    window.scrollTo({ top: 0 });
  };

  const index = lesson?.builtin ? BUILTIN_TOPICS.findIndex((t) => t.id === lesson.id) : -1;
  const openRelative = (delta) => {
    const next = BUILTIN_TOPICS[index + delta];
    if (next) search(next.name);
  };

  const toggleComplete = () => {
    const was = data.completed.includes(lesson.id);
    progress.toggleComplete(lesson.id);
    progress.toast(was ? 'Marked as not complete' : '+25 XP · Lesson complete');
  };

  const onQuizFinish = ({ score, total, first }) => {
    progress.recordQuiz(lesson.id, score, total);
    if (first) {
      const xp = score * 10 + (score === total ? 20 : 0);
      if (xp) award(xp, score === total ? 'Perfect quiz' : 'Quiz');
    }
  };

  const onChallengeFinish = ({ score, total, first }) => {
    const already = data.dailyDone === dayKey();
    if (!first || already) return;
    progress.finishDaily();
    award(score * 10 + 30, `Daily challenge ${score}/${total}`);
  };

  const suggestions = useMemo(
    () => [...data.history.map((h) => h.name), ...IDEAS, ...BUILTIN_TOPICS.map((t) => t.name)],
    [data.history]
  );

  return (
    <div className="app">
      <a className="skip-link" href="#main">Skip to content</a>
      <Header
        onHome={goHome}
        onSearch={search}
        onChallenge={openChallenge}
        onSubjects={() => openSubjects(null)}
        onCompare={() => openTool('compare')}
        onScan={() => openTool('scan')}
        subjectCount={data.subjects.length}
        loading={loading}
        query={query}
        showSearch={view !== 'home'}
        suggestions={suggestions}
        progress={data}
        dailyDone={data.dailyDone === dayKey()}
        theme={theme}
        onToggleTheme={toggleTheme}
        onFocusDone={() => {
          progress.addFocusSession();
          award(15, 'Focus session');
        }}
      />

      <main id="main" className={`main ${view === 'lesson' ? 'main-lesson' : ''}`}>
        {view === 'lesson' && lesson && (
          <div className="lesson-layout" key={lesson.id}>
            <div className="topic-view">
              {error && <p className="form-error" role="alert">{error}</p>}
              <TeachingBoard
                topic={lesson}
                index={index}
                total={BUILTIN_TOPICS.length}
                progress={data}
                aiOn={aiOn}
                onToggleComplete={toggleComplete}
                onNextTopic={() => openRelative(1)}
                onPrevTopic={() => openRelative(-1)}
                hasPrev={index > 0}
                hasNext={index >= 0 && index < BUILTIN_TOPICS.length - 1}
                onExplain={() => setStartSignal((n) => n + 1)}
                onOpenTopic={(name) => search(name)}
                onChangeDepth={(depth) => search(lesson.name, depth)}
                isBookmarked={data.bookmarks.some((b) => b.id === lesson.id)}
                onToggleBookmark={() => progress.toggleBookmark(lesson)}
                subjects={data.subjects}
                onToggleSubject={progress.toggleInSubject}
                onCreateSubject={progress.addSubject}
                note={data.notes[lesson.id] || ''}
                onNoteChange={(text) => progress.setNote(lesson.id, text)}
                cardsKnown={data.cardsKnown[lesson.id] || []}
                onCardsKnown={(list) => progress.setCardsKnown(lesson.id, list)}
                award={award}
                onQuizFinish={onQuizFinish}
              />
              <DoubtPanel currentTopic={lesson} />
            </div>
            <div className="lesson-side">
              <Teacher key={lesson.id} topicName={lesson.name} script={lesson.script} startSignal={startSignal} />
            </div>
          </div>
        )}

        {view === 'subjects' && (
          <Subjects
            progress={data}
            actions={progress}
            selectedId={subjectId}
            onSelect={setSubjectId}
            onOpenTopic={(name) => search(name)}
            loading={loading}
          />
        )}

        {view === 'compare' && <Compare aiOn={aiOn} award={award} onBack={goHome} onToast={progress.toast} />}

        {view === 'scan' && <NotesScanner aiOn={aiOn} award={award} onBack={goHome} onToast={progress.toast} />}

        {view === 'challenge' && (
          <Challenge doneToday={data.dailyDone === dayKey()} onFinish={onChallengeFinish} onBack={goHome} />
        )}

        {view === 'home' && (
          <Home
            onSearch={search}
            onChallenge={openChallenge}
            onCompare={() => openTool('compare')}
            onScan={() => openTool('scan')}
            onOpenSubject={openSubjects}
            onClearHistory={progress.clearHistory}
            onImport={progress.importData}
            onToast={progress.toast}
            loading={loading}
            error={error}
            progress={data}
            suggestions={suggestions}
          />
        )}
      </main>

      <Toasts toasts={progress.toasts} />
    </div>
  );
}
