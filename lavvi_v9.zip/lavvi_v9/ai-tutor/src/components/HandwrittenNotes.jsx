import { useState, useEffect } from 'react';
import { labelize } from '../lib/quiz';
import { hinglishFor } from '../lib/hinglish';

// Concept notes written like a student's notebook page: handwriting font, doodles, boxed definitions.
// Small pictures only: a hand-drawn sketch of the idea, plus a small taped photo when the lesson has one.

const Wobble = () => (
  <svg width="0" height="0" aria-hidden="true" focusable="false" style={{ position: 'absolute' }}>
    <filter id="hw-wobble">
      <feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="2" seed="7" result="n" />
      <feDisplacementMap in="SourceGraphic" in2="n" scale="2.6" />
    </filter>
  </svg>
);

const Squiggle = () => (
  <svg className="hw-squiggle" viewBox="0 0 220 12" preserveAspectRatio="none" aria-hidden="true">
    <path d="M2 7c12-7 22 5 34-1s22 4 34-1 22 5 34 0 22 4 34-1 22 4 34 0 22 3 34-1" fill="none" stroke="var(--hw-red)" strokeWidth="3" strokeLinecap="round" />
  </svg>
);

// ----- tiny sketches for the built-in DSA topics -----
const box = (x, y, w, h, label, extra = {}) => (
  <g key={`${x}-${y}`}>
    <rect x={x} y={y} width={w} height={h} rx="4" fill={extra.fill || 'none'} stroke="currentColor" strokeWidth="2.4" />
    {label !== undefined && <text x={x + w / 2} y={y + h / 2 + 5} textAnchor="middle" className="hw-svg-text">{label}</text>}
  </g>
);
const arrow = (x1, y, x2) => (
  <g key={`a${x1}${y}`} fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
    <path d={`M${x1} ${y}H${x2}`} />
    <path d={`M${x2 - 6} ${y - 5}L${x2} ${y}L${x2 - 6} ${y + 5}`} />
  </g>
);

const SKETCHES = {
  arrays: (
    <>
      {[0, 1, 2, 3, 4].map((i) => box(14 + i * 44, 40, 44, 44, ['7', '3', '9', '1', '5'][i]))}
      {[0, 1, 2, 3, 4].map((i) => <text key={i} x={36 + i * 44} y="104" textAnchor="middle" className="hw-svg-small">{i}</text>)}
      <text x="14" y="24" className="hw-svg-small">index →</text>
    </>
  ),
  'linked-lists': (
    <>
      {[0, 1, 2].map((i) => (
        <g key={i}>
          {box(10 + i * 78, 42, 38, 40, ['A', 'B', 'C'][i])}
          {box(48 + i * 78, 42, 22, 40, '', { fill: 'var(--hw-hl)' })}
          {i < 2 && arrow(59 + i * 78, 62, 88 + i * 78)}
        </g>
      ))}
      <text x="236" y="68" className="hw-svg-small">null</text>
      {arrow(214, 62, 232)}
    </>
  ),
  stacks: (
    <>
      {[0, 1, 2, 3].map((i) => box(70, 90 - i * 24, 80, 22, ['A', 'B', 'C', 'D'][i]))}
      <path d="M110 2v16M102 10l8 8 8-8" fill="none" stroke="var(--hw-red)" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
      <text x="160" y="30" className="hw-svg-small">push / pop</text>
      <text x="160" y="104" className="hw-svg-small">LIFO</text>
    </>
  ),
  queues: (
    <>
      {[0, 1, 2, 3].map((i) => box(40 + i * 40, 46, 40, 40, ['1', '2', '3', '4'][i]))}
      {arrow(6, 66, 36)}
      {arrow(204, 66, 236)}
      <text x="4" y="40" className="hw-svg-small">in</text>
      <text x="212" y="40" className="hw-svg-small">out</text>
      <text x="96" y="110" className="hw-svg-small">FIFO</text>
    </>
  ),
  recursion: (
    <>
      {[0, 1, 2].map((i) => <rect key={i} x={20 + i * 22} y={16 + i * 18} width={200 - i * 44} height={90 - i * 36} rx="6" fill="none" stroke="currentColor" strokeWidth="2.4" />)}
      <text x="120" y="76" textAnchor="middle" className="hw-svg-text">base case</text>
    </>
  ),
  sorting: (
    <>
      {[34, 70, 22, 88, 52].map((h, i) => <rect key={i} x={20 + i * 34} y={104 - h} width="24" height={h} rx="3" fill={i === 3 ? 'var(--hw-hl)' : 'none'} stroke="currentColor" strokeWidth="2.4" />)}
      <path d="M190 40c16-4 30 4 38 14M228 54l-2-10M228 54l-10-2" fill="none" stroke="var(--hw-red)" strokeWidth="2.4" strokeLinecap="round" />
    </>
  )
};

// A tiny flow chart drawn from the lesson's own diagram data (AI and Wikipedia lessons).
function MiniChain({ visual }) {
  if (visual.type === 'compare') {
    return (
      <div className="hw-compare">
        <span>{visual.columns[0].title}</span>
        <b>vs</b>
        <span>{visual.columns[1].title}</span>
      </div>
    );
  }
  const items = visual.items.slice(0, 5);
  return (
    <ol className={`hw-chain ${visual.type === 'cycle' ? 'is-cycle' : ''}`}>
      {items.map((it) => (
        <li key={it.label}><span>{it.label}</span></li>
      ))}
      {visual.type === 'cycle' && <li className="hw-back" aria-hidden="true">↺</li>}
    </ol>
  );
}

function Doodle({ topic, caption }) {
  const sketch = SKETCHES[topic.id];
  if (sketch) {
    return (
      <figure className="hw-sketch" aria-label={`Hand-drawn sketch of ${topic.name}`}>
        <svg viewBox="0 0 250 120" role="img" aria-hidden="true" filter="url(#hw-wobble)">{sketch}</svg>
        <figcaption>{caption}</figcaption>
      </figure>
    );
  }
  if (topic.visual?.items?.length >= 3 || topic.visual?.type === 'compare') {
    return (
      <figure className="hw-sketch hw-sketch-chain">
        <MiniChain visual={topic.visual} />
        <figcaption>{topic.visual.title}</figcaption>
      </figure>
    );
  }
  return null;
}

// Headings in both languages. Hinglish = Hindi in English letters, the way we talk in class.
const LABELS = {
  english: {
    what: 'What is it?', like: 'Think of it like…', why: 'Why we use it', key: 'Key points', careful: 'Careful!', watch: 'Watch out',
    time: 'Remember (time and space)', facts: 'Quick facts', remember: '★ Remember:', sketch: 'quick sketch',
    title: 'Handwritten notes', sub: 'The concept as a quick notebook page. Press Print to keep a copy.'
  },
  hinglish: {
    what: 'Yeh kya hai?', like: 'Aise socho…', why: 'Isse kyun use karte hain', key: 'Zaroori baatein', careful: 'Dhyan rakho!', watch: 'Dhyan rakho',
    time: 'Yaad rakho (time aur space)', facts: 'Quick facts', remember: '★ Yaad rakho:', sketch: 'chhota sketch',
    title: 'Handwritten notes', sub: 'Concept ek notebook page ki tarah. Copy rakhne ke liye Print dabao.'
  }
};

const textsOf = (c) => [c.tagline, c.whatIsIt, c.realLifeAnalogy.replace(/\n+/g, ' '), ...c.whyUse, ...c.limitations];
const converted = new Map(); // lesson id + level -> Hinglish strings, so switching back and forth is instant

export default function HandwrittenNotes({ topic, aiOn }) {
  const [lang, setLang] = useState(() => {
    try {
      return localStorage.getItem('ai_tutor_notes_lang') === 'hinglish' ? 'hinglish' : 'english';
    } catch {
      return 'english';
    }
  });
  const key = `${topic.id}|${topic.level || ''}`;
  const [hi, setHi] = useState(() => converted.get(key) || null);
  const [state, setState] = useState('idle'); // idle | loading | failed
  const original = topic.concept;
  const L = LABELS[lang];

  const [copied, setCopied] = useState(false);
  const copyText = () => {
    const lines = [`${topic.name}`, '', c.tagline, c.whatIsIt !== c.tagline ? c.whatIsIt : '', '', ...c.whyUse.map((p) => `- ${p}`), ...c.limitations.map((p) => `! ${p}`)].filter((x, i, a) => x || a[i - 1]);
    navigator.clipboard?.writeText(lines.join('\n')).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  };

  const choose = (l) => {
    setLang(l);
    try {
      localStorage.setItem('ai_tutor_notes_lang', l);
    } catch {
      /* ignore */
    }
  };

  // Turn the notes into Hinglish the first time they are asked for.
  useEffect(() => {
    if (lang !== 'hinglish' || hi) return undefined;
    let alive = true;
    setState('loading');
    hinglishFor(textsOf(original), { ai: aiOn }).then((out) => {
      if (!alive) return;
      const strings = out.map((o) => o.hi);
      if (strings.some(Boolean)) {
        converted.set(key, strings);
        setHi(strings);
        setState('idle');
      } else {
        setState('failed');
      }
    });
    return () => {
      alive = false;
    };
  }, [lang, hi, original, aiOn, key]);

  // The concept with every sentence replaced by its Hinglish version (falling back to English per line).
  const showHi = lang === 'hinglish' && hi;
  let c = original;
  if (showHi) {
    let i = 0;
    const take = (en) => hi[i++] || en;
    c = {
      ...original,
      tagline: take(original.tagline),
      whatIsIt: take(original.whatIsIt),
      realLifeAnalogy: take(original.realLifeAnalogy.replace(/\n+/g, ' ')),
      whyUse: original.whyUse.map(take),
      limitations: original.limitations.map(take)
    };
  }
  const facts = Object.entries(original.complexities || {});
  const takeaway = c.whyUse[0] || c.tagline;

  return (
    <div className="stack-lg fade-in">
      <div className="walk-head">
        <div>
          <h3 className="section-title">{L.title}</h3>
          <p className="muted small">{L.sub}</p>
        </div>
        <div className="hw-tools">
          <div className="segmented segmented-sm" role="group" aria-label="Language of the notes">
            <button type="button" className={lang === 'english' ? 'on' : ''} aria-pressed={lang === 'english'} onClick={() => choose('english')}>English</button>
            <button type="button" className={lang === 'hinglish' ? 'on' : ''} aria-pressed={lang === 'hinglish'} onClick={() => choose('hinglish')}>Hinglish</button>
          </div>
          <button type="button" className="btn btn-ghost btn-sm" onClick={copyText}>{copied ? 'Copied' : 'Copy text'}</button>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => window.print()}>Print</button>
        </div>
      </div>
      {lang === 'hinglish' && state === 'loading' && <p className="muted small" role="status">Notes ko Hinglish mein likh raha hoon… (writing the notes in Hinglish)</p>}
      {lang === 'hinglish' && state === 'failed' && <p className="form-error" role="alert">Could not make the Hinglish notes (this needs an internet connection), so the notes are shown in English.</p>}

      <Wobble />
      <article className="hw-page" aria-label={`Handwritten notes on ${topic.name}`}>
        <span className="hw-tape hw-tape-l" aria-hidden="true" />
        <span className="hw-tape hw-tape-r" aria-hidden="true" />

        <header className="hw-top">
          <h2 className="hw-title">
            <span className="hw-title-text">{topic.icon} {topic.name}</span>
            <Squiggle />
          </h2>
          <p className="hw-sub">{topic.subtitle}</p>
        </header>

        <div className="hw-row">
          <section className="hw-def">
            <h3>{L.what}</h3>
            <p>{c.tagline || c.whatIsIt}</p>
            {c.whatIsIt && c.tagline !== c.whatIsIt && !original.whatIsIt.startsWith(original.tagline) && <p className="hw-small">{c.whatIsIt}</p>}
          </section>
          <div className="hw-side">
            <Doodle topic={topic} caption={L.sketch} />
            {topic.image && (
              <figure className="hw-photo">
                <img src={topic.image} alt={`${topic.name}, small illustration`} loading="lazy" />
              </figure>
            )}
          </div>
        </div>

        {c.realLifeAnalogy && (
          <section className="hw-sticky">
            <h3>{L.like}</h3>
            <p>{c.realLifeAnalogy.replace(/\n+/g, ' ')}</p>
          </section>
        )}

        {c.whyUse.length > 0 && (
          <section className="hw-block">
            <h3>{topic.builtin ? L.why : L.key}</h3>
            <ul className="hw-list">
              {c.whyUse.map((p, i) => (
                <li key={i}>{p}</li>
              ))}
            </ul>
          </section>
        )}

        {c.limitations.length > 0 && (
          <section className="hw-block hw-warn">
            <h3>{topic.builtin ? L.careful : L.watch}</h3>
            <ul className="hw-list hw-list-red">
              {c.limitations.map((p, i) => (
                <li key={i}>{p}</li>
              ))}
            </ul>
          </section>
        )}

        {facts.length > 0 && (
          <section className="hw-block">
            <h3>{topic.builtin ? L.time : L.facts}</h3>
            <dl className="hw-facts">
              {facts.map(([k, v]) => (
                <div key={k}>
                  <dt>{labelize(k)}</dt>
                  <dd>{v}</dd>
                </div>
              ))}
            </dl>
          </section>
        )}

        {takeaway && (
          <p className="hw-takeaway">
            <span>{L.remember}</span> <mark>{takeaway}</mark>
          </p>
        )}
      </article>
    </div>
  );
}
