import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import TeacherAvatar from './TeacherAvatar';
import { PlayIcon, PauseIcon, StopIcon, SkipBackIcon, SkipNextIcon, MinusIcon, ExpandIcon, SettingsIcon } from './Icons';
import { speechSupported, loadVoices, usableVoices, pickVoice, planLine, STOP_EVENT } from '../lib/speech';

const RATES = [0.9, 1.0, 1.15];
const PITCHES = { soft: 1.15, normal: 1.0 }; // soft = a little lighter than the default voice
const store = {
  get: (k, d) => {
    try {
      return localStorage.getItem(k) || d;
    } catch {
      return d;
    }
  },
  set: (k, v) => {
    try {
      localStorage.setItem(k, v);
    } catch {
      /* ignore */
    }
  }
};

// Lavvi, the teacher. Speaks English in an Indian male voice and shows the same words as captions.
export default function Teacher({ topicName, script, startSignal }) {
  const supported = speechSupported();
  const lines = useMemo(() => script.filter((s) => s.en), [script]);

  const [status, setStatus] = useState('idle'); // idle | speaking | paused
  const [index, setIndex] = useState(0);
  const [rate, setRate] = useState(1.0);
  const [size, setSize] = useState('normal'); // normal | large | minimized
  const [voices, setVoices] = useState([]);
  const [voiceURI, setVoiceURI] = useState(() => store.get('ai_tutor_voice_uri', ''));
  const [showSettings, setShowSettings] = useState(false);

  const effectiveMode = 'english';
  const runRef = useRef(0);
  const indexRef = useRef(0);
  const rateRef = useRef(1.0);
  const pitchRef = useRef(store.get('ai_tutor_voice_pitch', 'soft'));
  const [pitch, setPitch] = useState(pitchRef.current);
  const utterRef = useRef(null);

  useEffect(() => {
    rateRef.current = rate;
  }, [rate]);

  useEffect(() => {
    if (!supported) return undefined;
    let alive = true;
    loadVoices().then((v) => alive && setVoices(v));
    const synth = window.speechSynthesis;
    const refresh = () => setVoices(synth.getVoices() || []);
    synth.addEventListener?.('voiceschanged', refresh);
    return () => {
      alive = false;
      synth.removeEventListener?.('voiceschanged', refresh);
      runRef.current += 1;
      synth.cancel();
    };
  }, [supported]);

  const choices = useMemo(() => usableVoices(voices), [voices]);
  const voice = useMemo(() => pickVoice(voices, effectiveMode, voiceURI), [voices, effectiveMode, voiceURI]);

  const speakFrom = useCallback(
    (start) => {
      if (!supported || lines.length === 0) return;
      const synth = window.speechSynthesis;
      synth.cancel();
      runRef.current += 1;
      const run = runRef.current;

      const next = (i) => {
        if (run !== runRef.current) return;
        if (i >= lines.length) {
          indexRef.current = 0;
          setIndex(0);
          setStatus('idle');
          return;
        }
        indexRef.current = i;
        setIndex(i);
        const plan = planLine(lines[i], effectiveMode, voices.length ? voices : synth.getVoices() || [], voiceURI);
        const u = new SpeechSynthesisUtterance(plan.text);
        utterRef.current = u; // keep a reference so the browser doesn't garbage-collect it
        u.lang = plan.lang;
        u.rate = rateRef.current;
        u.pitch = PITCHES[pitchRef.current] || 1.15;
        if (plan.voice) u.voice = plan.voice;
        u.onend = () => next(i + 1);
        u.onerror = (e) => {
          if (run !== runRef.current) return;
          if (e.error === 'canceled' || e.error === 'interrupted') return;
          setStatus('idle');
        };
        synth.speak(u);
      };

      setStatus('speaking');
      next(start);
    },
    [supported, lines, voices, voiceURI, effectiveMode]
  );

  // Start explaining automatically when a new lesson is opened from a search
  useEffect(() => {
    if (startSignal > 0) speakFrom(0);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startSignal]);

  const stop = useCallback(() => {
    runRef.current += 1;
    if (supported) window.speechSynthesis.cancel();
    indexRef.current = 0;
    setIndex(0);
    setStatus('idle');
  }, [supported]);

  // Something else (a chat answer, a walkthrough step) wants to speak.
  useEffect(() => {
    window.addEventListener(STOP_EVENT, stop);
    return () => window.removeEventListener(STOP_EVENT, stop);
  }, [stop]);

  const pause = () => {
    runRef.current += 1;
    window.speechSynthesis.cancel();
    setStatus('paused');
  };
  const jump = (to) => {
    const i = Math.max(0, Math.min(lines.length - 1, to));
    if (status === 'speaking') speakFrom(i);
    else {
      indexRef.current = i;
      setIndex(i);
      setStatus('paused');
    }
  };
  const changeRate = (r) => {
    setRate(r);
    rateRef.current = r;
    if (status === 'speaking') speakFrom(indexRef.current);
  };
  const changePitch = (p) => {
    setPitch(p);
    pitchRef.current = p;
    store.set('ai_tutor_voice_pitch', p);
    if (status === 'speaking') speakFrom(indexRef.current);
  };
  const changeVoice = (uri) => {
    setVoiceURI(uri);
    store.set('ai_tutor_voice_uri', uri);
    if (status === 'speaking') {
      runRef.current += 1;
      window.speechSynthesis.cancel();
      setStatus('paused');
    }
  };

  // Space plays or pauses the teacher (unless you are typing or on a button).
  const statusRef = useRef(status);
  statusRef.current = status;
  useEffect(() => {
    const onKey = (e) => {
      if (e.code !== 'Space' || e.target.closest?.('input, textarea, select, button, a, [contenteditable]') || !supported) return;
      e.preventDefault();
      if (statusRef.current === 'speaking') pause();
      else speakFrom(statusRef.current === 'paused' ? indexRef.current : 0);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  });

  const speaking = status === 'speaking';
  const caption =
    status === 'idle'
      ? `Hi, I'm Lavvi. Press Explain and I'll walk you through ${topicName}.`
      : lines[index]?.en || '';

  if (size === 'minimized') {
    return (
      <button type="button" className="teacher-bubble" onClick={() => setSize('normal')} aria-label="Open the teacher">
        <span className="teacher-bubble-face"><TeacherAvatar speaking={speaking} /></span>
        <span>Lavvi</span>
        {speaking && <span className="live-dot" />}
      </button>
    );
  }

  return (
    <aside className={`teacher ${size === 'large' ? 'teacher-large' : ''}`} aria-label="AI teacher">
      <div className="teacher-stage">
        <TeacherAvatar speaking={speaking} />
        <span className={`teacher-status ${speaking ? 'live' : ''}`}>
          <span className={`live-dot ${speaking ? '' : 'off'}`} />
          {speaking ? 'Speaking' : status === 'paused' ? 'Paused' : 'Ready'}
        </span>
        <span className="teacher-winbtns">
          <button type="button" onClick={() => setShowSettings(!showSettings)} aria-label="Voice settings" aria-expanded={showSettings}><SettingsIcon size={14} /></button>
          <button type="button" onClick={() => setSize(size === 'large' ? 'normal' : 'large')} aria-label="Resize the teacher"><ExpandIcon size={14} /></button>
          <button type="button" onClick={() => setSize('minimized')} aria-label="Minimize the teacher"><MinusIcon size={14} /></button>
        </span>
        {speaking && <span className="teacher-wave" aria-hidden="true"><i /><i /><i /><i /></span>}
      </div>

      <p className="teacher-caption" aria-live="polite">{caption}</p>

      {lines.length > 0 && (
        <div className="teacher-ticks" role="group" aria-label="Lesson parts">
          {lines.map((_, i) => (
            <button
              key={i}
              type="button"
              className={`tick ${status !== 'idle' && i === index ? 'on' : ''} ${status !== 'idle' && i < index ? 'past' : ''}`}
              onClick={() => (status === 'idle' ? speakFrom(i) : jump(i))}
              aria-label={`Part ${i + 1} of ${lines.length}`}
            />
          ))}
        </div>
      )}

      {supported ? (
        <>
          <div className="teacher-controls">
            <button type="button" className="icon-btn" onClick={() => jump(index - 1)} disabled={status === 'idle' || index === 0} aria-label="Previous part"><SkipBackIcon size={16} /></button>
            {speaking ? (
              <button type="button" className="btn btn-primary" onClick={pause}><PauseIcon size={16} /> Pause</button>
            ) : (
              <button type="button" className="btn btn-primary" onClick={() => speakFrom(status === 'paused' ? indexRef.current : 0)}>
                <PlayIcon size={16} /> {status === 'paused' ? 'Resume' : 'Explain'}
              </button>
            )}
            <button type="button" className="icon-btn" onClick={() => jump(index + 1)} disabled={status === 'idle' || index >= lines.length - 1} aria-label="Next part"><SkipNextIcon size={16} /></button>
            <button type="button" className="icon-btn" onClick={stop} disabled={status === 'idle'} aria-label="Stop"><StopIcon size={16} /></button>
          </div>

          <div className="teacher-options">
            <div className="segmented segmented-sm" role="group" aria-label="Voice tone">
              <button type="button" className={pitch === 'soft' ? 'on' : ''} aria-pressed={pitch === 'soft'} onClick={() => changePitch('soft')}>Soft</button>
              <button type="button" className={pitch === 'normal' ? 'on' : ''} aria-pressed={pitch === 'normal'} onClick={() => changePitch('normal')}>Normal</button>
            </div>
            <div className="segmented segmented-sm" role="group" aria-label="Speaking speed">
              {RATES.map((r) => (
                <button key={r} type="button" className={rate === r ? 'on' : ''} aria-pressed={rate === r} onClick={() => changeRate(r)}>
                  {r}x
                </button>
              ))}
            </div>
          </div>

          {showSettings && (
            <div className="teacher-settings">
              <label htmlFor="voice-select">Voice</label>
              <select id="voice-select" value={voice?.voiceURI || ''} onChange={(e) => changeVoice(e.target.value)}>
                {choices.length === 0 && <option value="">Default voice</option>}
                {choices.map((v) => (
                  <option key={v.voiceURI} value={v.voiceURI}>{v.name} ({v.lang})</option>
                ))}
              </select>
              <p className="muted small">I use an Indian English male voice when your device has one. Voices come from your browser and device.</p>
            </div>
          )}
        </>
      ) : (
        <p className="teacher-note">Voice isn't supported in this browser, but you can read my words above.</p>
      )}
    </aside>
  );
}
