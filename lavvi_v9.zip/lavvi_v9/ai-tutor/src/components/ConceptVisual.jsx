import { useState, useEffect } from 'react';
import { PlayIcon, PauseIcon, RefreshIcon } from './Icons';

const boxW = (label) => Math.max(76, label.length * 7.4 + 28);

// Cycle: boxes around an ellipse. Parts: a centre with spokes.
function Radial({ visual, active, onPick }) {
  const items = visual.items;
  const n = items.length;
  const cx = 230;
  const cy = 170;
  const rx = visual.type === 'cycle' ? 170 : 175;
  const ry = visual.type === 'cycle' ? 118 : 120;
  const pos = items.map((_, i) => {
    const a = (-90 + (i * 360) / n) * (Math.PI / 180);
    return { x: cx + rx * Math.cos(a), y: cy + ry * Math.sin(a) };
  });

  return (
    <svg className="cv-svg" viewBox="0 0 460 340" role="img" aria-label={visual.title}>
      {visual.type === 'cycle' ? (
        <ellipse cx={cx} cy={cy} rx={rx} ry={ry} className="cv-track" />
      ) : (
        pos.map((p, i) => <line key={i} x1={cx} y1={cy} x2={p.x} y2={p.y} className="cv-track" />)
      )}
      {visual.type === 'cycle' ? (
        <text x={cx} y={cy - 4} textAnchor="middle" className="cv-center-text">{visual.title}</text>
      ) : (
        <g>
          <circle cx={cx} cy={cy} r="52" className="cv-center" />
          <text x={cx} y={cy + 5} textAnchor="middle" className="cv-center-text on-fill">{visual.title.length > 22 ? `${visual.title.slice(0, 20)}…` : visual.title}</text>
        </g>
      )}
      {visual.type === 'cycle' && (
        <text x={cx} y={cy + 16} textAnchor="middle" className="cv-sub">then it repeats</text>
      )}
      {items.map((it, i) => {
        const w = boxW(it.label);
        return (
          <g key={i} className={`cv-node ${i === active ? 'on' : ''} ${i < active ? 'past' : ''}`} onClick={() => onPick(i)} tabIndex={0} role="button" aria-label={`${i + 1}. ${it.label}`} onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && onPick(i)}>
            <rect x={pos[i].x - w / 2} y={pos[i].y - 19} width={w} height="38" rx="12" />
            <text x={pos[i].x} y={pos[i].y + 5} textAnchor="middle">{it.label}</text>
            {visual.type === 'cycle' && (
              <g>
                <circle cx={pos[i].x - w / 2 + 2} cy={pos[i].y - 17} r="9" className="cv-badge" />
                <text x={pos[i].x - w / 2 + 2} y={pos[i].y - 13} textAnchor="middle" className="cv-badge-text">{i + 1}</text>
              </g>
            )}
          </g>
        );
      })}
    </svg>
  );
}

function Flow({ items, active, onPick }) {
  return (
    <ol className="cv-flow">
      {items.map((it, i) => (
        <li key={i}>
          <button type="button" className={`cv-step ${i === active ? 'on' : ''} ${i < active ? 'past' : ''}`} onClick={() => onPick(i)}>
            <span className="cv-step-num">{i + 1}</span>
            <span>{it.label}</span>
          </button>
          {i < items.length - 1 && <span className="cv-arrow" aria-hidden="true">→</span>}
        </li>
      ))}
    </ol>
  );
}

function Timeline({ items, active, onPick }) {
  return (
    <ol className="cv-timeline">
      {items.map((it, i) => (
        <li key={i} className={`${i === active ? 'on' : ''} ${i < active ? 'past' : ''}`}>
          <button type="button" onClick={() => onPick(i)}>
            <span className="cv-dot" />
            <span className="cv-tl-label">{it.label}</span>
          </button>
        </li>
      ))}
    </ol>
  );
}

function Compare({ visual }) {
  return (
    <div className="cv-compare">
      {visual.columns.map((col, i) => (
        <section key={i} className={`cv-col cv-col-${i}`}>
          <h4>{col.title}</h4>
          <ul>
            {col.points.map((p, j) => (
              <li key={j}>{p}</li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}

// A diagram for topics outside the DSA course. Flow, cycle, timeline and parts can be stepped through.
export default function ConceptVisual({ visual, onDone }) {
  const [active, setActive] = useState(0);
  const [auto, setAuto] = useState(false);
  const items = visual.items || [];
  const stepped = visual.type !== 'compare';

  useEffect(() => {
    if (!auto) return undefined;
    const t = setInterval(() => {
      setActive((a) => {
        if (a >= items.length - 1) {
          setAuto(false);
          return a;
        }
        return a + 1;
      });
    }, 2800);
    return () => clearInterval(t);
  }, [auto, items.length]);

  useEffect(() => {
    if (!stepped) return undefined;
    const onKey = (e) => {
      if (e.target.closest?.('input, textarea, select')) return;
      if (e.key === 'ArrowRight') setActive((a) => Math.min(items.length - 1, a + 1));
      if (e.key === 'ArrowLeft') setActive((a) => Math.max(0, a - 1));
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [stepped, items.length]);

  return (
    <div className="stack-lg fade-in">
      <div className="walk-head">
        <div>
          <h3 className="section-title">{visual.title}</h3>
          {stepped && <p className="muted small">Click a part or use the arrow keys to move through it.</p>}
        </div>
        {stepped && (
          <div className="walk-controls">
            <button type="button" className={`btn btn-ghost btn-sm ${auto ? 'is-on' : ''}`} onClick={() => { if (!auto && active >= items.length - 1) setActive(0); setAuto(!auto); }}>
              {auto ? <PauseIcon size={15} /> : <PlayIcon size={15} />} {auto ? 'Pause' : 'Auto-play'}
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setActive(0); setAuto(false); }}>
              <RefreshIcon size={15} /> Restart
            </button>
          </div>
        )}
      </div>

      <div className={`stage cv-stage cv-${visual.type}`}>
        {visual.type === 'compare' && <Compare visual={visual} />}
        {visual.type === 'flow' && <Flow items={items} active={active} onPick={setActive} />}
        {visual.type === 'timeline' && <Timeline items={items} active={active} onPick={setActive} />}
        {(visual.type === 'cycle' || visual.type === 'parts') && <Radial visual={visual} active={active} onPick={setActive} />}
      </div>

      {stepped && items[active] && (
        <>
          <div className="step-card">
            <div className="step-top">
              <span className="step-badge">{active + 1} of {items.length}: {items[active].label}</span>
            </div>
            <p>{items[active].detail}</p>
          </div>
          <div className="walk-nav">
            <button type="button" className="btn btn-ghost" onClick={() => setActive((a) => Math.max(0, a - 1))} disabled={active === 0}>Previous</button>
            <div className="dots">
              {items.map((_, i) => (
                <button key={i} type="button" className={`dot ${i === active ? 'on' : i < active ? 'past' : ''}`} onClick={() => setActive(i)} aria-label={`Go to part ${i + 1}`} />
              ))}
            </div>
            <button type="button" className="btn btn-primary" onClick={() => (active < items.length - 1 ? setActive(active + 1) : onDone())}>
              {active < items.length - 1 ? 'Next' : 'Take the quiz'}
            </button>
          </div>
        </>
      )}
      {!stepped && (
        <div className="next-row">
          <span />
          <button type="button" className="btn btn-primary" onClick={onDone}>Take the quiz</button>
        </div>
      )}
    </div>
  );
}
