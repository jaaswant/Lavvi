import { useState } from 'react';
import { DownloadIcon, FolderIcon, PlusIcon, PenIcon, TrashIcon, CheckIcon, ChevronIcon, CloseIcon } from './Icons';
import { lessonIdFor } from '../lib/lessons';

// The Subjects page: all subjects as cards, and one subject opened to study its saved topics.
export default function Subjects({ progress, actions, onOpenTopic, loading, selectedId, onSelect }) {
  const { subjects, completed } = progress;
  const [name, setName] = useState('');
  const [topic, setTopic] = useState('');
  const [renaming, setRenaming] = useState(false);
  const [draft, setDraft] = useState('');
  const subject = subjects.find((s) => s.id === selectedId) || null;

  const create = (e) => {
    e.preventDefault();
    const id = actions.addSubject(name);
    if (id) {
      setName('');
      onSelect(id);
    }
  };

  const addTopic = (e) => {
    e.preventDefault();
    const t = topic.trim();
    if (!t) return;
    actions.toggleInSubject(subject.id, { id: lessonIdFor(t), name: t.replace(/^./, (c) => c.toUpperCase()), icon: '📘' });
    setTopic('');
  };

  const exportSubject = () => {
    const md = [
      `# ${subject.name}`,
      '',
      `${subject.topics.length} topics, ${doneCount(subject)} completed.`,
      '',
      ...subject.topics.flatMap((t) => {
        const note = (progress.notes[t.id] || '').trim();
        return [`## ${completed.includes(t.id) ? '✅' : '⬜'} ${t.name}`, '', note || '(no notes yet)', ''];
      })
    ].join('\n');
    const url = URL.createObjectURL(new Blob([md], { type: 'text/markdown' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `${subject.name.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}-notes.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const doneCount = (s) => s.topics.filter((t) => completed.includes(t.id)).length;

  if (!subject) {
    return (
      <div className="subjects fade-in">
        <header className="subjects-head">
          <h1>My subjects</h1>
          <p className="muted">Group the topics you study into subjects. Save any lesson with “Add to subject”, then come back here to study them together.</p>
        </header>

        <form className="subject-new subject-new-big" onSubmit={create}>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name a new subject, e.g. Physics, History, Exam prep" maxLength={40} aria-label="New subject name" />
          <button type="submit" className="btn btn-primary" disabled={!name.trim()}><PlusIcon size={16} /> Create subject</button>
        </form>

        {subjects.length === 0 ? (
          <p className="empty-note">No subjects yet. Create your first one above.</p>
        ) : (
          <div className="subject-grid">
            {subjects.map((s) => (
              <button key={s.id} type="button" className="subject-card" style={{ '--sc': s.color }} onClick={() => onSelect(s.id)}>
                <span className="subject-card-icon"><FolderIcon size={22} /></span>
                <b>{s.name}</b>
                <span className="muted small">{s.topics.length} {s.topics.length === 1 ? 'topic' : 'topics'}{s.topics.length ? `, ${doneCount(s)} done` : ''}</span>
                <span className="subject-bar"><i style={{ width: `${s.topics.length ? (doneCount(s) / s.topics.length) * 100 : 0}%` }} /></span>
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  const next = subject.topics.find((t) => !completed.includes(t.id));

  return (
    <div className="subjects fade-in" style={{ '--sc': subject.color }}>
      <button type="button" className="mini-btn" onClick={() => { setRenaming(false); onSelect(null); }}>← All subjects</button>
      <header className="subjects-head subject-title-row">
        <span className="subject-card-icon"><FolderIcon size={26} /></span>
        {renaming ? (
          <form className="subject-new" onSubmit={(e) => { e.preventDefault(); actions.renameSubject(subject.id, draft); setRenaming(false); }}>
            <input type="text" value={draft} onChange={(e) => setDraft(e.target.value)} maxLength={40} aria-label="Subject name" autoFocus />
            <button type="submit" className="btn btn-primary btn-sm">Save</button>
          </form>
        ) : (
          <h1>{subject.name}</h1>
        )}
        <span className="subject-tools">
          <button type="button" className="icon-btn" onClick={exportSubject} aria-label="Download this subject's notes" title="Download notes (Markdown)"><DownloadIcon size={16} /></button>
          <button type="button" className="icon-btn" onClick={() => { setDraft(subject.name); setRenaming(!renaming); }} aria-label="Rename subject" title="Rename"><PenIcon size={16} /></button>
          <button
            type="button"
            className="icon-btn"
            onClick={() => {
              if (window.confirm(`Delete the subject “${subject.name}”? Your lessons and progress stay safe.`)) {
                actions.deleteSubject(subject.id);
                onSelect(null);
              }
            }}
            aria-label="Delete subject"
            title="Delete"
          >
            <TrashIcon size={16} />
          </button>
        </span>
      </header>

      <p className="muted">{subject.topics.length} {subject.topics.length === 1 ? 'topic' : 'topics'} saved, {doneCount(subject)} completed.</p>
      {next && (
        <button type="button" className="btn btn-primary" onClick={() => onOpenTopic(next.name)} disabled={loading}>
          Study next: {next.name} <ChevronIcon size={16} />
        </button>
      )}

      <form className="subject-new subject-new-big" onSubmit={addTopic}>
        <input type="text" value={topic} onChange={(e) => setTopic(e.target.value)} placeholder={`Add a topic to ${subject.name}, e.g. Newton's laws`} maxLength={80} aria-label="Topic to add" />
        <button type="submit" className="btn btn-ghost" disabled={!topic.trim()}><PlusIcon size={16} /> Add topic</button>
      </form>

      {subject.topics.length === 0 ? (
        <p className="empty-note">Nothing here yet. Add a topic above, or open any lesson and press “Add to subject”.</p>
      ) : (
        <ul className="subject-topics">
          {subject.topics.map((t) => {
            const done = completed.includes(t.id);
            return (
              <li key={t.id}>
                <button type="button" className="subject-topic" onClick={() => onOpenTopic(t.name)} disabled={loading}>
                  <span aria-hidden="true" className="subject-topic-icon">{t.icon}</span>
                  <span className="subject-topic-name">{t.name}</span>
                  {done && <span className="meta meta-done"><CheckIcon size={14} /> Completed</span>}
                  <ChevronIcon size={16} />
                </button>
                <button type="button" className="icon-btn" onClick={() => actions.toggleInSubject(subject.id, t)} aria-label={`Remove ${t.name} from ${subject.name}`} title="Remove from subject"><CloseIcon size={15} /></button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
