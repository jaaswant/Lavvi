import { useState, useRef, useEffect } from 'react';
import Quiz from './Quiz';
import Flashcards from './Flashcards';
import { photoToDataUrl, scanNotes, studyFromNotes, downloadText, slug } from '../lib/ai';
import AiNotice from './AiNotice';
import { useAiServer } from '../lib/ai';
import { DownloadIcon, CopyIcon, CloseIcon, PlusIcon, PenIcon, RefreshIcon } from './Icons';

const MAX_PAGES = 4;

const studyToMarkdown = (title, notes, s) =>
  [
    `# ${title}`,
    '',
    '## Cleaned notes',
    notes,
    '',
    ...(s.summary.length ? ['## Summary', ...s.summary.map((x) => `- ${x}`), ''] : []),
    ...(s.keyTerms.length ? ['## Key terms', ...s.keyTerms.map((t) => `- **${t.term}**: ${t.meaning}`), ''] : []),
    ...(s.difficult.length
      ? ['## Harder parts explained', ...s.difficult.flatMap((d) => [`> ${d.passage}`, '', d.explain, ...(d.example ? ['', `Example: ${d.example}`] : []), ''])]
      : []),
    ...(s.fixes.length ? ['## Check these', ...s.fixes.map((x) => `- ${x}`), ''] : []),
    ...(s.cards.length ? ['## Flashcards', ...s.cards.map((c) => `- Q: ${c.front}\n  A: ${c.back}`), ''] : []),
    ...(s.plan.length ? ['## Revision plan', ...s.plan.map((x, i) => `${i + 1}. ${x}`), ''] : [])
  ].join('\n');

// Photo of handwritten notes -> text -> cleaned notes -> explanations and revision material.
export default function NotesScanner({ award, onBack, onToast }) {
  const { ready: aiOn, status, recheck } = useAiServer();
  const [pages, setPages] = useState([]); // { id, url (data URL), name }
  const [step, setStep] = useState('upload'); // upload | review
  const [busy, setBusy] = useState(''); // '' | reading | studying
  const [error, setError] = useState('');
  const [scan, setScan] = useState(null);
  const [view, setView] = useState('clean'); // clean | written
  const [text, setText] = useState('');
  const [title, setTitle] = useState('');
  const [study, setStudy] = useState(null);
  const [tab, setTab] = useState('revise');
  const [lang, setLang] = useState('english');
  const [known, setKnown] = useState([]);
  const [sel, setSel] = useState('');
  const [explained, setExplained] = useState(null); // { passage, answer, hinglish }
  const [dragging, setDragging] = useState(false);
  const [copied, setCopied] = useState(false);
  const fileRef = useRef(null);
  const taRef = useRef(null);
  const studyRef = useRef(null);
  const awardedScan = useRef(false);
  const awardedStudy = useRef(false);

  useEffect(() => {
    if (study) studyRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [study]);

  const addFiles = async (fileList) => {
    const files = [...fileList];
    if (!files.length) return;
    setError('');
    const room = MAX_PAGES - pages.length;
    if (room <= 0) {
      setError(`You can scan up to ${MAX_PAGES} pages at a time.`);
      return;
    }
    try {
      const made = await Promise.all(
        files.slice(0, room).map(async (f) => ({ id: `${f.name}-${f.size}-${Math.random().toString(36).slice(2, 7)}`, name: f.name, url: await photoToDataUrl(f) }))
      );
      setPages((p) => [...p, ...made]);
      if (files.length > room) setError(`Only the first ${room} photo${room === 1 ? '' : 's'} were added (limit ${MAX_PAGES}).`);
    } catch (e) {
      setError(e.message);
    }
  };

  const read = async () => {
    setError('');
    setBusy('reading');
    try {
      const r = await scanNotes(pages.map((p) => p.url));
      if (!r.readable) {
        setError(r.clean || 'I could not read any writing in that photo. Try a sharper, brighter, flatter picture.');
        return;
      }
      setScan(r);
      setText(r.clean || r.transcript);
      setTitle(r.title);
      setView('clean');
      setStudy(null);
      setExplained(null);
      setStep('review');
      if (!awardedScan.current) {
        awardedScan.current = true;
        award?.(5, 'Scanned notes');
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy('');
    }
  };

  const switchView = (v) => {
    setView(v);
    setText(v === 'clean' ? scan.clean || scan.transcript : scan.transcript || scan.clean);
    setSel('');
  };

  const makeStudy = async () => {
    setError('');
    setBusy('studying');
    try {
      const s = await studyFromNotes(text, title);
      setStudy(s);
      setTab('revise');
      setKnown([]);
      if (!awardedStudy.current) {
        awardedStudy.current = true;
        award?.(10, 'Revision material');
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy('');
    }
  };

  const explainSelection = async () => {
    const passage = sel.trim();
    if (!passage) return;
    setError('');
    setBusy('explaining');
    setExplained(null);
    try {
      const res = await fetch('/api/ask', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ question: `Explain this part of my class notes simply, and say if anything looks wrong: "${passage.slice(0, 300)}"`, topic: title || 'My notes', context: text })
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || 'Could not explain that part.');
      setExplained({ passage, answer: d.answer, hinglish: d.hinglish });
    } catch (e) {
      setError(e.message);
    } finally {
      setBusy('');
    }
  };

  const trackSelection = () => {
    const el = taRef.current;
    if (!el) return;
    setSel(el.value.slice(el.selectionStart, el.selectionEnd));
  };

  const copy = () => {
    navigator.clipboard?.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  };

  const startOver = () => {
    setPages([]);
    setScan(null);
    setStudy(null);
    setExplained(null);
    setText('');
    setSel('');
    setError('');
    setStep('upload');
  };

  const loading = Boolean(busy);

  return (
    <div className="tool fade-in">
      <button type="button" className="back-link" onClick={onBack}>Back to home</button>
      <h1 className="tool-title">Notes scanner</h1>
      <p className="muted tool-sub">Photograph a page of handwritten notes. Lavvi reads it, cleans it up, explains the hard parts and turns it into revision material.</p>

      <AiNotice status={status} onRecheck={recheck} />
      {error && <p className="form-error" role="alert">{error}</p>}

      {step === 'upload' && (
        <div className="stack-lg">
          <div
            className={`dropzone ${dragging ? 'is-over' : ''}`}
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragging(false);
              addFiles(e.dataTransfer.files);
            }}
          >
            <PenIcon size={30} />
            <p><b>Drop photos of your notes here</b></p>
            <p className="muted small">JPG, PNG or WebP. Up to {MAX_PAGES} pages. Good light and a flat page read best.</p>
            <button type="button" className="btn btn-primary" onClick={() => fileRef.current?.click()} disabled={loading || pages.length >= MAX_PAGES}>
              <PlusIcon size={16} /> {pages.length ? 'Add another page' : 'Choose photos'}
            </button>
            <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" multiple hidden onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} />
          </div>

          {pages.length > 0 && (
            <>
              <ul className="thumbs" aria-label="Pages to read">
                {pages.map((p, i) => (
                  <li key={p.id}>
                    <img src={p.url} alt={`Page ${i + 1}: ${p.name}`} />
                    <span className="thumb-n">{i + 1}</span>
                    <button type="button" className="thumb-x" onClick={() => setPages((l) => l.filter((x) => x.id !== p.id))} aria-label={`Remove page ${i + 1}`} disabled={loading}>
                      <CloseIcon size={14} />
                    </button>
                  </li>
                ))}
              </ul>
              <div>
                <button type="button" className="btn btn-primary" onClick={read} disabled={loading || !aiOn}>
                  {busy === 'reading' ? 'Reading your handwriting…' : `Read ${pages.length === 1 ? 'this page' : `these ${pages.length} pages`}`}
                </button>
              </div>
            </>
          )}
          <p className="muted small">Photos are sent to the Lavvi server and on to the AI provider to be read. They are not saved.</p>
        </div>
      )}

      {step === 'review' && scan && (
        <div className="stack-lg">
          <div className="scan-grid">
            <ul className="thumbs thumbs-side" aria-label="Your pages">
              {pages.map((p, i) => (
                <li key={p.id}>
                  <a href={p.url} target="_blank" rel="noreferrer" title="Open full size">
                    <img src={p.url} alt={`Page ${i + 1}`} />
                  </a>
                  <span className="thumb-n">{i + 1}</span>
                </li>
              ))}
            </ul>

            <div className="stack scan-editor">
              <div className="walk-head">
                <label className="field scan-title">
                  <span>Title</span>
                  <input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={100} />
                </label>
                <div className="segmented segmented-sm" role="group" aria-label="Which text to show">
                  <button type="button" className={view === 'clean' ? 'on' : ''} aria-pressed={view === 'clean'} onClick={() => switchView('clean')}>Cleaned up</button>
                  <button type="button" className={view === 'written' ? 'on' : ''} aria-pressed={view === 'written'} onClick={() => switchView('written')}>As written</button>
                </div>
              </div>

              <label className="field">
                <span>
                  {view === 'clean' ? 'Cleaned notes' : 'What the page says'} · edit anything that is wrong{scan.subject ? ` · ${scan.subject}` : ''}
                </span>
                <textarea ref={taRef} className="scan-text" rows={14} value={text} onChange={(e) => setText(e.target.value)} onSelect={trackSelection} onKeyUp={trackSelection} onMouseUp={trackSelection} spellCheck />
              </label>

              {scan.uncertain.length > 0 && (
                <div className="card scan-uncertain">
                  <h3>Check these words</h3>
                  <p className="muted small">I was not fully sure about these. Fix them above if I got them wrong. <code>[?]</code> marks words I could not read.</p>
                  <ul className="plain-list">{scan.uncertain.map((u) => <li key={u}>{u}</li>)}</ul>
                </div>
              )}

              <div className="scan-actions">
                <button type="button" className="btn btn-primary" onClick={makeStudy} disabled={loading || text.trim().length < 20}>
                  {busy === 'studying' ? 'Making your revision material…' : study ? 'Remake revision material' : 'Make revision material'}
                </button>
                <button type="button" className="btn btn-ghost" onClick={explainSelection} disabled={loading || !sel.trim()} title="Select some text in the box first">
                  {busy === 'explaining' ? 'Explaining…' : 'Explain selected text'}
                </button>
                <button type="button" className="btn btn-ghost btn-sm" onClick={copy}><CopyIcon size={15} /> {copied ? 'Copied' : 'Copy'}</button>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => downloadText(`${slug(title)}.md`, `# ${title}\n\n${text}\n`)}>
                  <DownloadIcon size={15} /> Markdown
                </button>
                <button type="button" className="btn btn-ghost btn-sm" onClick={startOver}><RefreshIcon size={15} /> Scan other notes</button>
              </div>
              <p className="muted small">Tip: select a sentence or paragraph in the box and press “Explain selected text”.</p>

              {explained && (
                <div className="card fade-in" aria-live="polite">
                  <h3>Explained</h3>
                  <blockquote className="passage">{explained.passage}</blockquote>
                  <p>{explained.answer}</p>
                  {explained.hinglish && <p lang="hi-Latn" className="muted">{explained.hinglish}</p>}
                </div>
              )}
            </div>
          </div>

          {study && (
            <div className="stack-lg fade-in" ref={studyRef}>
              <div className="walk-head">
                <div>
                  <h2 className="section-title">Revision material</h2>
                  <p className="muted small">Made from your notes{study.quiz.length ? `: ${study.cards.length} flashcards and a ${study.quiz.length}-question quiz` : ''}.</p>
                </div>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => downloadText(`${slug(title)}-revision.md`, studyToMarkdown(title, text, study))}>
                  <DownloadIcon size={15} /> Download all (Markdown)
                </button>
              </div>

              <div className="segmented" role="tablist" aria-label="Revision views">
                {[['revise', 'Summary'], ['explain', 'Hard parts'], ['cards', 'Flashcards'], ['quiz', 'Quiz']].map(([id, label]) => (
                  <button key={id} type="button" role="tab" aria-selected={tab === id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}
                    disabled={(id === 'cards' && !study.cards.length) || (id === 'quiz' && !study.quiz.length)}>
                    {label}
                  </button>
                ))}
              </div>

              {tab === 'revise' && (
                <div className="stack-lg">
                  {study.summary.length > 0 && (
                    <div className="card"><h3>In a nutshell</h3><ul className="plain-list">{study.summary.map((x) => <li key={x}>{x}</li>)}</ul></div>
                  )}
                  {study.keyTerms.length > 0 && (
                    <div className="card">
                      <h3>Key terms</h3>
                      <dl className="terms">{study.keyTerms.map((t) => <div key={t.term}><dt>{t.term}</dt><dd>{t.meaning}</dd></div>)}</dl>
                    </div>
                  )}
                  {study.fixes.length > 0 && (
                    <div className="card scan-uncertain"><h3>Double-check these</h3><ul className="plain-list">{study.fixes.map((x) => <li key={x}>{x}</li>)}</ul></div>
                  )}
                  {study.plan.length > 0 && (
                    <div className="card"><h3>Revision plan</h3><ol className="plain-list">{study.plan.map((x) => <li key={x}>{x}</li>)}</ol></div>
                  )}
                </div>
              )}

              {tab === 'explain' && (
                <div className="stack-lg">
                  <div className="segmented segmented-sm" role="group" aria-label="Language of the explanations">
                    <button type="button" className={lang === 'english' ? 'on' : ''} aria-pressed={lang === 'english'} onClick={() => setLang('english')}>English</button>
                    <button type="button" className={lang === 'hinglish' ? 'on' : ''} aria-pressed={lang === 'hinglish'} onClick={() => setLang('hinglish')}>Hinglish</button>
                  </div>
                  {study.difficult.length === 0 && <p className="muted">Nothing here looked especially hard. You can still select any text above and press “Explain selected text”.</p>}
                  {study.difficult.map((d) => (
                    <article className="card" key={d.passage}>
                      <blockquote className="passage">{d.passage}</blockquote>
                      <p lang={lang === 'hinglish' ? 'hi-Latn' : 'en'}>{lang === 'hinglish' && d.hinglish ? d.hinglish : d.explain}</p>
                      {d.example && <p className="muted"><b>Example:</b> {d.example}</p>}
                    </article>
                  ))}
                </div>
              )}

              {tab === 'cards' && <Flashcards cards={study.cards} known={known} onKnown={setKnown} onAward={award} title={title} />}

              {tab === 'quiz' && (
                <Quiz
                  questions={study.quiz}
                  title={title}
                  onFinish={({ score, total, first }) => {
                    if (!first) return;
                    const xp = score * 10 + (score === total ? 20 : 0);
                    if (xp) award?.(xp, score === total ? 'Perfect quiz' : 'Quiz');
                    onToast?.(`${score}/${total} on your notes quiz`);
                  }}
                />
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
