import { useState, useEffect, useMemo, useCallback } from 'react';
import { prepareQuestions } from '../lib/quiz';
import { CheckIcon, RefreshIcon } from './Icons';

// Multiple choice quiz. Used for lesson quizzes and for the daily challenge.
// One answer per question, then the explanation. Results show at the end.
export default function Quiz({ questions, title, onFinish, isCompleted, onComplete, showTopic = false }) {
  const [attempt, setAttempt] = useState(0);
  const [pool, setPool] = useState(questions);
  const set = useMemo(() => prepareQuestions(pool), [pool, attempt]); // eslint-disable-line react-hooks/exhaustive-deps
  const [i, setI] = useState(0);
  const [picked, setPicked] = useState(null);
  const [results, setResults] = useState([]); // true or false per question
  const [showResults, setShowResults] = useState(false);

  const q = set[i];
  const answered = picked !== null;

  const choose = useCallback(
    (n) => {
      if (answered || !q || !q.options[n]) return;
      setPicked(n);
      setResults((r) => [...r, q.options[n].isCorrect]);
    },
    [answered, q]
  );

  const next = useCallback(() => {
    if (i + 1 < set.length) {
      setI(i + 1);
      setPicked(null);
    }
  }, [i, set.length]);

  const score = results.filter(Boolean).length;
  const finished = showResults && set.length > 0;

  useEffect(() => {
    if (finished) onFinish?.({ score, total: set.length, first: attempt === 0 });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [finished]);

  // 1 to 4 (or A to D) answers, Enter goes on
  useEffect(() => {
    const onKey = (e) => {
      if (e.target.closest?.('input, textarea, select') || e.metaKey || e.ctrlKey) return;
      if (finished) return;
      const k = e.key.toLowerCase();
      let idx = '1234'.indexOf(k);
      if (idx < 0) idx = 'abcd'.indexOf(k);
      if (k.length === 1 && idx >= 0) choose(idx);
      else if (e.key === 'Enter' && answered && !e.target.closest?.('button')) (i + 1 < set.length ? next() : setShowResults(true));
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [choose, next, answered, finished, i, set.length]);

  const restart = (wrongOnly) => {
    if (wrongOnly) {
      const missed = set.filter((_, n) => !results[n]).map(({ id, ...rest }) => rest); // eslint-disable-line no-unused-vars
      setPool(missed);
    } else {
      setPool(questions);
    }
    setAttempt((a) => a + 1);
    setI(0);
    setPicked(null);
    setResults([]);
    setShowResults(false);
  };

  if (!q) return <p className="muted">No questions yet.</p>;

  if (finished) {
    const pct = Math.round((score / set.length) * 100);
    const message = pct === 100 ? 'Perfect score.' : pct >= 60 ? 'Good work. Look at the ones you missed.' : 'Worth another go. Read the explanations first.';
    return (
      <section className="card quiz fade-in" aria-label="Quiz results">
        <h3 className="quiz-score">
          <span className="quiz-score-num">{score}<small>/{set.length}</small></span>
          <span>{message}</span>
        </h3>
        {attempt > 0 && <p className="muted small">Practice runs after the first one don't earn XP.</p>}
        <ol className="review">
          {set.map((s, n) => (
            <li key={n} className={results[n] ? 'ok' : 'miss'}>
              <span className="review-mark" aria-label={results[n] ? 'Correct' : 'Missed'}>{results[n] ? <CheckIcon size={14} /> : '✕'}</span>
              <div>
                <p>{s.question}</p>
                {!results[n] && <p className="review-answer">Answer: {s.options.find((o) => o.isCorrect)?.text}</p>}
              </div>
            </li>
          ))}
        </ol>
        <div className="quiz-actions">
          {score < set.length && (
            <button type="button" className="btn btn-primary" onClick={() => restart(true)}>
              <RefreshIcon size={16} /> Retry the {set.length - score} I missed
            </button>
          )}
          <button type="button" className="btn btn-ghost" onClick={() => restart(false)}>Start again</button>
          {onComplete && pct >= 60 && (
            <button type="button" className={`btn ${isCompleted ? 'btn-done' : 'btn-outline'}`} onClick={onComplete}>
              {isCompleted ? 'Lesson completed' : 'Mark lesson as complete'}
            </button>
          )}
        </div>
      </section>
    );
  }

  const correct = answered && q.options[picked].isCorrect;
  return (
    <section className="card quiz fade-in" aria-label="Quiz">
      <div className="quiz-top">
        <span className="quiz-title">{title}</span>
        <span className="quiz-count">Question {i + 1} of {set.length}</span>
      </div>
      <div className="quiz-bar" aria-hidden="true">
        {set.map((_, n) => (
          <span key={n} className={n < results.length ? (results[n] ? 'ok' : 'miss') : n === i ? 'now' : ''} />
        ))}
      </div>

      {showTopic && q.topic && <p className="quiz-topic">{q.topic}</p>}
      <h3 className="quiz-q">{q.question}</h3>

      <div className="options" role="radiogroup" aria-label="Answer options">
        {q.options.map((opt, n) => {
          let state = '';
          if (answered && opt.isCorrect) state = 'correct';
          else if (answered && picked === n) state = 'wrong';
          return (
            <button key={n} type="button" role="radio" aria-checked={picked === n} className={`option ${state}`} onClick={() => choose(n)} disabled={answered}>
              <span className="option-letter">{String.fromCharCode(65 + n)}</span>
              <span>{opt.text}</span>
            </button>
          );
        })}
      </div>

      {answered && (
        <div className={`feedback ${correct ? 'ok' : 'retry'}`} role="status">
          <strong>{correct ? 'Correct.' : 'Not quite.'}</strong>
          {q.explanation && <p>{q.explanation}</p>}
          {i + 1 < set.length ? (
            <button type="button" className="btn btn-primary" onClick={next}>Next question</button>
          ) : (
            <button type="button" className="btn btn-primary" onClick={() => setShowResults(true)}>See my results</button>
          )}
        </div>
      )}
      {!answered && <p className="muted small hint">Tip: press 1 to 4 to answer.</p>}
    </section>
  );
}
