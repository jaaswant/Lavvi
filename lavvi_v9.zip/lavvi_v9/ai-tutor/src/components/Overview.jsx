import { useState } from 'react';
import { MENTOR_TIPS } from '../data/topicsData';
import { labelize } from '../lib/quiz';

export default function Overview({ topic, nextLabel, onNext, onOpenTopic }) {
  const [tipIndex, setTipIndex] = useState(0);
  const c = topic.concept;
  const facts = Object.entries(c.complexities || {});

  return (
    <div className="stack-lg fade-in">
      <section className="callout">
        <h3 className="section-title">In one line</h3>
        {topic.image && (
          <figure className="lesson-thumb">
            <img src={topic.image} alt={`${topic.name}, small illustration from Wikipedia`} loading="lazy" />
          </figure>
        )}
        <p className="callout-quote"><mark>{c.tagline}</mark></p>
        {c.realLifeAnalogy && (
          <div className="callout-body">
            <h4>A real-life way to picture it</h4>
            {c.realLifeAnalogy.split('\n').map((line, i) => (
              <p key={i}>{line}</p>
            ))}
          </div>
        )}
      </section>

      <div className="grid-2">
        <section className="card">
          <h3>What is it?</h3>
          <p>{c.whatIsIt}</p>
          {c.whyUse.length > 0 && (
            <>
              <h4>{topic.builtin ? 'Why use it' : 'Key points'}</h4>
              <ul className="check-list">
                {c.whyUse.map((point, i) => (
                  <li key={i}>{point}</li>
                ))}
              </ul>
            </>
          )}
        </section>

        {(c.limitations.length > 0 || facts.length > 0) && (
          <section className="card">
            {c.limitations.length > 0 && (
              <>
                <h3>{topic.builtin ? 'Limitations' : 'Watch out for'}</h3>
                <ul className="warn-list">
                  {c.limitations.map((item, i) => (
                    <li key={i}>{item}</li>
                  ))}
                </ul>
              </>
            )}
            {facts.length > 0 && (
              <>
                <h4>{topic.builtin ? 'Time and space complexity' : 'Key facts'}</h4>
                <dl className="complexity">
                  {facts.map(([key, val]) => (
                    <div key={key} className="complexity-row">
                      <dt>{labelize(key)}</dt>
                      <dd>{val}</dd>
                    </div>
                  ))}
                </dl>
              </>
            )}
          </section>
        )}
      </div>

      {topic.related?.length > 0 && (
        <section className="related">
          <h3 className="section-title">Explore next</h3>
          <div className="chips">
            {topic.related.map((name) => (
              <button key={name} type="button" className="chip" onClick={() => onOpenTopic(name)}>{name}</button>
            ))}
          </div>
        </section>
      )}

      {topic.sources?.length > 0 && (
        <p className="muted sources">
          Sources:{' '}
          {topic.sources.map((s) => (
            <a key={s.url} href={s.url} target="_blank" rel="noreferrer">{s.title}</a>
          ))}
        </p>
      )}

      {topic.builtin && (
        <section className="tip">
          <div>
            <h3 className="section-title">Mentor tip</h3>
            <p>{MENTOR_TIPS[tipIndex]}</p>
          </div>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setTipIndex((i) => (i + 1) % MENTOR_TIPS.length)}>
            Another tip
          </button>
        </section>
      )}

      {nextLabel && (
        <div className="next-row">
          <span>Next up: {nextLabel.toLowerCase()}.</span>
          <button type="button" className="btn btn-primary" onClick={onNext}>{nextLabel}</button>
        </div>
      )}
    </div>
  );
}
