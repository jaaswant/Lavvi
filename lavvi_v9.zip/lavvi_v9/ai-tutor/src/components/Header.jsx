import SearchBar from './SearchBar';
import StudyTimer from './StudyTimer';
import ProgressRing from './ProgressRing';
import { FlameIcon, SunIcon, MoonIcon, BoltIcon, FolderIcon, CompareIcon, ScanIcon } from './Icons';
import { levelInfo } from '../lib/progress';

export default function Header({
  onHome,
  onSearch,
  onChallenge,
  onSubjects,
  onCompare,
  onScan,
  subjectCount,
  loading,
  query,
  showSearch,
  suggestions,
  progress,
  dailyDone,
  theme,
  onToggleTheme,
  onFocusDone
}) {
  const lv = levelInfo(progress.xp);
  return (
    <header className="topbar">
      <button type="button" className="brand" onClick={onHome} aria-label="Lavvi, back to home">
        <span className="brand-mark" aria-hidden="true">
          <svg viewBox="0 0 32 32" width="32" height="32">
            <rect x="2" y="2" width="28" height="28" rx="8" fill="currentColor" />
            <path d="M11 8v13.5a1 1 0 0 0 1 1h9" stroke="var(--hl)" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            <circle cx="21.5" cy="10.5" r="2.4" fill="var(--hl)" />
          </svg>
        </span>
        <span className="brand-name">Lavvi</span>
      </button>

      {showSearch && (
        <div className="topbar-search">
          <SearchBar key={query} onSearch={onSearch} loading={loading} initialValue={query} size="small" placeholder="Search any topic" suggestions={suggestions} />
        </div>
      )}

      <div className="topbar-tools">
        <button type="button" className="chip-btn" onClick={onCompare} title="Compare any two concepts side by side">
          <CompareIcon size={16} />
          <span className="hide-sm">Compare</span>
        </button>
        <button type="button" className="chip-btn" onClick={onScan} title="Scan handwritten notes and turn them into revision material">
          <ScanIcon size={16} />
          <span className="hide-sm">Scan notes</span>
        </button>
        <button type="button" className="chip-btn" onClick={onSubjects} title="Your subjects and the topics saved in them">
          <FolderIcon size={16} />
          <span className="hide-sm">Subjects{subjectCount > 0 ? ` (${subjectCount})` : ''}</span>
        </button>
        <button type="button" className={`chip-btn ${dailyDone ? '' : 'attention'}`} onClick={onChallenge} title="Five mixed questions, new every day">
          <BoltIcon size={16} />
          <span className="hide-sm">{dailyDone ? 'Daily challenge done' : 'Daily challenge'}</span>
        </button>
        <span className="stat" title={`${progress.streak.count} day study streak`}>
          <FlameIcon size={17} />
          <b>{progress.streak.count}</b>
        </span>
        <span className="stat stat-level" title={`${progress.xp} XP in total. ${lv.size - lv.into} XP to level ${lv.level + 1}.`}>
          <ProgressRing value={lv.into} max={lv.size} size={30} stroke={4} label={`Level ${lv.level}`}>
            <span className="ring-num">{lv.level}</span>
          </ProgressRing>
          <span className="hide-sm">{lv.title}</span>
        </span>
        <StudyTimer sessions={progress.focusSessions} onFocusDone={onFocusDone} />
        <button type="button" className="icon-btn" onClick={onToggleTheme} aria-label={theme === 'dark' ? 'Switch to the light notebook theme' : 'Switch to the dark blackboard theme'} title={theme === 'dark' ? 'Notebook theme' : 'Blackboard theme'}>
          {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
        </button>
      </div>
    </header>
  );
}
