// Explains why the AI tools are not ready, and how to fix it.
export default function AiNotice({ status, onRecheck }) {
  if (status === 'ok') return null;
  if (status === 'checking') return <p className="muted" role="status">Checking the Lavvi server…</p>;
  return (
    <div className="form-error ai-notice" role="alert">
      {status === 'unreachable' ? (
        <>
          <b>Can't reach the Lavvi server.</b>
          <p>
            In the <code>ai-tutor</code> folder, run <code>npm run dev</code> for development or <code>npm start</code> for production.
            Both commands start the API automatically. Open the local address printed in the terminal.
          </p>
        </>
      ) : (
        <>
          <b>The server is running, but it has no API key.</b>
          <p>
            Put <code>GEMINI_API_KEY=your-key</code> in the <code>.env</code> file inside the <code>ai-tutor</code> folder (next to <code>package.json</code>),
            then stop the server (Ctrl+C) and start it again. Run <code>npm run check</code> to test the key.
          </p>
        </>
      )}
      <button type="button" className="btn btn-ghost btn-sm" onClick={onRecheck}>Check again</button>
    </div>
  );
}
