import { useState, useRef, useEffect } from 'react';
import { FolderIcon, PlusIcon, CheckIcon } from './Icons';

// "Add to subject" button on a lesson. Opens a small list of the learner's subjects to save the lesson into.
export default function SubjectPicker({ lesson, subjects, onToggle, onCreate }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const boxRef = useRef(null);
  const inLists = subjects.filter((s) => s.topics.some((t) => t.id === lesson.id));

  useEffect(() => {
    if (!open) return undefined;
    const close = (e) => {
      if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false);
    };
    const esc = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', esc);
    return () => {
      document.removeEventListener('mousedown', close);
      document.removeEventListener('keydown', esc);
    };
  }, [open]);

  const create = (e) => {
    e.preventDefault();
    const id = onCreate(name);
    if (id) {
      onToggle(id, lesson); // state updates apply in order, so the new subject already exists
      setName('');
    }
  };

  return (
    <div className="subject-picker" ref={boxRef}>
      <button type="button" className={`btn btn-ghost ${inLists.length ? 'is-on' : ''}`} onClick={() => setOpen(!open)} aria-expanded={open} aria-haspopup="true">
        <FolderIcon size={16} /> {inLists.length ? `In ${inLists.length === 1 ? inLists[0].name : `${inLists.length} subjects`}` : 'Add to subject'}
      </button>
      {open && (
        <div className="subject-pop" role="dialog" aria-label="Save this lesson in a subject">
          <p className="subject-pop-title">Save “{lesson.name}” in a subject</p>
          {subjects.length === 0 && <p className="muted small">You have no subjects yet. Create one below, like “Physics” or “Exam prep”.</p>}
          <ul className="subject-pop-list">
            {subjects.map((s) => {
              const on = s.topics.some((t) => t.id === lesson.id);
              return (
                <li key={s.id}>
                  <button type="button" className={`subject-opt ${on ? 'on' : ''}`} onClick={() => onToggle(s.id, lesson)} aria-pressed={on}>
                    <span className="subject-dot" style={{ background: s.color }} />
                    <span className="subject-opt-name">{s.name}</span>
                    <span className="subject-opt-count">{s.topics.length}</span>
                    {on && <CheckIcon size={16} />}
                  </button>
                </li>
              );
            })}
          </ul>
          <form className="subject-new" onSubmit={create}>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="New subject name" maxLength={40} aria-label="New subject name" />
            <button type="submit" className="btn btn-primary btn-sm" disabled={!name.trim()}><PlusIcon size={15} /> Create</button>
          </form>
        </div>
      )}
    </div>
  );
}
