import { useMemo } from 'react';
import Quiz from './Quiz';
import { BUILTIN_TOPICS } from '../lib/lessons';
import { dailyChallenge } from '../lib/quiz';
import { dayKey } from '../lib/progress';
import { BoltIcon } from './Icons';

// Five questions mixed from the whole DSA course. The same set all day.
export default function Challenge({ doneToday, onFinish, onBack }) {
  const day = dayKey();
  const questions = useMemo(() => dailyChallenge(BUILTIN_TOPICS, day), [day]);

  return (
    <div className="challenge">
      <button type="button" className="back-link" onClick={onBack}>Back to home</button>
      <h1 className="challenge-title"><BoltIcon size={30} /> Daily challenge</h1>
      <p className="muted">
        {doneToday
          ? 'You finished today\'s challenge. You can play it again for practice, but it will not earn more XP. A new set arrives tomorrow.'
          : 'Five questions from across the DSA course. Finish them to earn 30 bonus XP, plus 10 XP for every right answer.'}
      </p>
      <Quiz questions={questions} title="Today's questions" showTopic onFinish={onFinish} />
    </div>
  );
}
