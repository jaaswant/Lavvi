// Lavvi, an illustrated Indian male teacher. The mouth moves while he speaks and his eyes blink.
export default function TeacherAvatar({ speaking }) {
  return (
    <svg className={`avatar ${speaking ? 'talking' : ''}`} viewBox="0 0 200 200" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Lavvi, your AI teacher">
      <defs>
        <linearGradient id="av-bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#1d3a31" />
          <stop offset="1" stopColor="#2f5a49" />
        </linearGradient>
        <linearGradient id="av-shirt" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f2efe6" />
          <stop offset="1" stopColor="#d9d4c4" />
        </linearGradient>
      </defs>

      <rect width="200" height="200" fill="url(#av-bg)" />
      <g fill="none" stroke="#eaf2e6" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" opacity="0.28">
        <path d="M12 30h28M12 40h18" />
        <rect x="150" y="22" width="12" height="12" />
        <rect x="166" y="22" width="12" height="12" />
        <path d="M162 28h4M178 28l8 0" />
        <path d="M14 70q6-10 12 0t12 0" />
        <circle cx="172" cy="64" r="8" />
        <path d="M172 72v8M168 80h8" />
      </g>
      <text x="14" y="58" fontFamily="monospace" fontSize="13" fill="#f4d35e" opacity="0.55">E = mc²</text>
      <text x="150" y="104" fontFamily="monospace" fontSize="11" fill="#8ec5ff" opacity="0.5">π ≈ 3.14</text>

      {/* shoulders: a light kurta with a small collar and a dark waistcoat */}
      <path d="M18 200c4-38 34-54 82-54s78 16 82 54z" fill="url(#av-shirt)" />
      <path d="M62 152l38 22 38-22 14 48H48z" fill="#2b3a67" opacity="0.92" />
      <path d="M88 148l12 16 12-16" fill="#d9d4c4" stroke="#b9b29c" strokeWidth="1.5" />
      <circle cx="100" cy="180" r="2.4" fill="#f4d35e" />
      <circle cx="100" cy="190" r="2.4" fill="#f4d35e" />

      <g className="av-head">
        <rect x="86" y="122" width="28" height="30" rx="10" fill="#a8683f" />
        <ellipse cx="55" cy="97" rx="7" ry="11" fill="#b9774a" />
        <ellipse cx="145" cy="97" rx="7" ry="11" fill="#b9774a" />
        {/* face */}
        <ellipse cx="100" cy="94" rx="45" ry="53" fill="#c98a5c" />
        {/* short neat black hair */}
        <path d="M53 88c-7-42 18-64 48-64 34 0 56 22 47 64-3-16-10-27-24-32-16 6-40 6-58 0-8 8-11 20-13 32z" fill="#14100e" />
        {/* eyebrows */}
        <path d="M68 80q11-7 22-1" stroke="#14100e" strokeWidth="4.5" strokeLinecap="round" fill="none" />
        <path d="M110 79q11-6 22 1" stroke="#14100e" strokeWidth="4.5" strokeLinecap="round" fill="none" />
        {/* eyes */}
        <g className="av-eyes">
          <ellipse cx="80" cy="94" rx="5.2" ry="5.6" fill="#1a1412" />
          <ellipse cx="120" cy="94" rx="5.2" ry="5.6" fill="#1a1412" />
          <circle cx="81.5" cy="92" r="1.6" fill="#fff" />
          <circle cx="121.5" cy="92" r="1.6" fill="#fff" />
        </g>
        {/* glasses */}
        <g fill="none" stroke="#2a2a2a" strokeWidth="2.8">
          <rect x="63" y="83" width="35" height="24" rx="9" />
          <rect x="102" y="83" width="35" height="24" rx="9" />
          <path d="M98 93h4" />
          <path d="M63 91l-8-2M137 91l8-2" />
        </g>
        {/* nose */}
        <path d="M100 98q-5 14-2 18 4 3 8 0" stroke="#9a6139" strokeWidth="3" strokeLinecap="round" fill="none" />
        {/* moustache */}
        <path d="M80 123c6-7 14-8 20-3 6-5 14-4 20 3-8 2-14 1-20-2-6 3-12 4-20 2z" fill="#14100e" />
        {/* mouth */}
        {speaking ? (
          <ellipse className="av-mouth" cx="100" cy="134" rx="11" ry="7" fill="#4a1a17" />
        ) : (
          <path d="M88 133q12 8 24 0" stroke="#5a2420" strokeWidth="3.5" strokeLinecap="round" fill="none" />
        )}
      </g>
    </svg>
  );
}
