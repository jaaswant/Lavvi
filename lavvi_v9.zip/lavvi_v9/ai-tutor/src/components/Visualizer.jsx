// Renders the graphic for one step of a topic's visual walkthrough.
export default function Visualizer({ topicId, step }) {
  if (topicId === 'arrays' && step.elements) {
    return (
      <div className="viz viz-array" aria-label="Array">
        {step.elements.map((item, i) => (
          <div key={i} className={`array-cell state-${item.state}`}>
            <span className="array-addr">{item.addr}</span>
            <span className="array-val">{item.val}</span>
            <span className="array-idx">[{item.index}]</span>
            {item.state === 'inserted' && <span className="cell-tag">New</span>}
            {item.state === 'shifted' && <span className="cell-tag">Shifted</span>}
          </div>
        ))}
      </div>
    );
  }

  if (topicId === 'linked-lists' && step.nodes) {
    return (
      <div className="viz viz-list" aria-label="Linked list">
        {step.nodes.map((node, i) => (
          <div key={node.id} className="ll-item">
            <div className="ll-col">
              <span className="head-tag">{node.isHead ? 'HEAD' : ''}</span>
              <div className={`ll-node state-${node.state}`}>
                <div className="ll-part">
                  <small>Data</small>
                  <b>{node.val}</b>
                </div>
                <div className="ll-part">
                  <small>Next</small>
                  <b>{node.nextVal}</b>
                </div>
              </div>
            </div>
            {i < step.nodes.length - 1 && <span className="ll-arrow">→</span>}
          </div>
        ))}
      </div>
    );
  }

  if (topicId === 'stacks' && step.stackItems !== undefined) {
    return (
      <div className="viz viz-stack" aria-label="Stack">
        <div className="stack-box">
          {step.stackItems.length === 0 ? (
            <div className="viz-empty">Empty stack (TOP = -1)</div>
          ) : (
            step.stackItems.map((val, i) => (
              <div key={i} className={`stack-item ${i === 0 ? 'top' : ''}`}>
                {val}
                {i === 0 && <span className="stack-top-tag">TOP</span>}
              </div>
            ))
          )}
        </div>
        <span className="viz-caption">Items enter and leave from the top only</span>
      </div>
    );
  }

  if (topicId === 'queues' && step.queueItems !== undefined) {
    const items = step.queueItems;
    return (
      <div className="viz viz-queue" aria-label="Queue">
        <span className="queue-end">Front (dequeue)</span>
        <div className="queue-row">
          {items.length === 0 ? (
            <div className="viz-empty">Queue is empty</div>
          ) : (
            items.map((item, i) => (
              <div key={i} className={`queue-item ${i === 0 ? 'front' : ''}`}>
                <b>{item}</b>
                <small>
                  {i === 0 && 'FRONT'}
                  {i === 0 && i === items.length - 1 && ' · '}
                  {i === items.length - 1 && 'REAR'}
                </small>
              </div>
            ))
          )}
        </div>
        <span className="queue-end">Rear (enqueue)</span>
      </div>
    );
  }

  if (topicId === 'recursion' && step.callStack) {
    return (
      <div className="viz viz-calls" aria-label="Call stack">
        <span className="viz-caption">Call stack (top of the stack first)</span>
        {step.callStack.map((frame, i) => (
          <div key={i} className={`call-frame ${i === 0 ? 'active' : ''}`}>
            <code>{frame.func}</code>
            <span className="call-state">{frame.state}</span>
            <span className="call-val">{frame.val}</span>
          </div>
        ))}
      </div>
    );
  }

  if (topicId === 'sorting' && step.elements) {
    return (
      <div className="viz viz-bars" aria-label="Sorting bars">
        {step.elements.map((el, i) => (
          <div key={i} className="sort-col">
            <div className={`sort-bar state-${el.state}`} style={{ height: `${Math.max(48, el.val * 36)}px` }}>
              <b>{el.val}</b>
            </div>
            <small>{el.state}</small>
          </div>
        ))}
      </div>
    );
  }

  return null;
}
