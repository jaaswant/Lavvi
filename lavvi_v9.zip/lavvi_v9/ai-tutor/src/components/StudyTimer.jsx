import { useState, useEffect, useRef } from 'react';
import { TimerIcon, PlayIcon, PauseIcon, RefreshIcon } from './Icons';
import ProgressRing from './ProgressRing';

const MODES = { focus: { label: 'Focus', minutes: 25 }, rest: { label: 'Break', minutes: 5 } };

function beep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = 660;
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.9);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 1);
  } catch {
    /* audio is optional */
  }
}

const fmt = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

// A Pomodoro timer: 25 minutes of focus, 5 of rest. Finished focus sessions earn XP.
export default function StudyTimer({ sessions, onFocusDone }) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState('focus');
  const [left, setLeft] = useState(MODES.focus.minutes * 60);
  const [running, setRunning] = useState(false);
  const endRef = useRef(0);
  const doneCb = useRef(onFocusDone);
  const wrapRef = useRef(null);

  useEffect(() => {
    doneCb.current = onFocusDone;
  }, [onFocusDone]);

  useEffect(() => {
    if (!running) return undefined;
    const tick = () => {
      const remaining = Math.max(0, Math.round((endRef.current - Date.now()) / 1000));
      setLeft(remaining);
      if (remaining === 0) {
        setRunning(false);
        beep();
        if (mode === 'focus') doneCb.current?.();
        const next = mode === 'focus' ? 'rest' : 'focus';
        setMode(next);
        setLeft(MODES[next].minutes * 60);
      }
    };
    const id = setInterval(tick, 500);
    return () => clearInterval(id);
  }, [running, mode]);

  useEffect(() => {
    const base = 'Lavvi';
    document.title = running ? `${fmt(left)} · ${MODES[mode].label} · ${base}` : document.title.replace(/^\d\d:\d\d · \w+ · /, '');
    return undefined;
  }, [running, left, mode]);

  useEffect(() => {
    if (!open) return undefined;
    const close = (e) => {
      if (!wrapRef.current?.contains(e.target)) setOpen(false);
    };
    const esc = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', esc);
    return () => {
      document.removeEventListener('mousedown', close);
      document.removeEventListener('keydown', esc);
    };
  }, [open]);

  const toggle = () => {
    if (!running) endRef.current = Date.now() + left * 1000;
    setRunning(!running);
  };
  const reset = (m = mode) => {
    setRunning(false);
    setMode(m);
    setLeft(MODES[m].minutes * 60);
  };

  return (
    <div className="popwrap" ref={wrapRef}>
      <button type="button" className={`icon-btn ${running ? 'is-live' : ''}`} onClick={() => setOpen(!open)} aria-expanded={open} aria-label="Study timer" title="Study timer">
        <TimerIcon />
        {running && <span className="icon-btn-text">{fmt(left)}</span>}
      </button>
      {open && (
        <div className="popover timer-pop" role="dialog" aria-label="Study timer">
          <div className="segmented" role="group" aria-label="Timer mode">
            {Object.entries(MODES).map(([id, m]) => (
              <button key={id} type="button" className={mode === id ? 'on' : ''} aria-pressed={mode === id} onClick={() => reset(id)}>
                {m.label} {m.minutes}m
              </button>
            ))}
          </div>
          <ProgressRing value={MODES[mode].minutes * 60 - left} max={MODES[mode].minutes * 60} size={132} stroke={8} label="Time left">
            <span className="timer-time">{fmt(left)}</span>
          </ProgressRing>
          <div className="timer-actions">
            <button type="button" className="btn btn-primary" onClick={toggle}>
              {running ? <PauseIcon size={16} /> : <PlayIcon size={16} />} {running ? 'Pause' : 'Start'}
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => reset()} aria-label="Reset timer">
              <RefreshIcon size={16} /> Reset
            </button>
          </div>
          <p className="muted small">{sessions} focus {sessions === 1 ? 'session' : 'sessions'} finished. Each one earns 15 XP.</p>
        </div>
      )}
    </div>
  );
}
