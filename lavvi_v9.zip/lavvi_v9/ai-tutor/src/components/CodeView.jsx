import { useState } from 'react';
import { highlight } from '../lib/highlight';
import { runJavaScript } from '../lib/runner';
import { CopyIcon, PlayIcon, DownloadIcon } from './Icons';

const LANGUAGES = [
  { id: 'javascript', label: 'JavaScript', ext: 'js' },
  { id: 'python', label: 'Python', ext: 'py' },
  { id: 'cpp', label: 'C++', ext: 'cpp' }
];

export default function CodeView({ topic }) {
  const [language, setLanguage] = useState('javascript');
  const [copied, setCopied] = useState(false);
  const [output, setOutput] = useState(null);
  const [running, setRunning] = useState(false);

  const code = topic.codeSnippets[language] || '';
  const lang = LANGUAGES.find((l) => l.id === language);

  const copy = () => {
    navigator.clipboard?.writeText(code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  };

  const download = () => {
    const url = URL.createObjectURL(new Blob([code], { type: 'text/plain' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `${topic.id}.${lang.ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const run = async () => {
    setRunning(true);
    setOutput(await runJavaScript(code));
    setRunning(false);
  };

  return (
    <div className="stack-lg fade-in">
      <div className="code-bar">
        <div className="segmented" role="group" aria-label="Programming language">
          {LANGUAGES.map((l) => (
            <button key={l.id} type="button" className={language === l.id ? 'on' : ''} aria-pressed={language === l.id} onClick={() => { setLanguage(l.id); setOutput(null); }}>
              {l.label}
            </button>
          ))}
        </div>
        <div className="walk-controls">
          <button type="button" className="btn btn-ghost btn-sm" onClick={copy}><CopyIcon size={15} /> {copied ? 'Copied' : 'Copy'}</button>
          <button type="button" className="btn btn-ghost btn-sm" onClick={download}><DownloadIcon size={15} /> Download</button>
          {language === 'javascript' && (
            <button type="button" className="btn btn-primary btn-sm" onClick={run} disabled={running}><PlayIcon size={15} /> {running ? 'Running…' : 'Run code'}</button>
          )}
        </div>
      </div>

      <div className="code-window">
        <div className="code-file">{topic.id}.{lang.ext}</div>
        <pre><code>{highlight(code, language)}</code></pre>
      </div>

      {output && (
        <div className={`code-output ${output.ok ? '' : 'has-error'}`} role="status">
          <div className="code-file">Output</div>
          <pre>{output.out.length ? output.out.join('\n') : output.ok ? '(the code ran and printed nothing)' : ''}{output.error ? `${output.out.length ? '\n' : ''}Error: ${output.error}` : ''}</pre>
        </div>
      )}

      <p className="muted">
        {language === 'javascript'
          ? 'Run code works right here, safely, inside your browser. Change nothing, then trace it by hand with the example values to check your understanding.'
          : 'Paste this into any editor (VS Code, Replit, an online compiler) to run it. JavaScript can also be run here.'}
      </p>
    </div>
  );
}
