import { useState } from 'react';
import Overview from './Overview';
import Walkthrough from './Walkthrough';
import ConceptVisual from './ConceptVisual';
import CodeView from './CodeView';
import Quiz from './Quiz';
import Flashcards from './Flashcards';
import Notes from './Notes';
import HandwrittenNotes from './HandwrittenNotes';
import SubjectPicker from './SubjectPicker';
import { StarIcon, PlayIcon, CheckIcon } from './Icons';

const ALL_TABS = [
  { id: 'concept', label: 'Overview' },
  { id: 'sketch', label: 'Handwritten notes' },
  { id: 'visual', label: 'Walkthrough' },
  { id: 'code', label: 'Code' },
  { id: 'practice', label: 'Quiz' },
  { id: 'cards', label: 'Flashcards' },
  { id: 'notes', label: 'Notes' }
];

const DEPTHS = [
  { id: 'simple', label: 'Simple' },
  { id: 'standard', label: 'Standard' },
  { id: 'deep', label: 'Deep' }
];

export default function TeachingBoard({
  topic,
  index,
  total,
  progress,
  aiOn,
  onToggleComplete,
  onNextTopic,
  onPrevTopic,
  hasPrev,
  hasNext,
  onExplain,
  onOpenTopic,
  onChangeDepth,
  isBookmarked,
  onToggleBookmark,
  subjects,
  onToggleSubject,
  onCreateSubject,
  note,
  onNoteChange,
  cardsKnown,
  onCardsKnown,
  award,
  onQuizFinish
}) {
  const [activeTab, setActiveTab] = useState('concept');
  const isCompleted = progress.completed.includes(topic.id);
  const steps = topic.visualTrace?.steps || [];
  const best = progress.quizBest[topic.id];

  const tabs = ALL_TABS.filter(
    (t) => (t.id !== 'visual' || steps.length || topic.visual) && (t.id !== 'code' || topic.codeSnippets) && (t.id !== 'practice' || topic.quiz.length)
  );
  const nextTab = tabs[1];

  return (
    <article className="lesson" aria-label={`${topic.name} lesson`}>
      <header className="lesson-head">
        <p className="lesson-kicker">
          {topic.builtin ? `Topic ${index + 1} of ${total} in the DSA course` : topic.source === 'wikipedia' ? 'Lesson from Wikipedia' : 'Lesson written by AI'}
        </p>
        <h1>
          <span aria-hidden="true" className="lesson-icon">{topic.icon}</span> {topic.name}
        </h1>
        <p className="lesson-subtitle">{topic.subtitle}</p>
        <p className="lesson-summary">{topic.summary}</p>

        <div className="meta-row">
          <span className={`level level-${topic.difficulty.toLowerCase()}`}>{topic.difficulty}</span>
          <span className="meta">{topic.estimatedTime} to read</span>
          {best && <span className="meta">Best quiz score {best.score}/{best.total}</span>}
          {isCompleted && <span className="meta meta-done"><CheckIcon size={14} /> Completed</span>}
        </div>

        <div className="lesson-actions">
          <button type="button" className="btn btn-primary" onClick={onExplain}>
            <PlayIcon size={16} /> Have Lavvi explain this
          </button>
          <button type="button" className={`btn btn-ghost ${isBookmarked ? 'is-on' : ''}`} onClick={onToggleBookmark} aria-pressed={isBookmarked}>
            <StarIcon size={16} /> {isBookmarked ? 'Saved' : 'Save lesson'}
          </button>
          <SubjectPicker lesson={topic} subjects={subjects} onToggle={onToggleSubject} onCreate={onCreateSubject} />
          {aiOn && topic.source === 'ai' && (
            <div className="depth">
              <span className="muted small">Explain it</span>
              <div className="segmented segmented-sm" role="group" aria-label="How deep the explanation goes">
                {DEPTHS.map((d) => (
                  <button key={d.id} type="button" className={topic.level === d.id ? 'on' : ''} aria-pressed={topic.level === d.id} onClick={() => topic.level !== d.id && onChangeDepth(d.id)}>
                    {d.label}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </header>

      <div className="tabs" role="tablist" aria-label="Lesson sections">
        {tabs.map((tab) => (
          <button key={tab.id} type="button" role="tab" aria-selected={activeTab === tab.id} className={`tab ${activeTab === tab.id ? 'active' : ''}`} onClick={() => setActiveTab(tab.id)}>
            {tab.id === 'visual' && !steps.length ? 'Diagram' : tab.label}
            {tab.id === 'visual' && steps.length > 0 && <span className="tab-count">{steps.length}</span>}
            {tab.id === 'practice' && <span className="tab-count">{topic.quiz.length}</span>}
            {tab.id === 'notes' && note && <span className="tab-dot" aria-label="You have notes" />}
          </button>
        ))}
      </div>

      <div className="lesson-body" role="tabpanel">
        {activeTab === 'concept' && (
          <Overview topic={topic} nextLabel={nextTab?.label} onNext={() => setActiveTab(nextTab.id)} onOpenTopic={onOpenTopic} />
        )}
        {activeTab === 'visual' && steps.length > 0 && <Walkthrough topic={topic} onDone={() => setActiveTab(topic.codeSnippets ? 'code' : 'practice')} />}
        {activeTab === 'visual' && !steps.length && topic.visual && (
          <ConceptVisual key={topic.id} visual={topic.visual} onDone={() => setActiveTab(topic.quiz.length ? 'practice' : 'cards')} />
        )}
        {activeTab === 'sketch' && <HandwrittenNotes key={topic.id} topic={topic} aiOn={aiOn} />}
        {activeTab === 'code' && topic.codeSnippets && <CodeView topic={topic} />}
        {activeTab === 'practice' && topic.quiz.length > 0 && (
          <Quiz key={topic.id} questions={topic.quiz} title={`${topic.name} quiz`} onFinish={onQuizFinish} isCompleted={isCompleted} onComplete={onToggleComplete} />
        )}
        {activeTab === 'cards' && <Flashcards lesson={topic} known={cardsKnown} onKnown={onCardsKnown} onAward={award} />}
        {activeTab === 'notes' && <Notes lesson={topic} note={note} onChange={onNoteChange} />}
      </div>

      {topic.builtin && (
        <footer className="lesson-foot">
          <button type="button" className="btn btn-ghost" onClick={onPrevTopic} disabled={!hasPrev}>
            Previous topic
          </button>
          <button type="button" className={`btn ${isCompleted ? 'btn-done' : 'btn-outline'}`} onClick={onToggleComplete}>
            {isCompleted ? 'Completed' : 'Mark as complete'}
          </button>
          <button type="button" className="btn btn-ghost" onClick={onNextTopic} disabled={!hasNext}>
            Next topic
          </button>
        </footer>
      )}
    </article>
  );
}
