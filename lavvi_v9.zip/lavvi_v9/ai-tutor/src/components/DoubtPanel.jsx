import { useState, useRef, useEffect } from 'react';
import { QUICK_QUESTIONS } from '../data/topicsData';
import { askFollowUp } from '../lib/lessons';
import { speechSupported, loadVoices, planLine, speakOnce, stopSpeaking } from '../lib/speech';
import { MicIcon, SpeakerIcon, CopyIcon, TrashIcon, StopIcon } from './Icons';

const GENERIC_QUESTIONS = ['Explain it more simply', 'Why does it matter?', 'Give me an example', 'What are common mistakes?'];

const Recognition = typeof window !== 'undefined' ? window.SpeechRecognition || window.webkitSpeechRecognition : null;

export default function DoubtPanel({ currentTopic, onAsk }) {
  const welcome = (name) => ({
    id: 'welcome',
    sender: 'bot',
    text: `Hi! I'm Lavvi. Ask me anything about ${name}, by typing or with the microphone.`
  });

  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [messages, setMessages] = useState(() => [welcome(currentTopic?.name || 'DSA')]);
  const [listening, setListening] = useState(false);
  const [micLang, setMicLang] = useState('en-IN');
  const [speakingId, setSpeakingId] = useState(null);
  const [copiedId, setCopiedId] = useState(null);
  const [voices, setVoices] = useState([]);
  const counter = useRef(1);
  const logRef = useRef(null);
  const recRef = useRef(null);

  useEffect(() => {
    const el = logRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, isTyping]);

  useEffect(() => {
    loadVoices().then(setVoices);
    return () => {
      recRef.current?.abort?.();
      stopSpeaking();
    };
  }, []);

  const ask = (text) => {
    const value = (text ?? input).trim();
    if (!value || isTyping) return;
    const id = counter.current++;
    setMessages((prev) => [...prev, { id: `u-${id}`, sender: 'user', text: value }]);
    setInput('');
    setIsTyping(true);
    onAsk?.();
    askFollowUp(value, currentTopic)
      .catch(() => ({ text: 'Sorry, I could not answer that just now. Please try again.', spoken: '' }))
      .then((answer) => {
        setMessages((prev) => [...prev, { id: `b-${id}`, sender: 'bot', text: answer.text, spoken: answer.spoken }]);
        setIsTyping(false);
      });
  };

  const listen = () => {
    if (!Recognition) return;
    if (listening) {
      recRef.current?.stop();
      return;
    }
    const rec = new Recognition();
    recRef.current = rec;
    rec.lang = micLang;
    rec.interimResults = true;
    rec.onresult = (e) => setInput(Array.from(e.results).map((r) => r[0].transcript).join(' '));
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    setListening(true);
    rec.start();
  };

  const speak = (m) => {
    if (speakingId === m.id) {
      stopSpeaking();
      setSpeakingId(null);
      return;
    }
    setSpeakingId(m.id);
    const plan = planLine({ en: m.text.replace(/\n+/g, '. ') }, 'english', voices, localStorage.getItem('ai_tutor_voice_uri') || '');
    speakOnce(plan.text, {
      voice: plan.voice,
      lang: plan.lang,
      onend: () => setSpeakingId((cur) => (cur === m.id ? null : cur))
    });
  };

  const copy = (m) => {
    navigator.clipboard?.writeText(m.text).then(() => {
      setCopiedId(m.id);
      setTimeout(() => setCopiedId(null), 1500);
    });
  };

  const clear = () => {
    stopSpeaking();
    setSpeakingId(null);
    setMessages([welcome(currentTopic?.name || 'DSA')]);
  };

  return (
    <section className="chat" aria-label="Ask Lavvi">
      <div className="chat-head">
        <div>
          <h2>Ask Lavvi</h2>
          <p>Stuck on something in {currentTopic?.name}? Ask a follow-up question.</p>
        </div>
        {messages.length > 1 && (
          <button type="button" className="btn btn-ghost btn-sm" onClick={clear}>
            <TrashIcon size={15} /> Clear chat
          </button>
        )}
      </div>

      <div className="chips" aria-label="Suggested questions">
        {(currentTopic.builtin ? QUICK_QUESTIONS : GENERIC_QUESTIONS).map((chip) => (
          <button key={chip} type="button" className="chip" onClick={() => ask(chip)} disabled={isTyping}>
            {chip}
          </button>
        ))}
      </div>

      <div className="chat-log" ref={logRef} role="log" aria-live="polite">
        {messages.map((m) => (
          <div key={m.id} className={`msg ${m.sender}`}>
            <span className="msg-who">{m.sender === 'user' ? 'You' : 'Lavvi'}</span>
            <div className="msg-text">
              {m.text.split('\n').map((line, i) => (
                <p key={i}>{line}</p>
              ))}
            </div>
            {m.sender === 'bot' && m.id !== 'welcome' && (
              <div className="msg-actions">
                {speechSupported() && (
                  <button type="button" className="mini-btn" onClick={() => speak(m)}>
                    {speakingId === m.id ? <StopIcon size={14} /> : <SpeakerIcon size={14} />}
                    {speakingId === m.id ? 'Stop' : 'Listen'}
                  </button>
                )}
                <button type="button" className="mini-btn" onClick={() => copy(m)}>
                  <CopyIcon size={14} /> {copiedId === m.id ? 'Copied' : 'Copy'}
                </button>
              </div>
            )}
          </div>
        ))}
        {isTyping && (
          <div className="msg bot">
            <span className="msg-who">Lavvi</span>
            <div className="typing" aria-label="Lavvi is typing">
              <span /><span /><span />
            </div>
          </div>
        )}
      </div>

      <form
        className="chat-form"
        onSubmit={(e) => {
          e.preventDefault();
          ask();
        }}
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={listening ? 'Listening…' : `Ask a question about ${currentTopic?.name || 'DSA'}`}
          aria-label="Your question"
        />
        {Recognition && (
          <>
            <button type="button" className="mini-btn lang-btn" onClick={() => setMicLang(micLang === 'en-IN' ? 'hi-IN' : 'en-IN')} title="Language you will speak in" disabled={listening}>
              {micLang === 'en-IN' ? 'EN' : 'हिं'}
            </button>
            <button type="button" className={`icon-btn mic ${listening ? 'is-live' : ''}`} onClick={listen} aria-label={listening ? 'Stop listening' : 'Ask with your voice'} aria-pressed={listening}>
              <MicIcon />
            </button>
          </>
        )}
        <button type="submit" className="btn btn-primary" disabled={!input.trim() || isTyping}>
          Send
        </button>
      </form>
    </section>
  );
}
