import { DownloadIcon } from './Icons';

// Personal notes for one lesson. Saved in the browser as you type.
export default function Notes({ lesson, note, onChange }) {
  const points = [lesson.concept.tagline, ...lesson.concept.whyUse, ...lesson.concept.limitations].filter(Boolean);

  const add = (text) => onChange(`${note}${note && !note.endsWith('\n') ? '\n' : ''}- ${text}\n`);

  const download = () => {
    const md = [
      `# ${lesson.name}`,
      '',
      lesson.summary,
      '',
      '## Key points',
      ...points.map((p) => `- ${p}`),
      '',
      '## My notes',
      note || '(nothing written yet)',
      ''
    ].join('\n');
    const url = URL.createObjectURL(new Blob([md], { type: 'text/markdown' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `${lesson.name.replace(/[^a-z0-9]+/gi, '-').toLowerCase()}-notes.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="stack-lg fade-in">
      <div className="walk-head">
        <div>
          <h3 className="section-title">My notes</h3>
          <p className="muted small">Saved on this device as you type.</p>
        </div>
        <button type="button" className="btn btn-ghost btn-sm" onClick={download}>
          <DownloadIcon size={15} /> Download as Markdown
        </button>
      </div>

      <textarea
        className="notes-area"
        value={note}
        onChange={(e) => onChange(e.target.value)}
        placeholder={`Write what you want to remember about ${lesson.name}. Add a key point below to start.`}
        aria-label={`Notes for ${lesson.name}`}
        rows={9}
      />

      {points.length > 0 && (
        <section className="card">
          <h3>Add a key point to your notes</h3>
          <ul className="point-list">
            {points.slice(0, 7).map((p) => (
              <li key={p}>
                <span>{p}</span>
                <button type="button" className="mini-btn" onClick={() => add(p)}>Add</button>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
