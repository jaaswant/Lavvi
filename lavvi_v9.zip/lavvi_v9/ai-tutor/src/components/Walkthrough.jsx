import { useState, useEffect } from 'react';
import Visualizer from './Visualizer';
import { PlayIcon, PauseIcon, RefreshIcon, SpeakerIcon } from './Icons';
import { speechSupported, loadVoices, pickVoice, speakOnce, stopSpeaking } from '../lib/speech';

const SPEEDS = [
  { label: 'Slow', ms: 3600 },
  { label: 'Normal', ms: 2400 },
  { label: 'Fast', ms: 1300 }
];

// Step by step visual trace. Arrow keys move between steps.
export default function Walkthrough({ topic, onDone }) {
  const steps = topic.visualTrace.steps;
  const total = steps.length;
  const [stepIndex, setStepIndex] = useState(0);
  const [autoPlay, setAutoPlay] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [voices, setVoices] = useState([]);
  const [reading, setReading] = useState(false);
  const step = steps[stepIndex];

  useEffect(() => {
    loadVoices().then(setVoices);
    return () => stopSpeaking();
  }, []);

  useEffect(() => {
    if (!autoPlay) return undefined;
    const timer = setInterval(() => {
      setStepIndex((prev) => {
        if (prev >= total - 1) {
          setAutoPlay(false);
          return prev;
        }
        return prev + 1;
      });
    }, SPEEDS[speed].ms);
    return () => clearInterval(timer);
  }, [autoPlay, total, speed]);

  useEffect(() => {
    const onKey = (e) => {
      if (e.target.closest?.('input, textarea, select')) return;
      if (e.key === 'ArrowRight') setStepIndex((p) => Math.min(total - 1, p + 1));
      if (e.key === 'ArrowLeft') setStepIndex((p) => Math.max(0, p - 1));
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [total]);

  const read = () => {
    if (reading) {
      stopSpeaking();
      setReading(false);
      return;
    }
    setReading(true);
    speakOnce(`${step.description} ${step.highlightText || ''}`, {
      voice: pickVoice(voices, 'english', ''),
      onend: () => setReading(false)
    });
  };

  return (
    <div className="stack-lg fade-in">
      <div className="walk-head">
        <div>
          <h3 className="section-title">{topic.visualTrace.title}</h3>
          <p className="muted small">Use the left and right arrow keys to move between steps.</p>
        </div>
        <div className="walk-controls">
          <div className="segmented segmented-sm" role="group" aria-label="Auto-play speed">
            {SPEEDS.map((s, i) => (
              <button key={s.label} type="button" className={speed === i ? 'on' : ''} aria-pressed={speed === i} onClick={() => setSpeed(i)}>{s.label}</button>
            ))}
          </div>
          <button
            type="button"
            className={`btn btn-ghost btn-sm ${autoPlay ? 'is-on' : ''}`}
            onClick={() => {
              if (!autoPlay && stepIndex >= total - 1) setStepIndex(0);
              setAutoPlay(!autoPlay);
            }}
          >
            {autoPlay ? <PauseIcon size={15} /> : <PlayIcon size={15} />} {autoPlay ? 'Pause' : 'Auto-play'}
          </button>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setStepIndex(0); setAutoPlay(false); }}>
            <RefreshIcon size={15} /> Restart
          </button>
        </div>
      </div>

      <div className="stage">
        <Visualizer topicId={topic.id} step={step} />
      </div>

      <div className="step-card">
        <div className="step-top">
          <span className="step-badge">Step {stepIndex + 1} of {total}</span>
          {speechSupported() && (
            <button type="button" className="mini-btn" onClick={read}>
              <SpeakerIcon size={14} /> {reading ? 'Stop' : 'Read this step'}
            </button>
          )}
        </div>
        <p>{step.description}</p>
        {step.highlightText && <p className="step-note">{step.highlightText}</p>}
      </div>

      <div className="walk-nav">
        <button type="button" className="btn btn-ghost" onClick={() => setStepIndex((p) => Math.max(0, p - 1))} disabled={stepIndex === 0}>
          Previous
        </button>
        <div className="dots">
          {steps.map((_, i) => (
            <button key={i} type="button" className={`dot ${i === stepIndex ? 'on' : i < stepIndex ? 'past' : ''}`} onClick={() => setStepIndex(i)} aria-label={`Go to step ${i + 1}`} />
          ))}
        </div>
        <button type="button" className="btn btn-primary" onClick={() => (stepIndex < total - 1 ? setStepIndex((p) => p + 1) : onDone())}>
          {stepIndex < total - 1 ? 'Next step' : 'See the code'}
        </button>
      </div>
    </div>
  );
}
