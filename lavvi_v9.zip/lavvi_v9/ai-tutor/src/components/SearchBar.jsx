import { useState, useRef, useId } from 'react';
import { SearchIcon } from './Icons';

// Search box with suggestions. Press "/" anywhere to focus it.
export default function SearchBar({ onSearch, loading, initialValue = '', size = 'large', placeholder, suggestions = [] }) {
  const [value, setValue] = useState(initialValue);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const listId = useId();
  const inputRef = useRef(null);

  const q = value.trim().toLowerCase();
  const shown = suggestions
    .filter((s, i, all) => all.indexOf(s) === i && s.toLowerCase() !== q && (!q || s.toLowerCase().includes(q)))
    .slice(0, 6);

  const go = (text) => {
    const v = (text ?? value).trim();
    if (!v || loading) return;
    setValue(v);
    setOpen(false);
    inputRef.current?.blur();
    onSearch(v);
  };

  const onKeyDown = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setOpen(true);
      setActive((a) => Math.min(shown.length - 1, a + 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActive((a) => Math.max(-1, a - 1));
    } else if (e.key === 'Escape') {
      setOpen(false);
      inputRef.current?.blur();
    } else if (e.key === 'Enter' && active >= 0 && shown[active]) {
      e.preventDefault();
      go(shown[active]);
    }
  };

  return (
    <form
      className={`searchbar searchbar-${size}`}
      onSubmit={(e) => {
        e.preventDefault();
        go();
      }}
      role="search"
    >
      <SearchIcon size={size === 'large' ? 22 : 18} />
      <input
        ref={inputRef}
        data-search-input
        type="text"
        value={value}
        onChange={(e) => {
          setValue(e.target.value);
          setOpen(true);
          setActive(-1);
        }}
        onFocus={() => setOpen(true)}
        onBlur={() => setOpen(false)}
        onKeyDown={onKeyDown}
        placeholder={placeholder || 'Type any topic, like photosynthesis or black holes'}
        aria-label="Search any topic"
        role="combobox"
        aria-expanded={open && shown.length > 0}
        aria-controls={listId}
        aria-autocomplete="list"
        autoComplete="off"
        maxLength={120}
      />
      {size === 'large' && !value && <kbd className="kbd" aria-hidden="true">/</kbd>}
      <button type="submit" disabled={!value.trim() || loading}>
        {loading ? 'Preparing…' : 'Teach me'}
      </button>

      {open && shown.length > 0 && (
        <ul className="suggest" id={listId} role="listbox">
          {shown.map((s, i) => (
            <li key={s} role="option" aria-selected={i === active} className={i === active ? 'on' : ''}>
              <button type="button" tabIndex={-1} onMouseDown={(e) => { e.preventDefault(); go(s); }}>
                {s}
              </button>
            </li>
          ))}
        </ul>
      )}
    </form>
  );
}
