import SearchBar from './SearchBar';
import ProgressRing from './ProgressRing';
import { CATEGORIES } from '../data/ideas';
import { levelInfo, dayKey } from '../lib/progress';
import { useRef } from 'react';
import { DownloadIcon, FolderIcon, PlusIcon, FlameIcon, StarIcon, BoltIcon, CheckIcon, ChevronIcon, TrashIcon, CompareIcon, ScanIcon } from './Icons';

export default function Home({ onSearch, onChallenge, onCompare, onScan, onOpenSubject, onClearHistory, loading, error, progress, suggestions, onImport, onToast }) {
  const fileRef = useRef(null);
  const backup = () => {
    const url = URL.createObjectURL(new Blob([JSON.stringify(progress, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `lavvi-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };
  const restore = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      onImport(await file.text());
      onToast('Backup restored');
    } catch (err) {
      onToast(err.message || 'Could not read that file');
    }
  };
  const lv = levelInfo(progress.xp);
  const last = progress.history[0];
  const dailyDone = progress.dailyDone === dayKey();

  return (
    <div className="home">
      <section className="hero">
        <div className="hero-main">
          <h1>What do you want to understand today?</h1>
          <p className="hero-sub">
            Type any topic. Lavvi explains it out loud in English, shows handwritten notes (in English or Hinglish), draws a diagram where it
            helps, and checks what you learned with a quiz and flashcards.
          </p>

          <SearchBar onSearch={onSearch} loading={loading} suggestions={suggestions} />
          {error && <p className="form-error" role="alert">{error}</p>}
        </div>

        <aside className="today" aria-label="Your progress">
          <h2 className="today-title">Your progress</h2>
          <div className="today-stats">
            <ProgressRing value={lv.into} max={lv.size} size={76} stroke={7} label={`Level ${lv.level}`}>
              <span className="ring-big">{lv.level}</span>
            </ProgressRing>
            <div>
              <p className="today-level">{lv.title}</p>
              <p className="muted small">{progress.xp} XP, {lv.size - lv.into} to the next level</p>
            </div>
          </div>
          <dl className="today-grid">
            <div><dt><FlameIcon size={15} /> Streak</dt><dd>{progress.streak.count} {progress.streak.count === 1 ? 'day' : 'days'}</dd></div>
            <div><dt><CheckIcon size={15} /> Lessons done</dt><dd>{progress.completed.length}</dd></div>
          </dl>
          <button type="button" className="today-card" onClick={onChallenge}>
            <BoltIcon size={20} />
            <span>
              <b>{dailyDone ? 'Daily challenge done' : 'Daily challenge'}</b>
              <small>{dailyDone ? 'Play again for practice' : 'Five mixed questions, 30 bonus XP'}</small>
            </span>
            <ChevronIcon size={18} />
          </button>
          {last && (
            <button type="button" className="today-card" onClick={() => onSearch(last.name)} disabled={loading}>
              <span className="today-emoji" aria-hidden="true">{last.icon}</span>
              <span>
                <b>Continue {last.name}</b>
                <small>Pick up where you left off</small>
              </span>
              <ChevronIcon size={18} />
            </button>
          )}
        </aside>
      </section>

      <section aria-label="Study tools">
        <div className="home-tools">
          <button type="button" className="home-tool" onClick={onCompare}>
            <CompareIcon size={28} />
            <span>
              <b>Compare two concepts</b>
              <small>Arrays vs linked lists, RAM vs ROM, supervised vs unsupervised learning, side by side.</small>
            </span>
            <ChevronIcon size={18} />
          </button>
          <button type="button" className="home-tool" onClick={onScan}>
            <ScanIcon size={28} />
            <span>
              <b>Scan handwritten notes</b>
              <small>Photo in, clean text out. Hard paragraphs explained, then flashcards and a quiz.</small>
            </span>
            <ChevronIcon size={18} />
          </button>
        </div>
      </section>

      <section aria-label="Topic ideas">
        <h2 className="section-heading">Not sure where to start?</h2>
        <div className="ideas">
          {CATEGORIES.map((c) => (
            <div key={c.title} className="idea-col">
              <h3>{c.title}</h3>
              <ul>
                {c.topics.map((t) => (
                  <li key={t}>
                    <button type="button" onClick={() => onSearch(t)} disabled={loading}>{t}</button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section aria-label="My subjects">
        <h2 className="shelf-title">
          <FolderIcon size={18} /> My subjects
          <button type="button" className="mini-btn" onClick={() => onOpenSubject(null)}>
            {progress.subjects.length ? 'Manage' : <><PlusIcon size={14} /> Create one</>}
          </button>
        </h2>
        {progress.subjects.length === 0 ? (
          <p className="muted small">Save topics you study into subjects like “Physics” or “Exam prep”, and find them all in one place.</p>
        ) : (
          <div className="chips">
            {progress.subjects.map((s) => (
              <button key={s.id} type="button" className="chip chip-subject" style={{ '--sc': s.color }} onClick={() => onOpenSubject(s.id)}>
                <FolderIcon size={15} /> {s.name} <span className="muted">· {s.topics.length}</span>
              </button>
            ))}
          </div>
        )}
      </section>

      {(progress.bookmarks.length > 0 || progress.history.length > 0) && (
        <div className="shelf">
          {progress.bookmarks.length > 0 && (
            <section aria-label="Saved lessons">
              <h2 className="shelf-title"><StarIcon size={18} /> Saved lessons</h2>
              <div className="chips">
                {progress.bookmarks.map((b) => (
                  <button key={b.id} type="button" className="chip" onClick={() => onSearch(b.name)} disabled={loading}>
                    <span aria-hidden="true">{b.icon}</span> {b.name}
                  </button>
                ))}
              </div>
            </section>
          )}
          {progress.history.length > 0 && (
            <section aria-label="Recently studied">
              <h2 className="shelf-title">
                Recently studied
                <button type="button" className="mini-btn" onClick={onClearHistory}><TrashIcon size={14} /> Clear</button>
              </h2>
              <div className="chips">
                {progress.history.map((h) => (
                  <button key={h.id} type="button" className="chip" onClick={() => onSearch(h.name)} disabled={loading}>
                    <span aria-hidden="true">{h.icon}</span> {h.name}
                  </button>
                ))}
              </div>
            </section>
          )}
        </div>
      )}

      <p className="muted small backup-row">
        Your progress, subjects and notes live in this browser.{' '}
        <button type="button" className="mini-btn" onClick={backup}><DownloadIcon size={14} /> Back up</button>{' '}
        <button type="button" className="mini-btn" onClick={() => fileRef.current?.click()}>Restore</button>
        <input ref={fileRef} type="file" accept="application/json,.json" hidden onChange={restore} />
      </p>

      <p className="muted small shortcuts">
        Shortcuts: press <kbd className="kbd">/</kbd> to search, <kbd className="kbd">←</kbd> <kbd className="kbd">→</kbd> to move through diagrams and flashcards, <kbd className="kbd">1</kbd>–<kbd className="kbd">4</kbd> to answer quiz questions, <kbd className="kbd">Space</kbd> to play or pause the teacher.
      </p>
    </div>
  );
}
