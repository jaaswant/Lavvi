import { useState, useMemo, useEffect, useCallback } from 'react';
import { buildFlashcards } from '../lib/flashcards';
import { shuffle } from '../lib/quiz';
import { ShuffleIcon, RefreshIcon } from './Icons';

// Flip cards made from the lesson. "Got it" cards are remembered between visits.
export default function Flashcards({ lesson, cards: given, known, onKnown, onAward, title = 'Flashcards' }) {
  const cards = useMemo(() => given || buildFlashcards(lesson), [given, lesson]);
  const [order, setOrder] = useState(() => cards.map((_, i) => i));
  const [pos, setPos] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [onlyNew, setOnlyNew] = useState(false);

  const deck = onlyNew ? order.filter((n) => !known.includes(n)) : order;
  const card = cards[deck[pos]];
  const finished = deck.length === 0 || pos >= deck.length;

  const mark = useCallback(
    (gotIt) => {
      if (!card) return;
      const n = deck[pos];
      if (gotIt && !known.includes(n)) {
        onKnown([...known, n]);
        onAward?.(2, 'Flashcard');
      }
      if (!gotIt && known.includes(n)) onKnown(known.filter((x) => x !== n));
      setFlipped(false);
      setPos((p) => p + 1);
    },
    [card, deck, pos, known, onKnown, onAward]
  );

  useEffect(() => {
    const onKey = (e) => {
      if (finished || e.target.closest?.('input, textarea, select')) return;
      if (e.key === 'ArrowRight' && flipped) mark(true);
      else if (e.key === 'ArrowLeft' && flipped) mark(false);
      else if ((e.key === ' ' || e.key === 'Enter') && !e.target.closest?.('button')) {
        e.preventDefault();
        setFlipped((f) => !f);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [flipped, finished, mark]);

  const restart = (reviewOnly) => {
    setOnlyNew(reviewOnly);
    setPos(0);
    setFlipped(false);
  };

  if (cards.length === 0) return <p className="muted">There are no cards yet.</p>;

  return (
    <div className="stack-lg fade-in">
      <div className="walk-head">
        <div>
          <h3 className="section-title">{title}</h3>
          <p className="muted small">{known.length} of {cards.length} cards learned</p>
        </div>
        <div className="walk-controls">
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setOrder(shuffle(cards.map((_, i) => i))); setPos(0); setFlipped(false); }}>
            <ShuffleIcon size={15} /> Shuffle
          </button>
        </div>
      </div>

      {finished ? (
        <div className="card deck-done">
          <h3>{deck.length === 0 ? 'Nothing left to review.' : 'You reached the end of the deck.'}</h3>
          <p className="muted">{known.length} of {cards.length} cards are marked as learned.</p>
          <div className="quiz-actions">
            {known.length < cards.length && (
              <button type="button" className="btn btn-primary" onClick={() => restart(true)}>
                <RefreshIcon size={16} /> Review the {cards.length - known.length} I haven't learned
              </button>
            )}
            <button type="button" className="btn btn-ghost" onClick={() => restart(false)}>Go through all cards</button>
          </div>
        </div>
      ) : (
        <>
          <button type="button" className={`flip ${flipped ? 'is-flipped' : ''}`} onClick={() => setFlipped(!flipped)} aria-label={flipped ? 'Show the question' : 'Show the answer'}>
            <span className="flip-inner">
              <span className="flip-face flip-front">
                <small>Question {pos + 1} of {deck.length}</small>
                <b>{card.front}</b>
                <em>Click or press space to flip</em>
              </span>
              <span className="flip-face flip-back">
                <small>Answer</small>
                <span>{card.back}</span>
              </span>
            </span>
          </button>
          <div className="flip-actions">
            <button type="button" className="btn btn-ghost" onClick={() => mark(false)} disabled={!flipped}>Still learning</button>
            <button type="button" className="btn btn-primary" onClick={() => mark(true)} disabled={!flipped}>Got it</button>
          </div>
        </>
      )}
    </div>
  );
}
