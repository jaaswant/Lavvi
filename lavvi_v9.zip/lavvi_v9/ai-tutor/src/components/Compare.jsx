import { useState, useRef } from 'react';
import Quiz from './Quiz';
import Flashcards from './Flashcards';
import { compareConcepts, downloadText, slug } from '../lib/ai';
import AiNotice from './AiNotice';
import { useAiServer } from '../lib/ai';
import { RefreshIcon, DownloadIcon, CopyIcon } from './Icons';

const EXAMPLES = [
  ['Arrays', 'Linked lists'],
  ['RAM', 'ROM'],
  ['Supervised learning', 'Unsupervised learning'],
  ['Stack', 'Queue'],
  ['TCP', 'UDP'],
  ['Mitosis', 'Meiosis']
];

const toMarkdown = (r) =>
  [
    `# ${r.title}`,
    '',
    `- **${r.a.name}**: ${r.a.oneLiner}`,
    `- **${r.b.name}**: ${r.b.oneLiner}`,
    '',
    `| | ${r.a.name} | ${r.b.name} |`,
    '|---|---|---|',
    ...r.rows.map((x) => `| ${x.aspect} | ${x.a.replace(/\|/g, '/')} | ${x.b.replace(/\|/g, '/')} |`),
    '',
    ...(r.similarities.length ? ['## What they share', ...r.similarities.map((s) => `- ${s}`), ''] : []),
    '## When to use which',
    `- **${r.a.name}**: ${r.whenToUse.a}`,
    `- **${r.b.name}**: ${r.whenToUse.b}`,
    '',
    ...(r.mistakes.length ? ['## Common mix-ups', ...r.mistakes.map((s) => `- ${s}`), ''] : []),
    ...(r.memoryTip ? [`**Remember:** ${r.memoryTip}`, ''] : [])
  ].join('\n');

// Two concepts side by side, with a quick revision deck and quiz made from the comparison.
export default function Compare({ award, onBack, onToast }) {
  const { ready: aiOn, status, recheck } = useAiServer();
  const [a, setA] = useState('');
  const [b, setB] = useState('');
  const [state, setState] = useState('idle'); // idle | loading
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);
  const [tab, setTab] = useState('table');
  const [known, setKnown] = useState([]);
  const [copied, setCopied] = useState(false);
  const firstInput = useRef(null);
  const awarded = useRef(new Set());

  const run = async (x = a, y = b) => {
    const A = x.trim();
    const B = y.trim();
    if (!A || !B) {
      setError('Enter two concepts to compare.');
      return;
    }
    setError('');
    setState('loading');
    try {
      const r = await compareConcepts(A, B);
      setResult(r);
      setTab('table');
      setKnown([]);
      const key = `${A.toLowerCase()}|${B.toLowerCase()}`;
      if (!awarded.current.has(key)) {
        awarded.current.add(key);
        award?.(5, 'Comparison');
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setState('idle');
    }
  };

  const pick = ([x, y]) => {
    setA(x);
    setB(y);
    run(x, y);
  };

  const swap = () => {
    setA(b);
    setB(a);
    if (result) run(b, a);
  };

  const copy = () => {
    navigator.clipboard?.writeText(toMarkdown(result)).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  };

  const loading = state === 'loading';

  return (
    <div className="tool fade-in">
      <button type="button" className="back-link" onClick={onBack}>Back to home</button>
      <h1 className="tool-title">Compare two concepts</h1>
      <p className="muted tool-sub">Side by side, with the differences that matter, when to use which, and a quick quiz to lock it in.</p>

      <AiNotice status={status} onRecheck={recheck} />

      <form
        className="compare-form"
        onSubmit={(e) => {
          e.preventDefault();
          run();
        }}
      >
        <label className="field">
          <span>First concept</span>
          <input ref={firstInput} value={a} onChange={(e) => setA(e.target.value)} placeholder="e.g. Arrays" maxLength={80} autoComplete="off" />
        </label>
        <button type="button" className="icon-btn compare-swap" onClick={swap} aria-label="Swap the two concepts" title="Swap" disabled={loading}>
          <RefreshIcon size={18} />
        </button>
        <label className="field">
          <span>Second concept</span>
          <input value={b} onChange={(e) => setB(e.target.value)} placeholder="e.g. Linked lists" maxLength={80} autoComplete="off" />
        </label>
        <button type="submit" className="btn btn-primary compare-go" disabled={loading || !aiOn}>
          {loading ? 'Comparing…' : 'Compare'}
        </button>
      </form>

      <div className="chips compare-examples" aria-label="Examples">
        {EXAMPLES.map((ex) => (
          <button key={ex.join()} type="button" className="chip" onClick={() => pick(ex)} disabled={loading || !aiOn}>
            {ex[0]} vs {ex[1]}
          </button>
        ))}
      </div>

      {error && <p className="form-error" role="alert">{error}</p>}
      {loading && <p className="muted" role="status">Putting {a || 'the first concept'} next to {b || 'the second'}…</p>}

      {result && !loading && (
        <div className="stack-lg fade-in" aria-live="polite">
          <div className="walk-head">
            <div>
              <h2 className="section-title cmp-title">{result.title}</h2>
              {result.note && <p className="muted small">{result.note}</p>}
            </div>
            <div className="walk-controls">
              <button type="button" className="btn btn-ghost btn-sm" onClick={copy}><CopyIcon size={15} /> {copied ? 'Copied' : 'Copy'}</button>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => downloadText(`${slug(result.title)}.md`, toMarkdown(result))}>
                <DownloadIcon size={15} /> Markdown
              </button>
            </div>
          </div>

          <div className="segmented" role="tablist" aria-label="Comparison views">
            {[['table', 'Side by side'], ['cards', 'Flashcards'], ['quiz', 'Quiz']].map(([id, label]) => (
              <button key={id} type="button" role="tab" aria-selected={tab === id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}
                disabled={(id === 'cards' && !result.cards.length) || (id === 'quiz' && !result.quiz.length)}>
                {label}
              </button>
            ))}
          </div>

          {tab === 'table' && (
            <div className="stack-lg">
              <div className="cmp-heads">
                <div className="cmp-head cmp-a"><h3>{result.a.name}</h3><p>{result.a.oneLiner}</p></div>
                <div className="cmp-head cmp-b"><h3>{result.b.name}</h3><p>{result.b.oneLiner}</p></div>
              </div>

              <div className="cmp-table" role="table" aria-label={result.title}>
                <div className="cmp-row cmp-row-head" role="row">
                  <span role="columnheader">Aspect</span>
                  <span role="columnheader">{result.a.name}</span>
                  <span role="columnheader">{result.b.name}</span>
                </div>
                {result.rows.map((r) => (
                  <div className="cmp-row" role="row" key={r.aspect}>
                    <b role="rowheader">{r.aspect}</b>
                    <span role="cell" data-label={result.a.name}>{r.a}</span>
                    <span role="cell" data-label={result.b.name}>{r.b}</span>
                  </div>
                ))}
              </div>

              <div className="cmp-use">
                <div className="card cmp-a"><h3>Pick {result.a.name} when…</h3><p>{result.whenToUse.a}</p></div>
                <div className="card cmp-b"><h3>Pick {result.b.name} when…</h3><p>{result.whenToUse.b}</p></div>
              </div>

              <div className="cmp-extra">
                {result.similarities.length > 0 && (
                  <div className="card">
                    <h3>What they share</h3>
                    <ul className="plain-list">{result.similarities.map((s) => <li key={s}>{s}</li>)}</ul>
                  </div>
                )}
                {result.mistakes.length > 0 && (
                  <div className="card">
                    <h3>Common mix-ups</h3>
                    <ul className="plain-list">{result.mistakes.map((s) => <li key={s}>{s}</li>)}</ul>
                  </div>
                )}
              </div>

              {result.memoryTip && (
                <p className="tip"><span><b>Remember:</b> {result.memoryTip}</span></p>
              )}
              {result.hinglish && (
                <div className="card">
                  <h3>In Hinglish</h3>
                  <p lang="hi-Latn">{result.hinglish}</p>
                </div>
              )}
            </div>
          )}

          {tab === 'cards' && (
            <Flashcards cards={result.cards} known={known} onKnown={setKnown} onAward={award} title={`${result.a.name} vs ${result.b.name}`} />
          )}

          {tab === 'quiz' && (
            <Quiz
              questions={result.quiz}
              title={`${result.a.name} vs ${result.b.name}`}
              onFinish={({ score, total, first }) => {
                if (!first) return;
                const xp = score * 10 + (score === total ? 20 : 0);
                if (xp) award?.(xp, score === total ? 'Perfect quiz' : 'Quiz');
                onToast?.(`${score}/${total} on the comparison quiz`);
              }}
            />
          )}
        </div>
      )}
    </div>
  );
}
