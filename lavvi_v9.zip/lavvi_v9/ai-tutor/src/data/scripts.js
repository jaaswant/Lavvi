// Spoken lessons for the built-in DSA course.
// Each line is [English, Hinglish]. The English line is shown on screen as the caption,
// the Hinglish line (Hindi written in English letters) is what the teacher says out loud.

export const SCRIPTS = {
  arrays: [
    [`Welcome! Today we are learning about arrays.`, `Namaste! Aaj hum arrays ke baare mein seekhenge.`],
    [`An array is like a continuous row in computer memory, where every element has a fixed index.`, `Array computer memory mein ek continuous line jaisa hota hai, jahan har element ka ek fixed index hota hai.`],
    [`Indexing starts at zero.`, `Indexing zero se start hoti hai.`],
    [`Its biggest strength is that you can access any index in O(1) constant time.`, `Iski sabse badi taakat yeh hai ki aap kisi bhi index ko O(1) constant time mein access kar sakte ho.`],
    [`However, inserting a new element in the middle takes O(n) time, because the remaining elements have to be shifted forward.`, `Lekin beech mein naya element insert karne mein O(n) time lagta hai, kyunki baaki elements ko aage shift karna padta hai.`]
  ],
  'linked-lists': [
    [`Linked lists are very different from arrays.`, `Linked list arrays se bilkul alag hoti hai.`],
    [`They do not need one continuous block of memory.`, `Isko memory ka ek continuous block nahi chahiye hota.`],
    [`Each element is called a node, and a node has two parts: the data, and a pointer or reference to the next node.`, `Har element ko node kehte hain, aur node ke do hisse hote hain: data, aur agle node ka pointer ya reference.`],
    [`Think of a treasure hunt where every note tells you where to find the next clue.`, `Ek treasure hunt socho, jahan har parchi batati hai ki agla clue kahan milega.`],
    [`The advantage is that insertion and deletion can be done in O(1) time if you already know the pointer, but you cannot jump directly to a random position.`, `Fayda yeh hai ki agar pointer pata ho toh insertion aur deletion O(1) time mein ho jaata hai, lekin aap seedha kisi random position par jump nahi kar sakte.`]
  ],
  stacks: [
    [`A stack is a very interesting data structure that follows the LIFO principle.`, `Stack ek bahut interesting data structure hai jo LIFO principle follow karta hai.`],
    [`LIFO means Last In, First Out.`, `LIFO ka matlab hai Last In, First Out, yaani jo sabse last mein aaya, woh sabse pehle bahar jaata hai.`],
    [`Think of a pile of plates at a buffet: the last plate placed on top is the first one people pick up.`, `Buffet mein plates ka dher socho: jo plate sabse upar rakhi gayi, log wahi sabse pehle uthate hain.`],
    [`Pressing Ctrl Z to undo in a text editor, or pressing the back button in a browser, both work using a stack.`, `Text editor mein Ctrl Z se undo karna, ya browser mein back button dabana, dono stack se hi kaam karte hain.`],
    [`Its main operations, push, pop and peek, all take O(1) time.`, `Iske main operations, push, pop aur peek, teeno O(1) time mein hote hain.`]
  ],
  queues: [
    [`A queue simply means a line.`, `Queue ka matlab hota hai line.`],
    [`Its rule is FIFO, which stands for First In, First Out.`, `Iska rule FIFO hai, yaani First In, First Out.`],
    [`Picture the line at a cinema ticket counter: the person who is first in line gets their ticket first and leaves first.`, `Cinema ke ticket counter ki line socho: jo line mein sabse pehle khada hai, usse ticket pehle milta hai aur woh pehle nikalta hai.`],
    [`New people join at the back, which is called enqueue, and people leave from the front after being served, which is called dequeue.`, `Naye log peeche se judte hain, ise enqueue kehte hain, aur kaam hone ke baad log aage se nikalte hain, ise dequeue kehte hain.`],
    [`Print jobs in a printer and customer care call queues are live examples.`, `Printer ke print jobs aur customer care ki call queue iske live examples hain.`]
  ],
  recursion: [
    [`Recursion is a magical concept in programming.`, `Recursion programming ka ek jaadui concept hai.`],
    [`When a function calls itself, we call it recursion.`, `Jab ek function khud ko hi call karta hai, ise recursion kehte hain.`],
    [`It rests on two essential pillars: first the base case, and second the recursive relation.`, `Yeh do zaroori cheezon par tika hai: pehla base case, aur doosra recursive relation.`],
    [`The base case is the stop button that tells the recursion when to end.`, `Base case woh stop button hai jo recursion ko batata hai ki kab rukna hai.`],
    [`If you forget to write a base case, the function keeps calling itself and you get a stack overflow.`, `Agar base case likhna bhool gaye, toh function khud ko baar baar call karta rahega aur stack overflow ho jayega.`],
    [`Think of opening a Russian doll, finding a smaller doll inside, until you reach the last solid doll.`, `Ek Russian doll kholne ka socho, andar chhoti doll milti hai, aur yeh tab tak chalta hai jab tak aakhri solid doll na aa jaaye.`]
  ],
  sorting: [
    [`Sorting is one of the most popular use cases in programming.`, `Sorting programming ke sabse popular use cases mein se ek hai.`],
    [`Arranging data in a sequence or order is called sorting.`, `Data ko ek order ya sequence mein lagana sorting kehlata hai.`],
    [`For example, sorting prices from low to high in an e-commerce app, or viewing names alphabetically in a phone book.`, `Jaise e-commerce app mein prices ko kam se zyada sort karna, ya phone book mein naam alphabetically dekhna.`],
    [`For beginners, bubble sort and selection sort are the easiest to understand.`, `Beginners ke liye bubble sort aur selection sort samajhna sabse aasan hai.`],
    [`In bubble sort, the largest element floats to the end in every pass, just like a bubble rising in water.`, `Bubble sort mein har pass mein sabse bada element end mein pahunch jaata hai, bilkul paani mein uthte bubble ki tarah.`]
  ]
};

// Extra hand-written quiz questions (the first question of each lesson lives in topicsData.js).
const q = (question, correct, wrong, explanation) => ({
  question,
  options: [{ text: correct, isCorrect: true }, ...wrong.map((text) => ({ text, isCorrect: false }))],
  explanation
});

export const EXTRA_QUIZ = {
  arrays: [
    q('How can an array reach arr[i] in O(1) time?', 'It computes base address + i × element size and jumps straight there.', ['It scans from the first element until it finds index i.', 'It runs a binary search on the indexes.', 'It keeps a pointer to every element.'], 'Elements are the same size and sit side by side, so the address of arr[i] is a single multiplication and addition. No searching is needed.'),
    q('Why are arrays called cache friendly?', 'Neighbouring elements sit next to each other, so one cache load brings several of them in.', ['They are always smaller than other structures.', 'They store each element twice.', 'The CPU sorts them automatically.'], 'The CPU loads memory in small blocks. With contiguous storage, the next elements you read are usually already in that block.')
  ],
  'linked-lists': [
    q('What is the time complexity of inserting a node at the head of a linked list?', 'O(1)', ['O(n)', 'O(log n)', 'O(n²)'], 'You only create the node, point it at the old head and move HEAD. Nothing has to be shifted or traversed.'),
    q('Why can a linked list not do index access like an array in O(1)?', 'Nodes are scattered in memory, so you must follow next pointers from the head.', ['Linked lists cannot store numbers.', 'The head pointer is read-only.', 'Every node stores the whole list.'], 'There is no formula that gives the address of the 5th node. You have to hop node by node, which is O(n).')
  ],
  stacks: [
    q('Which pair of operations adds and removes items in a stack?', 'push and pop', ['enqueue and dequeue', 'insert and delete at any index', 'peek and sort'], 'push places an item on top, pop removes the top item. enqueue and dequeue belong to queues.'),
    q('Which job is a classic use of a stack?', 'Checking whether brackets in an expression are balanced', ['Serving print jobs in arrival order', 'Finding a student by roll number', 'Listing names alphabetically'], 'Each opening bracket is pushed, and each closing bracket must match the most recent one still waiting, which is exactly the top of the stack.')
  ],
  queues: [
    q('A queue follows which rule?', 'FIFO: First In, First Out', ['LIFO: Last In, First Out', 'Random access by index', 'Smallest value first, always'], 'Whoever joined the line first is served first, like a ticket counter.'),
    q('A new person joins the line. Which operation is this?', 'enqueue, at the rear', ['dequeue, at the front', 'push, on top', 'peek, at the front'], 'enqueue adds to the rear. dequeue removes from the front.')
  ],
  recursion: [
    q('What happens if a recursive function has no base case?', 'It keeps calling itself until the call stack overflows.', ['It returns 0 automatically.', 'It runs once and stops.', 'The compiler adds a base case for you.'], 'Every call adds a frame to the call stack. Without a stopping condition the stack runs out of space.'),
    q('In factorial(n) = n × factorial(n − 1), which part is the base case?', 'factorial(0) = 1', ['n × factorial(n − 1)', 'factorial(n)', 'n − 1'], 'The base case is the one input answered directly, without another recursive call. It stops the chain.'),
    q('Why is naive recursive Fibonacci slow?', 'Each call makes two more calls, so the same values are recomputed again and again.', ['Recursion is always slower than loops by a fixed 10 times.', 'It stores every number in a linked list.', 'It sorts the numbers first.'], 'fib(n) calls fib(n − 1) and fib(n − 2), so the call tree roughly doubles at every level. That is exponential, about O(2ⁿ).')
  ],
  sorting: [
    q('After the first full pass of bubble sort on [5, 1, 4], which value is guaranteed to be in its final place?', '5, the largest, at the end', ['1, at the start', '4, in the middle', 'None of them yet'], 'Each pass swaps larger values to the right, so the biggest value bubbles to the end after one pass.'),
    q('Which of these sorts is O(n log n) in every case?', 'Merge sort', ['Bubble sort', 'Selection sort', 'Quick sort'], 'Merge sort always splits in half and merges. Quick sort degrades to O(n²) in its worst case, and bubble and selection sort are O(n²).')
  ]
};

export const RELATED = {
  arrays: ['Linked Lists', 'Sorting', 'Stacks'],
  'linked-lists': ['Arrays', 'Stacks', 'Queues'],
  stacks: ['Queues', 'Recursion', 'Arrays'],
  queues: ['Stacks', 'Linked Lists', 'Arrays'],
  recursion: ['Stacks', 'Sorting', 'Arrays'],
  sorting: ['Arrays', 'Recursion', 'Queues']
};
