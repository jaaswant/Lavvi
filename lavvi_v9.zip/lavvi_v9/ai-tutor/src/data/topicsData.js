// DSA curriculum: beginner-friendly lessons, step-by-step visual walkthroughs,
// multi-language code snippets and a practice question for each topic.

export const TOPICS = [
  {
    id: 'arrays',
    name: 'Arrays',
    subtitle: 'Contiguous memory',
    icon: '📊',
    difficulty: 'Beginner',
    estimatedTime: '8 min',
    summary: 'The most basic data structure: elements stored side by side in contiguous memory.',
    audioScript:
      'Welcome! Today we are learning about arrays. An array is like a continuous row in computer memory, where every element has a fixed index. Indexing starts at zero. Its biggest strength is that you can access any index in O(1) constant time. However, inserting a new element in the middle takes O(n) time, because the remaining elements have to be shifted forward.',
    concept: {
      tagline: 'A row of lockers, or train coaches, where every one has a fixed number.',
      whatIsIt:
        'An array is a linear data structure that stores elements of the same type in contiguous blocks of memory. All the elements sit right next to each other in RAM.',
      realLifeAnalogy:
        'Imagine a row of lockers in a school corridor, numbered 0 to 9. If the principal says "Open locker #4", you do not need to count lockers 0, 1, 2 and 3 — you walk straight to locker #4. That is the power of O(1) index access in an array.',
      whyUse: [
        'Instant random access: arr[i] reaches any element directly in O(1) time.',
        'Cache friendly: elements are contiguous in memory, so the CPU loads them into its cache quickly.',
        'Simple and memory efficient: no extra pointers are stored (unlike a linked list).'
      ],
      limitations: [
        'Fixed size: in C++ and Java, primitive arrays must have their size declared up front.',
        'Costly insertions and deletions: adding or removing an element in the middle shifts the rest (O(n) time).'
      ],
      complexities: {
        access: 'O(1) — direct index formula',
        search: 'O(n) linear search, O(log n) if sorted',
        insertion: 'O(n) — shifting required',
        deletion: 'O(n) — shifting required',
        space: 'O(n)'
      }
    },
    visualTrace: {
      title: 'Array insertion: inserting 25 at index 2',
      steps: [
        {
          stepNumber: 1,
          description:
            'Initial array: 4 elements [10, 20, 30, 40] stored at contiguous memory addresses (0x100, 0x104, 0x108, 0x10C).',
          elements: [
            { index: 0, val: 10, addr: '0x100', state: 'normal' },
            { index: 1, val: 20, addr: '0x104', state: 'normal' },
            { index: 2, val: 30, addr: '0x108', state: 'normal' },
            { index: 3, val: 40, addr: '0x10C', state: 'normal' },
            { index: 4, val: '--', addr: '0x110', state: 'empty' }
          ],
          highlightText: 'We want to insert the new number 25 at index 2.'
        },
        {
          stepNumber: 2,
          description: 'Shift right: element 40 moves from index 3 to index 4.',
          elements: [
            { index: 0, val: 10, addr: '0x100', state: 'normal' },
            { index: 1, val: 20, addr: '0x104', state: 'normal' },
            { index: 2, val: 30, addr: '0x108', state: 'normal' },
            { index: 3, val: '--', addr: '0x10C', state: 'empty' },
            { index: 4, val: 40, addr: '0x110', state: 'shifted' }
          ],
          highlightText: 'The last element is shifted right first.'
        },
        {
          stepNumber: 3,
          description: 'Element 30 moves from index 2 to index 3. Index 2 is now an empty slot.',
          elements: [
            { index: 0, val: 10, addr: '0x100', state: 'normal' },
            { index: 1, val: 20, addr: '0x104', state: 'normal' },
            { index: 2, val: '--', addr: '0x108', state: 'target' },
            { index: 3, val: 30, addr: '0x10C', state: 'shifted' },
            { index: 4, val: 40, addr: '0x110', state: 'shifted' }
          ],
          highlightText: 'Space is created at index 2. This shifting is why insertion takes O(n) time.'
        },
        {
          stepNumber: 4,
          description: 'The new element 25 is placed at index 2.',
          elements: [
            { index: 0, val: 10, addr: '0x100', state: 'normal' },
            { index: 1, val: 20, addr: '0x104', state: 'normal' },
            { index: 2, val: 25, addr: '0x108', state: 'inserted' },
            { index: 3, val: 30, addr: '0x10C', state: 'normal' },
            { index: 4, val: 40, addr: '0x110', state: 'normal' }
          ],
          highlightText: 'Done! Final array: [10, 20, 25, 30, 40].'
        }
      ]
    },
    codeSnippets: {
      javascript: `// Dynamic array operations in JavaScript
const scores = [10, 20, 30, 40];

// 1. O(1) instant access by index
console.log("Element at index 2:", scores[2]); // 30

// 2. Add to the end (O(1) amortized)
scores.push(50);
console.log("After push:", scores); // [10, 20, 30, 40, 50]

// 3. Insert at a specific index (O(n) shifting)
// splice(index, deleteCount, item)
scores.splice(2, 0, 25);
console.log("After inserting 25 at index 2:", scores); // [10, 20, 25, 30, 40, 50]

// 4. Remove an element (O(n) shifting)
scores.splice(2, 1); // remove index 2
console.log("After removing index 2:", scores);`,

      python: `# Python lists (dynamic arrays)
scores = [10, 20, 30, 40]

# 1. O(1) direct access
print("Element at index 2:", scores[2]) # 30

# 2. Append at the end: O(1)
scores.append(50)

# 3. Insert at an index: O(n) shifting
scores.insert(2, 25)
print("After inserting 25 at index 2:", scores)

# 4. Pop from a specific index: O(n)
removed = scores.pop(2)
print("Removed element:", removed)
print("Final list:", scores)`,

      cpp: `// C++ std::vector (dynamic array)
#include <iostream>
#include <vector>

int main() {
    std::vector<int> scores = {10, 20, 30, 40};

    // 1. O(1) direct access
    std::cout << "Index 2 value: " << scores[2] << "\\n";

    // 2. Push back: O(1)
    scores.push_back(50);

    // 3. Insert at index 2: O(n) shifting
    scores.insert(scores.begin() + 2, 25);

    // 4. Print all elements
    for(int val : scores) {
        std::cout << val << " ";
    }
    return 0;
}`
    },
    practice: {
      question:
        'If we insert a new element at index 0 (the very beginning) of an array, what is the time complexity and why?',
      options: [
        { text: 'O(1), because the first position is directly available.', isCorrect: false },
        { text: 'O(n), because all n existing elements must be shifted one position to the right.', isCorrect: true },
        { text: 'O(log n), because it works like binary search.', isCorrect: false },
        { text: 'O(n²), because a nested loop is needed.', isCorrect: false }
      ],
      explanation:
        'The correct answer is B. When you insert at index 0, every existing element (index 0 to n-1) has to move one step forward, so the operation takes O(n) time.'
    }
  },

  {
    id: 'linked-lists',
    name: 'Linked Lists',
    subtitle: 'A chain of pointers',
    icon: '🔗',
    difficulty: 'Beginner',
    estimatedTime: '10 min',
    summary: 'A collection of nodes where each node holds data and the address (pointer) of the next node.',
    audioScript:
      'Linked lists are very different from arrays. They do not need one continuous block of memory. Each element is called a node, and a node has two parts: the data, and a pointer or reference to the next node. Think of a treasure hunt where every note tells you where to find the next clue. The advantage is that insertion and deletion can be done in O(1) time if you already know the pointer, but you cannot jump directly to a random position.',
    concept: {
      tagline: 'A treasure hunt where every note tells you where the next clue is.',
      whatIsIt:
        'A linked list is a linear data structure whose memory is non-contiguous. Elements are scattered across RAM and connected to one another through pointers.',
      realLifeAnalogy:
        'Imagine children standing in a line, each holding the hand of the child in front. If a new child wants to join in the middle, only two hands need to change — the rest of the line does not have to move at all.',
      whyUse: [
        'Dynamic size: you do not need to predict the size in advance; memory is allocated at runtime.',
        'Efficient insert and delete: inserting at the beginning is O(1) with no shifting.',
        'No wasted memory: you use exactly as much memory as the nodes you need.'
      ],
      limitations: [
        'No random access: there is no direct arr[5]; you must traverse from the head (O(n)).',
        'Extra memory overhead: every node stores the next pointer along with its data.'
      ],
      complexities: {
        access: 'O(n) — must iterate from the head',
        search: 'O(n) — linear traversal',
        insertion: 'O(1) at the head, O(n) at the tail without a tail pointer',
        deletion: 'O(1) at the head, O(n) at a position',
        space: 'O(n) plus pointer overhead'
      }
    },
    visualTrace: {
      title: 'Singly linked list: inserting a new node at the head',
      steps: [
        {
          stepNumber: 1,
          description:
            'Initial list: the head pointer points to Node(10). Node(10) -> Node(20) -> Node(30) -> NULL.',
          nodes: [
            { id: 1, val: 10, nextVal: '20', isHead: true, state: 'normal' },
            { id: 2, val: 20, nextVal: '30', isHead: false, state: 'normal' },
            { id: 3, val: 30, nextVal: 'NULL', isHead: false, state: 'normal' }
          ],
          highlightText: 'Head = Node 10.'
        },
        {
          stepNumber: 2,
          description: 'Create a new Node(5) whose next pointer is initially NULL.',
          nodes: [
            { id: 0, val: 5, nextVal: 'NULL', isHead: false, state: 'new' },
            { id: 1, val: 10, nextVal: '20', isHead: true, state: 'normal' },
            { id: 2, val: 20, nextVal: '30', isHead: false, state: 'normal' },
            { id: 3, val: 30, nextVal: 'NULL', isHead: false, state: 'normal' }
          ],
          highlightText: 'New Node(5) has been allocated in memory.'
        },
        {
          stepNumber: 3,
          description: 'Point the new Node(5) next pointer at the old head (Node 10).',
          nodes: [
            { id: 0, val: 5, nextVal: '10', isHead: false, state: 'linking' },
            { id: 1, val: 10, nextVal: '20', isHead: true, state: 'normal' },
            { id: 2, val: 20, nextVal: '30', isHead: false, state: 'normal' },
            { id: 3, val: 30, nextVal: 'NULL', isHead: false, state: 'normal' }
          ],
          highlightText: 'newNode.next = Head.'
        },
        {
          stepNumber: 4,
          description: 'Update the head pointer to the new Node(5). The list is ready without any shifting.',
          nodes: [
            { id: 0, val: 5, nextVal: '10', isHead: true, state: 'inserted' },
            { id: 1, val: 10, nextVal: '20', isHead: false, state: 'normal' },
            { id: 2, val: 20, nextVal: '30', isHead: false, state: 'normal' },
            { id: 3, val: 30, nextVal: 'NULL', isHead: false, state: 'normal' }
          ],
          highlightText: 'Done in O(1) time. New head = Node 5.'
        }
      ]
    },
    codeSnippets: {
      javascript: `// Singly linked list in JavaScript
class Node {
  constructor(val) {
    this.val = val;
    this.next = null;
  }
}

class LinkedList {
  constructor() {
    this.head = null;
  }

  // Insert at the head (O(1) time)
  insertAtHead(val) {
    const newNode = new Node(val);
    newNode.next = this.head;
    this.head = newNode;
  }

  // Traversal (O(n) time)
  printList() {
    let curr = this.head;
    const elements = [];
    while (curr !== null) {
      elements.push(curr.val);
      curr = curr.next;
    }
    console.log(elements.join(" -> ") + " -> NULL");
  }
}

const list = new LinkedList();
list.insertAtHead(30);
list.insertAtHead(20);
list.insertAtHead(10);
list.printList(); // 10 -> 20 -> 30 -> NULL`,

      python: `# Singly linked list in Python
class Node:
    def __init__(self, val):
        self.val = val
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    # Insert at head: O(1)
    def insert_at_head(self, val):
        new_node = Node(val)
        new_node.next = self.head
        self.head = new_node

    # Print list: O(n)
    def display(self):
        curr = self.head
        res = []
        while curr:
            res.append(str(curr.val))
            curr = curr.next
        print(" -> ".join(res) + " -> NULL")

ll = LinkedList()
ll.insert_at_head(30)
ll.insert_at_head(20)
ll.insert_at_head(10)
ll.display() # 10 -> 20 -> 30 -> NULL`,

      cpp: `// Singly linked list in C++
#include <iostream>

struct Node {
    int val;
    Node* next;
    Node(int v) : val(v), next(nullptr) {}
};

void insertAtHead(Node*& head, int val) {
    Node* newNode = new Node(val);
    newNode->next = head;
    head = newNode; // O(1)
}

void printList(Node* head) {
    Node* curr = head;
    while(curr != nullptr) {
        std::cout << curr->val << " -> ";
        curr = curr->next;
    }
    std::cout << "NULL\\n";
}

int main() {
    Node* head = nullptr;
    insertAtHead(head, 30);
    insertAtHead(head, 20);
    insertAtHead(head, 10);
    printList(head); // 10 -> 20 -> 30 -> NULL
    return 0;
}`
    },
    practice: {
      question: 'Compared with an array, what is the biggest disadvantage of a linked list?',
      options: [
        { text: 'Its size cannot be changed.', isCorrect: false },
        {
          text: 'A random index (like arr[5]) cannot be accessed in O(1); you must traverse from the start.',
          isCorrect: true
        },
        { text: 'It can only store strings, not numbers.', isCorrect: false },
        { text: 'The head node can never be deleted.', isCorrect: false }
      ],
      explanation:
        'The correct answer is B. A linked list has no contiguous memory, so the direct index formula does not work. You have to start at the head and jump forward n steps (O(n) time).'
    }
  },

  {
    id: 'stacks',
    name: 'Stacks',
    subtitle: 'LIFO — last in, first out',
    icon: '🥞',
    difficulty: 'Beginner',
    estimatedTime: '8 min',
    summary: 'A linear structure that follows the LIFO principle: the last item added is the first one removed.',
    audioScript:
      'A stack is a very interesting data structure that follows the LIFO principle. LIFO means Last In, First Out. Think of a pile of plates at a buffet: the last plate placed on top is the first one people pick up. Pressing Ctrl Z to undo in a text editor, or pressing the back button in a browser, both work using a stack. Its main operations, push, pop and peek, all take O(1) time.',
    concept: {
      tagline: 'A pile of buffet plates — the last plate placed is the first one taken.',
      whatIsIt:
        'A stack is a restricted linear data structure in which insertions and deletions happen at only one end, called the TOP. Its golden rule is LIFO (Last-In, First-Out).',
      realLifeAnalogy:
        '1) A pile of plates in the kitchen.\n2) The back button history in a browser.\n3) Undo (Ctrl+Z) and Redo in text editors.\n4) The function call stack when you run nested functions.',
      whyUse: [
        'Strict order guarantee: perfect for processing things in reverse order.',
        'Blazing fast: push (add), pop (remove) and peek (check the top) all take O(1) constant time.',
        'Memory efficient: only a single top pointer needs to be maintained.'
      ],
      limitations: [
        'No middle access: you cannot read or edit an element in the middle until all the elements above it have been popped.'
      ],
      complexities: {
        push: 'O(1) — place an element on top',
        pop: 'O(1) — remove the top element',
        peek: 'O(1) — look at the top element',
        search: 'O(n) — must traverse',
        space: 'O(n)'
      }
    },
    visualTrace: {
      title: 'Stack operations: push(10), push(20), push(30), then pop()',
      steps: [
        {
          stepNumber: 1,
          description: 'Empty stack: the stack is empty right now. TOP pointer = -1 (NULL).',
          stackItems: [],
          topIndex: -1,
          highlightText: 'Stack initialized (empty).'
        },
        {
          stepNumber: 2,
          description: 'push(10): 10 sits at the bottom. TOP now points to 10.',
          stackItems: [10],
          topIndex: 0,
          highlightText: 'push(10) -> Top = 10'
        },
        {
          stepNumber: 3,
          description: 'push(20): 20 is placed on top of 10. TOP = 20.',
          stackItems: [20, 10],
          topIndex: 0,
          highlightText: 'push(20) -> Top = 20'
        },
        {
          stepNumber: 4,
          description: 'push(30): 30 is now at the very top. TOP = 30.',
          stackItems: [30, 20, 10],
          topIndex: 0,
          highlightText: 'push(30) -> Top = 30'
        },
        {
          stepNumber: 5,
          description: 'pop() is called. The last item added (30) is removed. TOP goes back to 20 (LIFO).',
          stackItems: [20, 10],
          topIndex: 0,
          highlightText: 'pop() returned 30. New Top = 20.'
        }
      ]
    },
    codeSnippets: {
      javascript: `// Stack implementation using an array in JavaScript
class Stack {
  constructor() {
    this.items = [];
  }

  // Push: add an element (O(1))
  push(element) {
    this.items.push(element);
  }

  // Pop: remove the top element (O(1))
  pop() {
    if (this.isEmpty()) return "Underflow! The stack is empty";
    return this.items.pop();
  }

  // Peek: look at the top element only (O(1))
  peek() {
    if (this.isEmpty()) return null;
    return this.items[this.items.length - 1];
  }

  isEmpty() {
    return this.items.length === 0;
  }
}

const myStack = new Stack();
myStack.push(10);
myStack.push(20);
myStack.push(30);
console.log("Top element:", myStack.peek()); // 30
console.log("Popped element:", myStack.pop()); // 30
console.log("New Top element:", myStack.peek()); // 20`,

      python: `# Stack in Python (using a list)
class Stack:
    def __init__(self):
        self.items = []

    def push(self, val):
        self.items.append(val) # O(1)

    def pop(self):
        if not self.is_empty():
            return self.items.pop() # O(1)
        return "Stack is empty"

    def peek(self):
        if not self.is_empty():
            return self.items[-1] # O(1)
        return None

    def is_empty(self):
        return len(self.items) == 0

s = Stack()
s.push(10)
s.push(20)
s.push(30)
print("Top:", s.peek()) # 30
print("Popped:", s.pop()) # 30
print("New Top:", s.peek()) # 20`,

      cpp: `// std::stack in C++
#include <iostream>
#include <stack>

int main() {
    std::stack<int> s;

    // Push: O(1)
    s.push(10);
    s.push(20);
    s.push(30);

    // Peek (top in C++): O(1)
    std::cout << "Top element: " << s.top() << "\\n"; // 30

    // Pop: O(1)
    s.pop();
    std::cout << "New Top element: " << s.top() << "\\n"; // 20

    return 0;
}`
    },
    practice: {
      question:
        'If we push A, B and C into a stack in that order and then call pop() once, which element comes out?',
      options: [
        { text: 'Element A', isCorrect: false },
        { text: 'Element B', isCorrect: false },
        { text: 'Element C, because C was pushed last (Last In, First Out).', isCorrect: true },
        { text: 'Any random element can come out.', isCorrect: false }
      ],
      explanation:
        'The correct answer is C. A stack follows LIFO. The sequence was push A, push B, push C (C is at the TOP). Popping removes the top element, which is C.'
    }
  },

  {
    id: 'queues',
    name: 'Queues',
    subtitle: 'FIFO — first in, first out',
    icon: '🎟️',
    difficulty: 'Beginner',
    estimatedTime: '8 min',
    summary: 'A data structure that follows the FIFO principle: whoever arrives first is served first.',
    audioScript:
      'A queue simply means a line. Its rule is FIFO, which stands for First In, First Out. Picture the line at a cinema ticket counter: the person who is first in line gets their ticket first and leaves first. New people join at the back, which is called enqueue, and people leave from the front after being served, which is called dequeue. Print jobs in a printer and customer care call queues are live examples.',
    concept: {
      tagline: 'A cinema ticket line — whoever arrives first gets their ticket first.',
      whatIsIt:
        'A queue is a linear data structure that follows the FIFO (First-In, First-Out) principle. It has two ends: the REAR, where new elements enter, and the FRONT, where elements leave.',
      realLifeAnalogy:
        '1) A bus stop or movie ticket line.\n2) An office printer: the print command sent first is printed first.\n3) A music playlist "Play next" queue.\n4) Requests arriving at a web server are processed in a queue.',
      whyUse: [
        'Fairness guarantee: it maintains first-come, first-served order.',
        'Asynchronous buffering: useful when the producer of data is fast and the consumer is slow (like a video streaming buffer).'
      ],
      limitations: [
        'In a simple array queue, removing from the front needs O(n) shifting, which is why a circular queue or linked list works better.'
      ],
      complexities: {
        enqueue: 'O(1) — add at the rear end',
        dequeue: 'O(1) — remove from the front (with a pointer or linked list)',
        peek: 'O(1) — look at the front element',
        search: 'O(n)',
        space: 'O(n)'
      }
    },
    visualTrace: {
      title: 'Queue trace: enqueue(A), enqueue(B), enqueue(C), then dequeue()',
      steps: [
        {
          stepNumber: 1,
          description: 'Empty queue: both FRONT and REAR are empty.',
          queueItems: [],
          highlightText: 'Queue initialized (empty).'
        },
        {
          stepNumber: 2,
          description: 'enqueue("A"): A stands at the front of the line. FRONT = A, REAR = A.',
          queueItems: ['A'],
          highlightText: 'enqueue("A") at the rear'
        },
        {
          stepNumber: 3,
          description: 'enqueue("B"): B joins the line behind A. FRONT = A, REAR = B.',
          queueItems: ['A', 'B'],
          highlightText: 'enqueue("B") at the rear'
        },
        {
          stepNumber: 4,
          description: 'enqueue("C"): C joins at the end of the line. FRONT = A, REAR = C.',
          queueItems: ['A', 'B', 'C'],
          highlightText: 'enqueue("C") at the rear'
        },
        {
          stepNumber: 5,
          description: 'dequeue() is called. A arrived first, so A leaves first (FIFO). The new FRONT is B.',
          queueItems: ['B', 'C'],
          highlightText: 'dequeue() removed "A". Next in line is "B".'
        }
      ]
    },
    codeSnippets: {
      javascript: `// Queue implementation in JavaScript (object with pointers, O(1))
class Queue {
  constructor() {
    this.items = {};
    this.front = 0;
    this.rear = 0;
  }

  // Enqueue: join the line (O(1))
  enqueue(val) {
    this.items[this.rear] = val;
    this.rear++;
  }

  // Dequeue: remove from the front (O(1))
  dequeue() {
    if (this.isEmpty()) return "Queue is empty";
    const removedItem = this.items[this.front];
    delete this.items[this.front];
    this.front++;
    return removedItem;
  }

  peek() {
    return this.items[this.front];
  }

  isEmpty() {
    return this.rear - this.front === 0;
  }
}

const q = new Queue();
q.enqueue("Student A");
q.enqueue("Student B");
q.enqueue("Student C");
console.log("Front element:", q.peek()); // Student A
console.log("Served:", q.dequeue()); // Student A
console.log("New Front:", q.peek()); // Student B`,

      python: `# collections.deque in Python (efficient O(1) queue)
from collections import deque

queue = deque()

# Enqueue (add at the rear)
queue.append("Document 1")
queue.append("Document 2")
queue.append("Document 3")

# Peek at the front
print("Front doc:", queue[0]) # Document 1

# Dequeue (remove from the front)
served = queue.popleft() # O(1)
print("Printed:", served) # Document 1
print("Remaining in queue:", list(queue)) # ['Document 2', 'Document 3']`,

      cpp: `// std::queue in C++
#include <iostream>
#include <queue>
#include <string>

int main() {
    std::queue<std::string> q;

    // Enqueue: O(1)
    q.push("Person A");
    q.push("Person B");
    q.push("Person C");

    // Front element
    std::cout << "Front: " << q.front() << "\\n"; // Person A

    // Dequeue: O(1)
    q.pop();
    std::cout << "New Front: " << q.front() << "\\n"; // Person B

    return 0;
}`
    },
    practice: {
      question: 'What is the core difference between a queue and a stack?',
      options: [
        { text: 'A queue uses LIFO, while a stack uses FIFO.', isCorrect: false },
        { text: 'In a queue, elements can be accessed randomly from both ends.', isCorrect: false },
        {
          text: 'A queue follows FIFO (First-In, First-Out), while a stack follows LIFO (Last-In, First-Out).',
          isCorrect: true
        },
        { text: 'A queue does not allocate memory.', isCorrect: false }
      ],
      explanation:
        'The correct answer is C. A queue follows FIFO (a line system), while a stack follows LIFO (a pile of plates).'
    }
  },

  {
    id: 'recursion',
    name: 'Recursion',
    subtitle: 'A function that calls itself',
    icon: '🪆',
    difficulty: 'Intermediate',
    estimatedTime: '12 min',
    summary: 'A function that calls itself repeatedly to solve smaller sub-problems.',
    audioScript:
      'Recursion is a magical concept in programming. When a function calls itself, we call it recursion. It rests on two essential pillars: first the base case, and second the recursive relation. The base case is the stop button that tells the recursion when to end. If you forget to write a base case, the function keeps calling itself and you get a stack overflow. Think of opening a Russian doll, finding a smaller doll inside, until you reach the last solid doll.',
    concept: {
      tagline: 'A Russian doll (Matryoshka) — a smaller doll inside each one, until you reach the last solid doll.',
      whatIsIt:
        'Recursion is a technique where a function solves a big problem by calling itself on a smaller sub-problem. It works on top of the call stack in memory.',
      realLifeAnalogy:
        '1) Russian nesting dolls: open each doll and find a smaller one inside. When you reach the last doll that cannot be opened (the base case), you stop and start closing everything back up.\n2) Two mirrors facing each other: infinite reflections, but in a computer a stopping point is essential.',
      whyUse: [
        'Clean and elegant code: complex tree traversals and divide-and-conquer problems become much simpler.',
        'Natural for hierarchical data: recursion is a natural fit for trees, graphs and parsing nested JSON.'
      ],
      limitations: [
        'Call stack overhead: every function call takes a stack frame in memory.',
        'Stack overflow risk: a missing base case, or a very deep recursion, can crash the program.'
      ],
      complexities: {
        time: 'Depends on branching: e.g. factorial is O(n), Fibonacci is O(2ⁿ)',
        space: 'O(depth of the recursion tree) — call stack memory'
      }
    },
    visualTrace: {
      title: 'Call stack trace: factorial(3) (3! = 3 × 2 × 1 = 6)',
      steps: [
        {
          stepNumber: 1,
          description:
            'The main program calls fact(3). To calculate fact(3) it needs 3 * fact(2), so fact(3) waits on the call stack.',
          callStack: [{ func: 'fact(3)', state: 'Waiting for fact(2)', val: '3 * ?' }],
          highlightText: 'fact(3) pushed to the call stack.'
        },
        {
          stepNumber: 2,
          description: 'fact(2) executes. It needs 2 * fact(1), so fact(2) is added to the stack as well.',
          callStack: [
            { func: 'fact(2)', state: 'Waiting for fact(1)', val: '2 * ?' },
            { func: 'fact(3)', state: 'Waiting for fact(2)', val: '3 * ?' }
          ],
          highlightText: 'fact(2) pushed on top of fact(3).'
        },
        {
          stepNumber: 3,
          description:
            'fact(1) executes. BASE CASE HIT! The condition if (n <= 1) is true, so fact(1) returns 1.',
          callStack: [
            { func: 'fact(1)', state: 'Base Case Hit! Returns 1', val: '1' },
            { func: 'fact(2)', state: 'Waiting for fact(1)', val: '2 * ?' },
            { func: 'fact(3)', state: 'Waiting for fact(2)', val: '3 * ?' }
          ],
          highlightText: 'Base case reached! Unwinding begins.'
        },
        {
          stepNumber: 4,
          description: 'Unwinding: fact(1) is popped. fact(2) calculates 2 * 1 = 2 and returns 2.',
          callStack: [
            { func: 'fact(2)', state: 'Calculated 2 * 1 = 2', val: '2' },
            { func: 'fact(3)', state: 'Waiting for fact(2)', val: '3 * ?' }
          ],
          highlightText: 'fact(2) completes and returns 2 to fact(3).'
        },
        {
          stepNumber: 5,
          description: 'fact(3) receives 2 and calculates 3 * 2 = 6. The final answer is 6, and the stack is empty again.',
          callStack: [{ func: 'fact(3)', state: 'Calculated 3 * 2 = 6', val: 'Final: 6' }],
          highlightText: 'Final result: 6 (stack unwound completely).'
        }
      ]
    },
    codeSnippets: {
      javascript: `// Factorial using recursion in JavaScript
function factorial(n) {
  // 1. BASE CASE (the stopping condition)
  if (n <= 1) {
    return 1;
  }

  // 2. RECURSIVE RELATION (break into a smaller problem)
  return n * factorial(n - 1);
}

console.log("3! =", factorial(3)); // 6
console.log("5! =", factorial(5)); // 120`,

      python: `# Factorial recursion in Python
def factorial(n):
    # 1. Base case: if n is 1 or 0, return 1
    if n <= 1:
        return 1

    # 2. Recursive step
    return n * factorial(n - 1)

print("3! =", factorial(3)) # 6
print("5! =", factorial(5)) # 120`,

      cpp: `// Factorial in C++
#include <iostream>

long long factorial(int n) {
    // 1. Base case
    if (n <= 1) {
        return 1;
    }
    // 2. Recursive call
    return n * factorial(n - 1);
}

int main() {
    std::cout << "3! = " << factorial(3) << "\\n"; // 6
    std::cout << "5! = " << factorial(5) << "\\n"; // 120
    return 0;
}`
    },
    practice: {
      question: 'What happens if we do not write a base case in a recursive function?',
      options: [
        { text: 'The program returns 0.', isCorrect: false },
        {
          text: 'The program makes infinite calls and crashes with a "Stack Overflow" once the call stack is full.',
          isCorrect: true
        },
        { text: 'The compiler automatically converts the code into a loop.', isCorrect: false },
        { text: 'The memory is cleared automatically.', isCorrect: false }
      ],
      explanation:
        'The correct answer is B. The base case is the brake of recursion. Without it, the function keeps pushing new frames onto the call stack until the memory limit is exceeded (a stack overflow error).'
    }
  },

  {
    id: 'sorting',
    name: 'Sorting',
    subtitle: 'Putting items in order',
    icon: '📶',
    difficulty: 'Intermediate',
    estimatedTime: '10 min',
    summary: 'Algorithms that arrange elements in ascending or descending order.',
    audioScript:
      'Sorting is one of the most popular use cases in programming. Arranging data in a sequence or order is called sorting. For example, sorting prices from low to high in an e-commerce app, or viewing names alphabetically in a phone book. For beginners, bubble sort and selection sort are the easiest to understand. In bubble sort, the largest element floats to the end in every pass, just like a bubble rising in water.',
    concept: {
      tagline: 'Lining up children by height on an assembly line.',
      whatIsIt:
        'Sorting is a technique that arranges an unsorted list in a specific order (small to large or large to small). It also makes searching fast (O(log n) binary search).',
      realLifeAnalogy:
        '1) Sorting playing cards in your hand.\n2) Standing in height order at a school assembly.\n3) Words in alphabetical order in a dictionary.',
      whyUse: [
        'Fast searching: on a sorted array we can use binary search in O(log n) time.',
        'Clear data analysis: finding the minimum, maximum and median becomes instant.',
        'Data presentation: the user experience improves (for example a price low-to-high filter).'
      ],
      limitations: [
        'Simple sorts (bubble and selection) take O(n²) time, which is slow for large data. For large data, merge sort or quick sort at O(n log n) is used.'
      ],
      complexities: {
        bubbleSort: 'Best: O(n) | Worst: O(n²)',
        selectionSort: 'Always O(n²)',
        mergeSort: 'Always O(n log n)',
        quickSort: 'Avg: O(n log n) | Worst: O(n²)'
      }
    },
    visualTrace: {
      title: 'Bubble sort visual trace on [5, 1, 4, 2]',
      steps: [
        {
          stepNumber: 1,
          description: 'Pass 1, step 1: compare index 0 (5) and index 1 (1). Since 5 > 1, swap them.',
          elements: [
            { val: 1, state: 'swapped' },
            { val: 5, state: 'swapped' },
            { val: 4, state: 'normal' },
            { val: 2, state: 'normal' }
          ],
          highlightText: '5 > 1: swapped! [1, 5, 4, 2]'
        },
        {
          stepNumber: 2,
          description: 'Pass 1, step 2: compare index 1 (5) and index 2 (4). Since 5 > 4, swap them.',
          elements: [
            { val: 1, state: 'normal' },
            { val: 4, state: 'swapped' },
            { val: 5, state: 'swapped' },
            { val: 2, state: 'normal' }
          ],
          highlightText: '5 > 4: swapped! [1, 4, 5, 2]'
        },
        {
          stepNumber: 3,
          description:
            'Pass 1, step 3: compare index 2 (5) and index 3 (2). Since 5 > 2, swap them. The largest number, 5, has reached the last position (the bubble floated up).',
          elements: [
            { val: 1, state: 'normal' },
            { val: 4, state: 'normal' },
            { val: 2, state: 'swapped' },
            { val: 5, state: 'sorted' }
          ],
          highlightText: '5 reached its final sorted position at index 3.'
        },
        {
          stepNumber: 4,
          description: 'Pass 2: in the next pass, 4 and 2 are compared. 4 > 2, so swap -> [1, 2, 4, 5]. All elements are sorted.',
          elements: [
            { val: 1, state: 'sorted' },
            { val: 2, state: 'sorted' },
            { val: 4, state: 'sorted' },
            { val: 5, state: 'sorted' }
          ],
          highlightText: 'Array fully sorted: [1, 2, 4, 5]!'
        }
      ]
    },
    codeSnippets: {
      javascript: `// Bubble sort in JavaScript
function bubbleSort(arr) {
  const n = arr.length;
  let swapped;

  for (let i = 0; i < n - 1; i++) {
    swapped = false;
    for (let j = 0; j < n - i - 1; j++) {
      // If the previous element is larger than the next, swap them
      if (arr[j] > arr[j + 1]) {
        [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
        swapped = true;
      }
    }
    // If no swap happened in a pass, the array is already sorted
    if (!swapped) break;
  }
  return arr;
}

const numbers = [5, 1, 4, 2];
console.log("Sorted Array:", bubbleSort(numbers)); // [1, 2, 4, 5]`,

      python: `# Bubble sort in Python
def bubble_sort(arr):
    n = len(arr)
    for i in range(n - 1):
        swapped = False
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break
    return arr

nums = [5, 1, 4, 2]
print("Sorted Array:", bubble_sort(nums)) # [1, 2, 4, 5]`,

      cpp: `// Bubble sort in C++
#include <iostream>
#include <vector>

void bubbleSort(std::vector<int>& arr) {
    int n = arr.size();
    for (int i = 0; i < n - 1; i++) {
        bool swapped = false;
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                std::swap(arr[j], arr[j + 1]);
                swapped = true;
            }
        }
        if (!swapped) break;
    }
}

int main() {
    std::vector<int> nums = {5, 1, 4, 2};
    bubbleSort(nums);
    for (int x : nums) std::cout << x << " ";
    return 0;
}`
    },
    practice: {
      question: 'What is the worst-case time complexity of bubble sort?',
      options: [
        { text: 'O(n)', isCorrect: false },
        { text: 'O(n log n)', isCorrect: false },
        { text: 'O(n²), when the array is reverse sorted and the nested loops must run in full.', isCorrect: true },
        { text: 'O(1)', isCorrect: false }
      ],
      explanation:
        'The correct answer is C. If the array is completely reverse ordered (like [5, 4, 3, 2, 1]), every element needs up to n comparisons, so the total time is O(n²).'
    }
  }
];

export const QUICK_QUESTIONS = [
  'What is the difference?',
  'Time complexity summary?',
  'Give me a real-life example',
  'Interview tip?',
  'How does a stack overflow happen?'
];

export const MENTOR_TIPS = [
  'Once the concept is clear, step through the visual tracer to see every operation animated.',
  'You do not need to memorize code. Understand the intuition, then do a dry run by hand.',
  'Interview hack: when you state the time complexity, mention the best, average and worst cases.'
];

const topicSpecific = (topic, map, fallback) => map[topic?.id] ?? fallback;

// Contextual responses for student doubts (demo mode, no API key needed)
export const getDemoResponse = (question, currentTopic) => {
  const q = question.toLowerCase();
  const topicName = currentTopic ? currentTopic.name : 'DSA';

  if (q.includes('difference') || q.includes('vs') || q.includes('compare')) {
    if (q.includes('array') && q.includes('linked list')) {
      return `Great question! The difference between an array and a linked list comes down to memory and access speed:
1) Memory: an array uses contiguous memory (in one block), while a linked list's nodes are scattered and connected by pointers.
2) Random access: arr[i] is O(1) in an array, but a linked list must be traversed from the head (O(n)).
3) Insertion/deletion: inserting at the start of a linked list is O(1), while an array has to shift elements (O(n)).
Rule of thumb: use an array when you need fast lookup; use a linked list when you have frequent insertions and deletions and the size is unknown.`;
    }
    if (q.includes('stack') && q.includes('queue')) {
      return `The biggest difference between a stack and a queue is the order in which items leave:
- Stack: LIFO (Last In, First Out). The last item in is the first one out, like a pile of plates at a buffet.
- Queue: FIFO (First In, First Out). The first item in is the first one served, like a line at a cinema ticket counter.
A stack uses 'push' and 'pop'; a queue uses 'enqueue' and 'dequeue'.`;
    }
  }

  if (q.includes('time complexity') || q.includes('complexity') || q.includes('big o') || q.includes('speed')) {
    const details = topicSpecific(
      currentTopic,
      {
        arrays:
          '• Access by index: O(1) (super fast)\n• Search: O(n) linear search\n• Insert/delete at the end: O(1)\n• Insert/delete at the beginning or middle: O(n) because of shifting.',
        'linked-lists':
          '• Access by index: O(n) (you must traverse)\n• Insert at head: O(1) (instant)\n• Delete at head: O(1)\n• Search: O(n)',
        stacks:
          '• Push: O(1)\n• Pop: O(1)\n• Peek/Top: O(1)\n• All the basic stack operations take constant time.',
        queues:
          '• Enqueue (add at rear): O(1)\n• Dequeue (remove from front): O(1) with pointers\n• Peek (front): O(1)',
        recursion:
          '• The complexity depends on the call tree and its branching factor.\n• Factorial: O(n) calls\n• Fibonacci (naive): O(2ⁿ) exponential calls\n• Space complexity is always O(recursion depth) because of the call stack.'
      },
      '• Bubble sort: best O(n), worst O(n²)\n• Selection sort: always O(n²)\n• Merge sort: always O(n log n)\n• Quick sort: average O(n log n), worst O(n²)'
    );
    return `Summary of the time complexities for "${topicName}":\n${details}`;
  }

  if (q.includes('real life') || q.includes('real-life') || q.includes('example') || q.includes('use case')) {
    const uses = topicSpecific(
      currentTopic,
      {
        arrays:
          '• Image processing (pixels are stored in 2D arrays)\n• Video buffering frames\n• High-performance lookup tables',
        'linked-lists':
          '• Music player previous/next song playlist\n• Web browser back/forward history\n• Free list for memory allocation in an operating system',
        stacks:
          '• Undo (Ctrl+Z) and redo (Ctrl+Y) in text editors\n• Browser history back button\n• Evaluating mathematical expressions (parenthesis matching in compilers)',
        queues:
          '• Printer spooler (multiple documents printing)\n• Ride-hailing apps (booking request queue)\n• Video streaming chunk buffer',
        recursion:
          '• Searching sub-folders inside folders in a file explorer\n• DOM tree traversal in HTML\n• Chess AI minimax algorithm'
      },
      '• Sorting products by price or rating in e-commerce\n• Ranking search results\n• Leaderboards in gaming apps'
    );
    return `Real-life analogy for ${topicName}:\n${currentTopic.concept.realLifeAnalogy}\n\nWhere it is used in real software:\n${uses}`;
  }

  if (q.includes('overflow')) {
    return `A stack overflow happens when the call stack or stack memory exceeds its limit.
The most common cause is forgetting the BASE CASE in recursion, or writing the condition incorrectly. When a function keeps calling itself, function frames pile up in memory until the program crashes.
How to avoid it: always write the stopping condition (base case) first, and check that the recursive argument moves toward the base case with every call.`;
  }

  if (q.includes('pointer') || q.includes('address')) {
    return `A pointer is a variable that holds the memory address of another value.
Think of an address written on a slip of paper. In a linked list, each node holds the address of the next node. In C++ we use '*' and '&', while in JavaScript and Python objects are passed by reference automatically.`;
  }

  if (q.includes('interview') || q.includes('tip') || q.includes('question')) {
    const tip = topicSpecific(
      currentTopic,
      {
        arrays: 'Prepare the two-pointer technique and sliding window patterns well.',
        'linked-lists': 'Fast and slow pointers (Floyd cycle detection) are an interviewer favorite.',
        stacks: 'The valid parentheses problem and the monotonic stack concept are asked very often.',
        queues: 'Focus on implementing a queue using two stacks, and on BFS (breadth-first search).',
        recursion: 'Define the base case first, and draw the recursion tree to explain it to the interviewer.'
      },
      'Know the stability of sorting algorithms and be clear on the trade-off between O(n log n) and O(n²).'
    );
    return `Interview tips for ${topicName}:
1. State the time and space complexity before writing the full code.
2. Check edge cases: an empty structure, a single element, duplicates and negative numbers.
3. ${tip}`;
  }

  return `Good question! It is completely normal to have this doubt while learning "${topicName}".
The idea: ${currentTopic.summary}
Key takeaway: ${currentTopic.concept.tagline}
Suggestion: open the "Visual Walkthrough" tab to see the step-by-step animation, or try the "Code" tab to see an implementation. If you are unsure about a specific line or complexity, just ask!`;
};
