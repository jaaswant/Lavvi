// Topic ideas shown on the home page and in search suggestions.
export const CATEGORIES = [
  { title: 'Science', topics: ['Photosynthesis', 'Black holes', 'How vaccines work', 'The water cycle'] },
  { title: 'History and civics', topics: ['The French Revolution', 'Indian Constitution', 'Mughal architecture', 'The Cold War'] },
  { title: 'Money', topics: ['Compound interest', 'GST in India', 'Inflation', 'How the stock market works'] },
  { title: 'Technology', topics: ['Machine learning', 'How the internet works', 'Blockchain', 'How GPS works'] }
];

export const IDEAS = CATEGORIES.flatMap((c) => c.topics);
