import { Readable } from 'node:stream';
import { handleRequest } from '../../server/index.js';

const FUNCTION_PREFIX = '/.netlify/functions/api';

export async function handler(event) {
  const eventPath = event.path || '/';
  const routePath = eventPath.startsWith(`${FUNCTION_PREFIX}/`)
    ? `/api/${eventPath.slice(FUNCTION_PREFIX.length + 1)}`
    : eventPath;
  const encodedBody = event.httpMethod === 'GET' || event.httpMethod === 'HEAD' ? '' : event.body || '';
  const body = event.isBase64Encoded ? Buffer.from(encodedBody, 'base64').toString('utf8') : encodedBody;
  const req = Readable.from(body ? [body] : []);
  req.method = event.httpMethod;
  req.url = routePath;

  let statusCode = 200;
  let headers = {};
  let responseBody = '';
  const res = {
    writeHead(status, responseHeaders) {
      statusCode = status;
      headers = responseHeaders;
    },
    end(content = '') {
      responseBody = content;
    }
  };

  await handleRequest(req, res, true);
  return { statusCode, headers, body: responseBody };
}
