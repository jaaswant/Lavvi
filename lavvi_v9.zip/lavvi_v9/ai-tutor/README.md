# Lavvi

Search any topic and Lavvi explains it: spoken in Hinglish, written in English, with a visual walkthrough, code, quizzes, flashcards and notes.

## What's new in this version
- **Compare any two concepts:** type two things (arrays vs linked lists, RAM vs ROM, supervised vs unsupervised learning) and get a side-by-side table, what they share, when to pick which, common mix-ups, a memory trick, a Hinglish summary, plus flashcards and a quiz made from the comparison. Copy or download as Markdown.
- **Notes scanner:** upload up to 4 photos of handwritten notes. Lavvi reads them, shows the text "as written" and "cleaned up" (editable, with a list of words it was unsure about), explains any paragraph you select, and makes revision material: summary, key terms, the hard parts explained (English or Hinglish, with examples), flashcards, a quiz and a short revision plan. Download everything as Markdown.
- Both are in the top bar and on the home page. They need the AI server (a `GEMINI_API_KEY`, which has a free tier, or an `ANTHROPIC_API_KEY`); photos are resized in the browser, sent to your server and on to the AI provider, and are not stored.

### Earlier in this version
- **Renamed to Lavvi**, with a simple logo (a yellow L and a spark on a dark tile).
- **Diagrams for any topic:** AI lessons now include a flow, cycle, timeline, parts or compare diagram you can step through (Diagram tab). Wikipedia lessons get a parts diagram.
- **Cleaner home page:** the DSA course list is gone from the front page. Search "Arrays", "Stacks", "Sorting" etc. to open those lessons, with their visual walkthrough.

## Everything else
- **New design:** a "Notebook" light theme (graph paper, margin line, highlighter) and a "Blackboard" dark theme. Toggle in the top bar.
- **Hinglish teacher:** Lavvi speaks Hinglish by default (switch to English any time), captions stay in English. Pick a voice, speed, jump between parts.
- **Quiz:** 5 questions per built-in lesson with explanations, results and "retry the ones I missed".
- **Flashcards**, **Notes** (download as Markdown), **Save lesson**, recent lessons.
- **Daily challenge:** 5 mixed questions, new every day.
- **XP, levels and a study streak**, plus a Pomodoro study timer.
- **Code tab:** syntax highlighting, download, and "Run code" for JavaScript (runs in a sandboxed worker).
- **Chat:** voice input (mic), listen to answers, copy.
- **Search suggestions**, `/` to focus search, arrow keys for walkthroughs and flashcards, 1-4 for quiz answers.
- **AI lessons (with a key):** Hinglish script, 4-question quiz, related topics, and a Simple / Standard / Deep switch.

## Run it
Not working? Run `npm run check`: it tests your key and tells you what Google says.

Easiest: copy `.env.example` to `.env`, paste your key in it, then run `npm install` and `npm start`. Lavvi reads `.env` on startup. Or set the variable in your terminal as below.

```bash
npm install
export GEMINI_API_KEY=...             # free key from https://aistudio.google.com/apikey (GEMINI_MODEL changes the model)
# or: export ANTHROPIC_API_KEY=sk-ant-...   # ANTHROPIC_MODEL changes the model
npm start                              # builds, then serves on http://localhost:8790

# or, for development with hot reload (starts the API and Vite together)
npm run dev
```
Without a key, any non-DSA topic falls back to a Wikipedia lesson (English voice only). Your key stays on the server.

## Deploy to Netlify
The `netlify.toml` file configures the static build and routes `/api/*` requests to a Netlify Function. In your Netlify site settings, add these server-side environment variables:

- `GEMINI_API_KEY` – your Gemini API key
- `GEMINI_MODEL` – `gemini-3.1-flash-lite`

Then deploy or trigger a new deploy so the function receives the variables. Do not add the API key to frontend code or a `VITE_` variable. Since the site is public, protect your key and monitor its usage and quota.

## Structure
- `src/App.jsx` – views (home, lesson, challenge), progress and theme
- `src/lib/progress.js` – XP, streak, saved lessons, notes (localStorage)
- `src/lib/lessons.js` – built-in, AI and Wikipedia lessons
- `src/lib/quiz.js`, `flashcards.js` – question and card generators
- `src/components/ConceptVisual.jsx` – diagrams for non-DSA topics
- `src/data/scripts.js` – Hinglish scripts and extra quiz questions for the DSA course
- `src/components/` – Teacher, TeachingBoard (tabs), Quiz, Flashcards, Notes, DoubtPanel, Header…
- `src/components/Compare.jsx`, `NotesScanner.jsx` – the two new tools; `src/lib/ai.js` – their API calls and photo resizing
- `server/index.js` – lesson, follow-up, `/api/compare`, `/api/scan` and `/api/notes-study`, serves `dist/`
