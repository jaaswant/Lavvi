import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Loads settings from the .env file in the project folder, one NAME=value per line.
// Forgiving on purpose: it copes with quotes, Windows line endings, the invisible BOM that Notepad adds,
// and lines pasted from a terminal such as  $env:GEMINI_API_KEY="..."  or  export GEMINI_API_KEY=...
// A real environment variable wins, unless it is empty.
const envFile = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '.env');
const found = [];

try {
  if (fs.existsSync(envFile)) {
    const buf = fs.readFileSync(envFile);
    // PowerShell's  echo ... > .env  writes UTF-16; everything else is UTF-8 (possibly with a BOM).
    const text = (buf[0] === 0xff && buf[1] === 0xfe ? buf.toString('utf16le') : buf.toString('utf8')).replace(/^\uFEFF/, '');
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.replace(/^\uFEFF/, '').trim();
      if (!line || line.startsWith('#')) continue;
      const m = /^(?:export\s+|set\s+|\$env:)?([A-Za-z0-9_]+)\s*=\s*(.*)$/i.exec(line);
      if (!m) continue;
      const value = m[2].trim().replace(/^(["'])(.*)\1$/, '$2').trim();
      if (value && !process.env[m[1]]?.trim()) {
        process.env[m[1]] = value;
        found.push(m[1]);
      }
    }
    console.log(`[env] Read ${envFile}. Settings found: ${found.length ? found.join(', ') : 'none (is the key line written as GEMINI_API_KEY=your-key ?)'}`);
  } else {
    console.log(`[env] No .env file at ${envFile}. Create it there (copy .env.example), or set the variable in your terminal.`);
  }
} catch (e) {
  console.log(`[env] Could not read ${envFile}: ${e.message}`);
}
