// Tiny API server: generates lessons for ANY topic with Claude, and serves the built app.
// Run:  GEMINI_API_KEY=... node server/index.js   (or ANTHROPIC_API_KEY=sk-ant-...)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import './env.js'; // loads .env before anything below reads process.env


const PORT = process.env.API_PORT || process.env.PORT || 8790;
// Pick the AI provider: Gemini if GEMINI_API_KEY is set (free tier available), otherwise Anthropic.
const GEMINI_KEY = (process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '').trim() || undefined;
const ANTHROPIC_KEY = (process.env.ANTHROPIC_API_KEY || '').trim() || undefined;
const PROVIDER = process.env.LLM_PROVIDER || (GEMINI_KEY ? 'gemini' : 'anthropic');
const KEY = PROVIDER === 'gemini' ? GEMINI_KEY : ANTHROPIC_KEY;
const MODEL = PROVIDER === 'gemini' ? process.env.GEMINI_MODEL || 'gemini-3.1-flash-lite' : process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5';
const NO_KEY = PROVIDER === 'gemini' ? 'GEMINI_API_KEY is not set on the server.' : 'ANTHROPIC_API_KEY is not set on the server.';
const DIST = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist');

const MIME = {
  '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.json': 'application/json'
};

const LEVELS = {
  simple: 'Explain it very simply, as if to a curious 12 year old. Short words, no jargon, one everyday example.',
  standard: 'Explain it for a curious beginner.',
  deep: 'Explain it for a motivated learner who wants more depth: include nuance, edge cases and how experts think about it, but stay clear.'
};

const lessonSystem = (level) => `You are Lavvi, a warm, clear teacher. Write a lesson on the topic the student gives you. ${LEVELS[level] || LEVELS.standard}
Reply with ONE JSON object only (no markdown fences) in exactly this shape:
{
 "title": string, "subtitle": string (max 6 words), "icon": one emoji, "difficulty": "Beginner"|"Intermediate"|"Advanced",
 "estimatedTime": string like "5 min", "summary": one sentence,
 "script": array of 6 to 9 objects { "en": string, "hi": string }. Together they are a spoken walkthrough of the lesson, about 150 to 220 words in English.
   "en" is one or two plain English sentences (no lists, no markdown, no emojis).
   "hi" says the same thing in natural Hinglish: Hindi written in English letters (Roman script), the way an Indian teacher talks in class, keeping technical words in English. Never use Devanagari.,
 "concept": {
   "tagline": one vivid sentence,
   "whatIsIt": 2-3 sentences,
   "realLifeAnalogy": 2-3 sentences using an everyday analogy,
   "whyUse": 3-4 short key points (why it matters),
   "limitations": 2-3 short caveats or common misconceptions,
   "facts": object of 3-5 short label -> value pairs
 },
 "quiz": array of exactly 4 objects { "question": string, "options": [ {"text": string, "isCorrect": boolean} x4, exactly one correct ], "explanation": string },
 "related": array of 3 short topic names the student could study next,
 "visual": a diagram that makes the topic easier to see, or null if no diagram would help. Pick the type that fits:
   "flow" for a process with steps in order, "cycle" for something that repeats (water cycle, photosynthesis), "timeline" for events in time order,
   "parts" for something made of components around one idea, "compare" for two things set side by side.
   For flow, cycle, timeline and parts: { "type", "title": max 5 words, "items": [ { "label": max 3 words, "detail": one clear sentence } ] } with 4 to 7 items (in order for flow, cycle and timeline).
   For compare: { "type": "compare", "title", "columns": [ { "title": string, "points": 3 to 5 short strings }, { "title": string, "points": 3 to 5 short strings } ] }
}
Be accurate. If the topic is unsafe or harmful, teach only the safe, educational side of it. All on-screen text (everything except "hi") is in English.`;


const COMPARE_SYSTEM = `You are Lavvi, a clear teacher. The student gives you two concepts to compare (for example "arrays" and "linked lists", "RAM" and "ROM").
Reply with ONE JSON object only (no markdown fences) in exactly this shape:
{
 "title": string like "Arrays vs Linked lists",
 "a": { "name": string, "oneLiner": one plain sentence },
 "b": { "name": string, "oneLiner": one plain sentence },
 "sameField": boolean (true if both are really in the same field and the comparison makes sense),
 "note": string or "" (use it only if the two are unrelated or ambiguous, to say what you assumed),
 "rows": array of 6 to 8 { "aspect": short label, "a": short phrase or sentence, "b": short phrase or sentence } covering definition, how it works, strengths, weaknesses, speed or cost, typical use, and anything else that really separates them,
 "similarities": array of 2 to 3 short strings,
 "whenToUse": { "a": one sentence, "b": one sentence },
 "mistakes": array of 2 to 3 short strings about common mix-ups between the two,
 "memoryTip": one short, memorable trick to tell them apart,
 "hinglish": 2 to 3 sentences summing up the difference in natural spoken Hinglish (Hindi in English letters, technical words kept in English, never Devanagari),
 "cards": array of 6 { "front": question, "back": short answer } for revision,
 "quiz": array of exactly 4 { "question", "options": [ {"text", "isCorrect": boolean} x4, exactly one correct ], "explanation" }
}
Be accurate and fair to both sides. All text except "hinglish" is English with no markdown and no emojis.`;

const SCAN_SYSTEM = `You read photos of handwritten or printed student notes and turn them into clean text.
Reply with ONE JSON object only (no markdown fences) in exactly this shape:
{
 "readable": boolean (false if there is no legible writing in the image(s)),
 "title": short title for the notes (max 8 words),
 "subject": short subject guess like "Physics" or "Data structures",
 "transcript": the text exactly as written, in reading order, keeping line breaks, headings, bullets and numbers. Mark any word you cannot read as [?]. Do not fix spelling or add content,
 "clean": the same notes cleaned up: spelling and grammar fixed, abbreviations spelled out only when you are sure, headings kept, bullets tidy, formulas written in plain text. Add no new facts. Use "# " for headings and "- " for bullets, nothing else,
 "uncertain": array of up to 8 short strings, each naming a word, number or formula you were not sure about and what you chose,
 "pages": number of pages read
}
If several images are given they are consecutive pages of the same notes. If the writing is not legible, set "readable" to false and explain in "clean".`;

const STUDY_SYSTEM = `You are Lavvi, a warm teacher helping a student revise from their own class notes.
You get the cleaned text of the notes. Use only what they cover, plus brief clarification where the notes are unclear. If the notes contain a likely mistake, say so gently in "fixes".
Reply with ONE JSON object only (no markdown fences) in exactly this shape:
{
 "summary": array of 4 to 7 short bullet strings (the whole page in a nutshell),
 "keyTerms": array of up to 10 { "term": string, "meaning": one plain sentence },
 "difficult": array of up to 5 { "passage": a short excerpt (max 25 words) copied from the notes, "explain": 2 to 4 simple sentences, "hinglish": the same explanation in natural spoken Hinglish (Hindi in English letters, never Devanagari), "example": one concrete everyday example or tiny worked example },
 "fixes": array of up to 3 strings: possible errors or missing steps in the notes, or [] if none,
 "cards": array of 8 to 12 { "front": question, "back": short answer },
 "quiz": array of exactly 5 { "question", "options": [ {"text", "isCorrect": boolean} x4, exactly one correct ], "explanation" },
 "plan": array of 3 short strings: a quick revision plan (what to do first, second, third)
}
Pick the "difficult" passages that a student is most likely to find hard. All text except "hinglish" is English with no markdown and no emojis.`;

const ASK_SYSTEM = `You are Lavvi, a friendly teacher answering a student follow-up question.
Reply with ONE JSON object only (no markdown fences): { "answer": string, "hinglish": string }.
"answer" is under 120 words, plain text, no markdown, in English.
"hinglish" says the same thing in natural spoken Hinglish (Hindi in English letters, technical words kept in English), never Devanagari.`;

const HINGLISH_SYSTEM = `You turn English teaching sentences into natural spoken Hinglish: Hindi written in English letters (Roman script), the way an Indian teacher talks in class, keeping technical words in English. Never use Devanagari.
Reply with ONE JSON object only (no markdown fences): { "lines": string[] } with exactly one Hinglish string per input sentence, in the same order.`;

// One function for every AI call. `user` is a string or an array of blocks:
// { type: 'text', text } and { type: 'image', source: { media_type, data } }.
class AiError extends Error {}

// Turns a provider failure into a message the student (or you) can act on.
function explainAiError(provider, status, detail) {
  let msg = '';
  try {
    msg = JSON.parse(detail)?.error?.message || '';
  } catch {
    msg = String(detail || '').slice(0, 200);
  }
  if (provider === 'gemini') {
    if (/api key not valid|API_KEY_INVALID/i.test(msg) || status === 401) return 'Google rejected the API key. Create a new key at https://aistudio.google.com/apikey and put it in the .env file.';
    if (status === 403) return `Google refused this request (${msg || 'permission denied'}). The key may be restricted, or Gemini may not be available in your region.`;
    if (status === 404) return `Google cannot use the model "${MODEL}" for this request. Run "npm run check" to see which models your key can use, then set GEMINI_MODEL in .env.`;
    if (status === 429) return 'Gemini free-tier limit reached. Wait a minute and try again.';
    if (status === 400) return `Gemini could not process that request: ${msg}`;
    return `Gemini error ${status}: ${msg}`;
  }
  if (status === 401) return 'Anthropic rejected the API key.';
  if (status === 429) return 'Rate limit reached. Wait a minute and try again.';
  return `Anthropic error ${status}: ${msg}`;
}

async function claude(system, user, maxTokens) {
  return PROVIDER === 'gemini' ? gemini(system, user, maxTokens) : anthropic(system, user, maxTokens);
}

async function anthropic(system, user, maxTokens) {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' },
    body: JSON.stringify({ model: MODEL, max_tokens: maxTokens, system, messages: [{ role: 'user', content: user }] })
  });
  if (!res.ok) throw new AiError(explainAiError('anthropic', res.status, await res.text().catch(() => '')));
  const data = await res.json();
  return data.content?.map((b) => b.text || '').join('') || '';
}

async function gemini(system, user, maxTokens) {
  const parts = (Array.isArray(user) ? user : [{ type: 'text', text: user }]).map((b) =>
    b.type === 'image' ? { inlineData: { mimeType: b.source.media_type, data: b.source.data } } : { text: b.text }
  );
  const generationConfig = { maxOutputTokens: maxTokens, responseMimeType: 'application/json' };
  if (/2\.5/.test(MODEL)) generationConfig.thinkingConfig = { thinkingBudget: 0 }; // keep the whole budget for the answer
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-goog-api-key': KEY },
    body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents: [{ role: 'user', parts }], generationConfig })
  });
  if (!res.ok) throw new AiError(explainAiError('gemini', res.status, await res.text().catch(() => '')));
  const data = await res.json();
  const out = data.candidates?.[0]?.content?.parts?.map((p) => p.text || '').join('') || '';
  if (!out) throw new AiError(`Gemini returned no answer${data.promptFeedback?.blockReason ? ` (blocked: ${data.promptFeedback.blockReason})` : ''}. Try again or rephrase.`);
  return out;
}

// Lessons already written are kept in memory, so the same topic doesn't cost another API call.
const lessonCache = new Map();

const parseJson = (text) => {
  try {
    return JSON.parse(text.slice(text.indexOf('{'), text.lastIndexOf('}') + 1));
  } catch {
    throw new AiError('The AI answered in a format Lavvi could not read. Please try again.');
  }
};

const readBody = (req, limit = 40_000) =>
  new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => {
      data += c;
      if (data.length > limit) reject(new Error('Request too large'));
    });
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); } catch (e) { reject(e); }
    });
  });

const send = (res, status, body) => {
  res.writeHead(status, { 'content-type': 'application/json' });
  res.end(JSON.stringify(body));
};

export async function handleRequest(req, res, apiOnly = false) {
    try {
      if (req.url === '/api/health') return send(res, 200, { ai: Boolean(KEY), provider: PROVIDER, model: KEY ? MODEL : null });

      if (req.method === 'POST' && req.url === '/api/lesson') {
        if (!KEY) return send(res, 503, { error: NO_KEY });
        const { topic, level } = await readBody(req);
        const clean = String(topic || '').trim().slice(0, 120);
        if (!clean) return send(res, 400, { error: 'Missing topic.' });
        const depth = LEVELS[level] ? level : 'standard';
        const cacheKey = `${clean.toLowerCase()}|${depth}`;
        if (lessonCache.has(cacheKey)) return send(res, 200, lessonCache.get(cacheKey));
        const text = await claude(lessonSystem(depth), `Topic: ${clean}`, 5000);
        const json = parseJson(text);
        lessonCache.set(cacheKey, json);
        if (lessonCache.size > 200) lessonCache.delete(lessonCache.keys().next().value);
        return send(res, 200, json);
      }


      if (req.method === 'POST' && req.url === '/api/compare') {
        if (!KEY) return send(res, 503, { error: NO_KEY });
        const { a, b } = await readBody(req);
        const A = String(a || '').trim().slice(0, 80);
        const B = String(b || '').trim().slice(0, 80);
        if (!A || !B) return send(res, 400, { error: 'Please enter two concepts.' });
        if (A.toLowerCase() === B.toLowerCase()) return send(res, 400, { error: 'Those are the same concept. Enter two different ones.' });
        const cacheKey = `cmp|${[A.toLowerCase(), B.toLowerCase()].join('|')}`;
        if (lessonCache.has(cacheKey)) return send(res, 200, lessonCache.get(cacheKey));
        const text = await claude(COMPARE_SYSTEM, `Compare: "${A}" and "${B}"`, 5000);
        const json = parseJson(text);
        lessonCache.set(cacheKey, json);
        if (lessonCache.size > 200) lessonCache.delete(lessonCache.keys().next().value);
        return send(res, 200, json);
      }

      if (req.method === 'POST' && req.url === '/api/scan') {
        if (!KEY) return send(res, 503, { error: NO_KEY });
        const { images } = await readBody(req, 14_000_000);
        const list = (Array.isArray(images) ? images : []).slice(0, 4);
        const blocks = [];
        for (const img of list) {
          const m = /^data:(image\/(?:jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/.exec(String(img || ''));
          if (!m) return send(res, 400, { error: 'Please upload JPG, PNG or WebP photos.' });
          blocks.push({ type: 'image', source: { type: 'base64', media_type: m[1], data: m[2] } });
        }
        if (!blocks.length) return send(res, 400, { error: 'No photo received.' });
        blocks.push({ type: 'text', text: `Read ${blocks.length === 1 ? 'this page' : `these ${blocks.length} pages`} of notes.` });
        const text = await claude(SCAN_SYSTEM, blocks, 6000);
        return send(res, 200, parseJson(text));
      }

      if (req.method === 'POST' && req.url === '/api/notes-study') {
        if (!KEY) return send(res, 503, { error: NO_KEY });
        const { text, title } = await readBody(req, 60_000);
        const notes = String(text || '').trim().slice(0, 12_000);
        if (notes.length < 20) return send(res, 400, { error: 'The notes are too short to study from.' });
        const out = await claude(STUDY_SYSTEM, `Title: ${String(title || 'My notes').slice(0, 100)}\n\nNotes:\n${notes}`, 6000);
        return send(res, 200, parseJson(out));
      }

      if (req.method === 'POST' && req.url === '/api/hinglish') {
        if (!KEY) return send(res, 503, { error: NO_KEY });
        const { lines } = await readBody(req);
        const list = (Array.isArray(lines) ? lines : []).slice(0, 24).map((l) => String(l).slice(0, 400));
        if (!list.length) return send(res, 400, { error: 'Missing lines.' });
        const text = await claude(HINGLISH_SYSTEM, JSON.stringify(list), 3000);
        const out = parseJson(text).lines;
        return send(res, 200, { lines: Array.isArray(out) ? out.map(String) : [] });
      }

      if (req.method === 'POST' && req.url === '/api/ask') {
        if (!KEY) return send(res, 503, { error: NO_KEY });
        const { question, topic, context } = await readBody(req);
        const text = await claude(
          ASK_SYSTEM,
          `Lesson topic: ${String(topic).slice(0, 120)}\nLesson notes: ${String(context).slice(0, 1500)}\n\nStudent question: ${String(question).slice(0, 400)}`,
          800
        );
        try {
          const json = parseJson(text);
          return send(res, 200, { answer: String(json.answer || '').trim(), hinglish: String(json.hinglish || '').trim() });
        } catch {
          return send(res, 200, { answer: text.trim(), hinglish: '' });
        }
      }

      if (apiOnly) return send(res, 404, { error: 'API route not found.' });

      // Static files (production build)
      const urlPath = req.url.split('?')[0];
      let file = path.join(DIST, urlPath === '/' ? 'index.html' : urlPath);
      if (!file.startsWith(DIST) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
        file = path.join(DIST, 'index.html');
      }
      if (!fs.existsSync(file)) return send(res, 404, { error: 'Run `npm run build` first.' });
      res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' });
      fs.createReadStream(file).pipe(res);
    } catch (e) {
      console.error(e);
      if (e instanceof AiError) return send(res, 502, { error: e.message });
      send(res, e.message === 'Request too large' ? 413 : 500, {
        error: e.message === 'Request too large' ? 'That photo is too large. Try a smaller one.' : 'Something went wrong. Please try again.'
      });
    }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  http.createServer((req, res) => handleRequest(req, res)).listen(PORT, () => {
    console.log(`Lavvi server on http://localhost:${PORT}  (AI ${KEY ? `enabled: ${PROVIDER}, ${MODEL}` : 'disabled: set GEMINI_API_KEY or ANTHROPIC_API_KEY'})`);
  });
}
