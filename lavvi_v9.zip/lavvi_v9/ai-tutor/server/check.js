// Run:  npm run check
// Tests your API key and lists the Gemini models it can use.
import './env.js';

const key = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
if (!key) {
  console.log('No GEMINI_API_KEY found. Put it in the .env file in the project folder (see .env.example).');
  process.exit(1);
}
console.log(`Key found (${key.length} characters).`);

try {
  const res = await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=100', { headers: { 'x-goog-api-key': key } });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    console.log(`\nGoogle said: HTTP ${res.status} ${body?.error?.message || ''}`);
    console.log('Create a new key at https://aistudio.google.com/apikey and paste it into .env after GEMINI_API_KEY=');
    process.exit(1);
  }
  const usable = (body.models || []).filter((m) => m.supportedGenerationMethods?.includes('generateContent')).map((m) => m.name.replace('models/', ''));
  console.log('\nThe key works. Models you can use:');
  usable.filter((n) => /^gemini/.test(n)).slice(0, 15).forEach((n) => console.log(`  ${n}`));
  const want = process.env.GEMINI_MODEL || 'gemini-3.1-flash-lite';
  console.log(usable.includes(want) ? `\nLavvi will use ${want}. All good.` : `\n"${want}" is not in that list. Add GEMINI_MODEL=<one of the names above> to .env.`);
} catch (e) {
  console.log(`\nCould not reach Google: ${e.cause?.code || e.message}. Check your internet connection, proxy or firewall.`);
  process.exit(1);
}
