import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const apiPort = process.env.API_PORT || process.env.PORT || '8790';
const env = { ...process.env, API_PORT: apiPort };
const children = [];
let stopping = false;

function stop(exitCode = 0) {
  if (stopping) return;
  stopping = true;
  process.exitCode = exitCode;
  for (const child of children) {
    if (child.exitCode === null) child.kill();
  }
}

function start(name, args) {
  const child = spawn(process.execPath, args, { cwd: root, env, stdio: 'inherit' });
  children.push(child);
  child.on('error', (error) => {
    console.error(`[dev] Could not start ${name}: ${error.message}`);
    stop(1);
  });
  child.on('exit', (code, signal) => {
    if (stopping) return;
    console.error(`[dev] ${name} stopped unexpectedly (${signal || `exit code ${code ?? 1}`}).`);
    stop(code ?? 1);
  });
}

process.on('SIGINT', () => stop());
process.on('SIGTERM', () => stop());

console.log(`[dev] Starting Lavvi API on port ${apiPort} and Vite.`);
start('Lavvi API', [path.join(root, 'server', 'index.js')]);
start('Vite', [path.join(root, 'node_modules', 'vite', 'bin', 'vite.js'), ...process.argv.slice(2)]);
