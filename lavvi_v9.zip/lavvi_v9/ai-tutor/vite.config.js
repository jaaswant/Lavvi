import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  // In development, forward /api calls to the AI server (npm run server)
  server: { proxy: { '/api': `http://localhost:${process.env.API_PORT || 8790}` } },
})
